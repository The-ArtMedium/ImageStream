"""Export window, laid out the way Lightroom Classic does it: you choose the photos,
then Export Location, File Naming, File Settings, Image Sizing, Output Sharpening,
Metadata and Post-Processing. The last settings used are remembered."""
import os

from PySide6.QtCore import Qt, QSize, QSettings
from PySide6.QtGui import QIcon, QColor, QBrush
from PySide6.QtWidgets import (
    QDialog, QHBoxLayout, QVBoxLayout, QListWidget, QListWidgetItem, QPushButton,
    QLabel, QGroupBox, QComboBox, QSpinBox, QCheckBox, QLineEdit, QFileDialog,
    QScrollArea, QWidget, QFormLayout, QRadioButton, QButtonGroup, QListView,
)

PRESETS = {
    "Full quality (archive)": dict(fmt="JPEG", quality=95, size=0, sharpen="none", max_kb=0, meta="all"),
    "Agency / editor (3000 px)": dict(fmt="JPEG", quality=90, size=3000, sharpen="low", max_kb=0, meta="all"),
    "Web (2048 px)": dict(fmt="JPEG", quality=85, size=2048, sharpen="standard", max_kb=0, meta="copyright"),
    "Social media (1080 px)": dict(fmt="JPEG", quality=85, size=1080, sharpen="standard", max_kb=0, meta="copyright"),
    "Email / WhatsApp (under 1 MB)": dict(fmt="JPEG", quality=90, size=2048, sharpen="standard", max_kb=1000, meta="copyright"),
}


class ExportDialog(QDialog):
    def __init__(self, parent, photos, checked, folder):
        """photos: list of (path, pixmap, note, color) in strip order.
        checked: the photos ticked when the window opens."""
        super().__init__(parent)
        self.setWindowTitle("Export")
        self.resize(1040, 680)
        self.settings = QSettings("ImageStream", "LocalRAW")
        self.folder = folder
        self.photos = photos
        self.notes = {p: note for p, _pm, note, _c in photos}

        outer = QHBoxLayout(self)

        # ── left: the photos, each with a tick box ──
        left = QVBoxLayout()
        self.count_label = QLabel()
        self.count_label.setStyleSheet("font-weight: bold; font-size: 14px;")
        left.addWidget(self.count_label)
        quick = QHBoxLayout()
        for text, rule in [("All", lambda p: True), ("None", lambda p: False),
                           ("Edited", lambda p: "\u270e" in self.notes[p] or "\U0001F4BE" in self.notes[p]),
                           ("In focus", lambda p: "IN FOCUS" in self.notes[p])]:
            b = QPushButton(text)
            b.clicked.connect(lambda _=False, r=rule: self._tick(r))
            quick.addWidget(b)
        left.addLayout(quick)
        self.grid = QListWidget()
        self.grid.setViewMode(QListView.IconMode)
        self.grid.setIconSize(QSize(120, 90))
        self.grid.setGridSize(QSize(138, 132))
        self.grid.setResizeMode(QListView.Adjust)
        self.grid.setMovement(QListView.Static)
        self.grid.setSpacing(4)
        self.grid.setWordWrap(True)
        for path, pixmap, note, color in photos:
            item = QListWidgetItem(QIcon(pixmap), os.path.basename(path) + (f"\n{note}" if note else ""))
            item.setData(Qt.UserRole, path)
            item.setFlags((item.flags() & ~Qt.ItemIsUserCheckable) | Qt.ItemIsEnabled)   # the click itself ticks
            item.setCheckState(Qt.Checked if path in checked else Qt.Unchecked)
            if color:
                item.setForeground(QBrush(QColor(color)))
            self.grid.addItem(item)
        self.grid.itemChanged.connect(lambda _i: self._update_count())
        self.grid.itemClicked.connect(self._toggle_item)
        left.addWidget(self.grid, 1)
        hint = QLabel("Click a photo to tick or untick it.")
        hint.setStyleSheet("color: #888; font-size: 11px;")
        left.addWidget(hint)
        outer.addLayout(left, 5)

        # ── right: the settings, in Lightroom's order ──
        right = QVBoxLayout()
        preset_row = QHBoxLayout()
        preset_row.addWidget(QLabel("Preset:"))
        self.preset = QComboBox()
        self.preset.addItem("Last used")
        self.preset.addItems(list(PRESETS))
        self.preset.currentTextChanged.connect(self._apply_preset)
        preset_row.addWidget(self.preset, 1)
        right.addLayout(preset_row)

        panel = QWidget()
        form_box = QVBoxLayout(panel)

        loc = QGroupBox("Export Location")
        f = QFormLayout(loc)
        row = QHBoxLayout()
        self.dest = QLineEdit()
        choose = QPushButton("Choose...")
        choose.clicked.connect(self._choose_folder)
        row.addWidget(self.dest, 1)
        row.addWidget(choose)
        f.addRow("Folder:", row)
        self.subfolder_on = QCheckBox("Put in subfolder:")
        self.subfolder = QLineEdit("Exported")
        sub = QHBoxLayout()
        sub.addWidget(self.subfolder_on)
        sub.addWidget(self.subfolder, 1)
        f.addRow(sub)
        self.existing = QComboBox()
        self.existing.addItems(["Choose a new name (keep both)", "Overwrite", "Skip"])
        f.addRow("If the file exists:", self.existing)
        form_box.addWidget(loc)

        naming = QGroupBox("File Naming")
        f = QFormLayout(naming)
        self.naming = QComboBox()
        self.naming.addItems(["Original name", "Original name + text", "Custom name + number"])
        f.addRow("Name:", self.naming)
        self.custom = QLineEdit()
        self.custom.setPlaceholderText("e.g.  Final_Game   or   -edit")
        f.addRow("Text:", self.custom)
        self.start = QSpinBox()
        self.start.setRange(1, 99999)
        f.addRow("Start number:", self.start)
        self.example = QLabel()
        self.example.setStyleSheet("color: #888;")
        f.addRow("Example:", self.example)
        for w in (self.naming, self.custom, self.start):
            (w.currentTextChanged if isinstance(w, QComboBox) else
             w.textChanged if isinstance(w, QLineEdit) else w.valueChanged).connect(self._update_example)
        form_box.addWidget(naming)

        files = QGroupBox("File Settings")
        f = QFormLayout(files)
        self.fmt = QComboBox()
        self.fmt.addItems(["JPEG", "TIFF", "PNG"])
        f.addRow("Format:", self.fmt)
        self.quality = QSpinBox()
        self.quality.setRange(40, 100)
        f.addRow("Quality:", self.quality)
        limit = QHBoxLayout()
        self.limit_on = QCheckBox("Limit file size to")
        self.max_kb = QSpinBox()
        self.max_kb.setRange(100, 50000)
        self.max_kb.setSuffix(" KB")
        limit.addWidget(self.limit_on)
        limit.addWidget(self.max_kb, 1)
        f.addRow(limit)
        f.addRow(QLabel("Colour: sRGB (right for screens, web and most labs)"))
        self.fmt.currentTextChanged.connect(self._format_changed)
        form_box.addWidget(files)

        sizing = QGroupBox("Image Sizing")
        f = QFormLayout(sizing)
        size_row = QHBoxLayout()
        self.resize_on = QCheckBox("Resize: long edge")
        self.long_edge = QSpinBox()
        self.long_edge.setRange(200, 20000)
        self.long_edge.setSuffix(" px")
        size_row.addWidget(self.resize_on)
        size_row.addWidget(self.long_edge, 1)
        f.addRow(size_row)
        f.addRow(QLabel("Photos are never enlarged."))
        form_box.addWidget(sizing)

        sharp = QGroupBox("Output Sharpening")
        f = QFormLayout(sharp)
        self.sharpen = QComboBox()
        for text, value in [("None", "none"), ("For screen: low", "low"),
                            ("For screen: standard", "standard"), ("For screen: high", "high")]:
            self.sharpen.addItem(text, value)
        f.addRow("Sharpen:", self.sharpen)
        form_box.addWidget(sharp)

        meta = QGroupBox("Metadata")
        f = QFormLayout(meta)
        self.meta = QComboBox()
        for text, value in [("All camera data (date, camera, lens, author)", "all"),
                            ("Author and copyright only", "copyright"), ("None", "none")]:
            self.meta.addItem(text, value)
        f.addRow("Include:", self.meta)
        self.no_location = QCheckBox("Remove location (GPS)")
        self.no_location.setToolTip("Recommended when the place where the photo was taken must stay private")
        f.addRow(self.no_location)
        form_box.addWidget(meta)

        post = QGroupBox("Post-Processing")
        f = QFormLayout(post)
        self.open_after = QCheckBox("Show the folder when done")
        f.addRow(self.open_after)
        form_box.addWidget(post)
        form_box.addStretch(1)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(panel)
        right.addWidget(scroll, 1)

        buttons = QHBoxLayout()
        buttons.addStretch(1)
        cancel = QPushButton("Cancel")
        cancel.clicked.connect(self.reject)
        self.go = QPushButton("Export")
        self.go.setDefault(True)
        self.go.setStyleSheet("QPushButton { font-weight: bold; padding: 6px 18px; }")
        self.go.clicked.connect(self._accept)
        buttons.addWidget(cancel)
        buttons.addWidget(self.go)
        right.addLayout(buttons)
        outer.addLayout(right, 4)

        self._load_last()
        self._update_count()
        self._update_example()

    # ── photo ticking ──
    def _tick(self, rule):
        self.grid.blockSignals(True)
        for i in range(self.grid.count()):
            item = self.grid.item(i)
            item.setCheckState(Qt.Checked if rule(item.data(Qt.UserRole)) else Qt.Unchecked)
        self.grid.blockSignals(False)
        self._update_count()

    def _toggle_item(self, item):
        item.setCheckState(Qt.Unchecked if item.checkState() == Qt.Checked else Qt.Checked)

    def chosen(self):
        return [self.grid.item(i).data(Qt.UserRole) for i in range(self.grid.count())
                if self.grid.item(i).checkState() == Qt.Checked]

    def _update_count(self):
        n = len(self.chosen())
        self.count_label.setText(f"Export {n} of {self.grid.count()} photos")
        self.go.setText(f"Export {n} photo{'s' if n != 1 else ''}")
        self.go.setEnabled(n > 0)

    # ── settings ──
    def _choose_folder(self):
        d = QFileDialog.getExistingDirectory(self, "Export to folder", self.dest.text())
        if d:
            self.dest.setText(d)

    def _format_changed(self, fmt):
        jpeg = fmt == "JPEG"
        self.quality.setEnabled(jpeg)
        self.limit_on.setEnabled(jpeg)
        self.max_kb.setEnabled(jpeg)
        self._update_example()

    def _update_example(self, *_):
        mode = self.naming.currentIndex()
        self.custom.setEnabled(mode > 0)
        self.start.setEnabled(mode == 2)
        first = self.chosen()[:1] or [p for p, *_ in self.photos[:1]] or ["IMG_0412.CR3"]
        ext = {"JPEG": ".jpg", "TIFF": ".tif", "PNG": ".png"}[self.fmt.currentText()]
        self.example.setText(name_for(first[0], 0, mode, self.custom.text(), self.start.value()) + ext)

    def _apply_preset(self, name):
        p = PRESETS.get(name)
        if not p:
            return
        self.fmt.setCurrentText(p["fmt"])
        self.quality.setValue(p["quality"])
        self.resize_on.setChecked(bool(p["size"]))
        if p["size"]:
            self.long_edge.setValue(p["size"])
        self.sharpen.setCurrentIndex(self.sharpen.findData(p["sharpen"]))
        self.limit_on.setChecked(bool(p["max_kb"]))
        if p["max_kb"]:
            self.max_kb.setValue(p["max_kb"])
        self.meta.setCurrentIndex(self.meta.findData(p["meta"]))

    def _load_last(self):
        s = self.settings
        self.dest.setText(s.value("dest", "") or self.folder or os.path.expanduser("~"))
        if self.folder and not s.value("dest_fixed", False, type=bool):
            self.dest.setText(self.folder)           # by default: next to the photos being worked on
        self.subfolder_on.setChecked(s.value("subfolder_on", True, type=bool))
        self.subfolder.setText(s.value("subfolder", "Exported"))
        self.existing.setCurrentIndex(s.value("existing", 0, type=int))
        self.naming.setCurrentIndex(s.value("naming", 0, type=int))
        self.custom.setText(s.value("custom", ""))
        self.start.setValue(s.value("start", 1, type=int))
        self.fmt.setCurrentText(s.value("fmt", "JPEG"))
        self.quality.setValue(s.value("quality", 92, type=int))
        self.limit_on.setChecked(s.value("limit_on", False, type=bool))
        self.max_kb.setValue(s.value("max_kb", 1000, type=int))
        self.resize_on.setChecked(s.value("resize_on", False, type=bool))
        self.long_edge.setValue(s.value("long_edge", 3000, type=int))
        self.sharpen.setCurrentIndex(max(0, self.sharpen.findData(s.value("sharpen", "none"))))
        self.meta.setCurrentIndex(max(0, self.meta.findData(s.value("meta", "all"))))
        self.no_location.setChecked(s.value("no_location", False, type=bool))
        self.open_after.setChecked(s.value("open_after", True, type=bool))
        self._format_changed(self.fmt.currentText())

    def _accept(self):
        s = self.settings
        s.setValue("dest_fixed", bool(self.folder) and os.path.abspath(self.dest.text()) != os.path.abspath(self.folder))
        s.setValue("dest", self.dest.text())
        for key, value in self.options().items():
            if key not in ("paths", "out_dir", "dest"):
                s.setValue(key, value)
        self.accept()

    def options(self):
        dest = self.dest.text().strip() or self.folder or os.path.expanduser("~")
        out_dir = os.path.join(dest, self.subfolder.text().strip() or "Exported") if self.subfolder_on.isChecked() else dest
        return dict(
            paths=self.chosen(), out_dir=out_dir, dest=dest,
            subfolder_on=self.subfolder_on.isChecked(), subfolder=self.subfolder.text(),
            existing=self.existing.currentIndex(), naming=self.naming.currentIndex(),
            custom=self.custom.text(), start=self.start.value(),
            fmt=self.fmt.currentText(), quality=self.quality.value(),
            limit_on=self.limit_on.isChecked() and self.fmt.currentText() == "JPEG", max_kb=self.max_kb.value(),
            resize_on=self.resize_on.isChecked(), long_edge=self.long_edge.value(),
            sharpen=self.sharpen.currentData(), meta=self.meta.currentData(),
            no_location=self.no_location.isChecked(), open_after=self.open_after.isChecked(),
        )


def name_for(path, index, mode, text, start):
    """File name (without extension) for the index-th exported photo."""
    stem = os.path.splitext(os.path.basename(path))[0]
    text = (text or "").strip()
    if mode == 1:
        return stem + (text if text.startswith(("-", "_")) or not text else "_" + text)
    if mode == 2:
        return f"{text or 'Photo'}_{start + index:03d}"
    return stem
