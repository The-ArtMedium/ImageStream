import io
import os

import cv2
import numpy as np
from PIL import Image

from app.utils.file_utils import is_raw


def camera_exif(source_path, mode="all", strip_location=False):
    """The camera data (date, camera, lens, exposure, author...) of the original
    photo as EXIF bytes with the orientation reset to upright, or None.
    mode: "all", "copyright" (author and copyright only) or "none"."""
    if mode == "none":
        return None
    try:
        if is_raw(source_path):
            import rawpy
            with rawpy.imread(source_path) as raw:
                thumb = raw.extract_thumb()
            if thumb.format != rawpy.ThumbFormat.JPEG:
                return None
            img = Image.open(io.BytesIO(bytes(thumb.data)))
        else:
            img = Image.open(source_path)
        raw_bytes = img.info.get("exif")
        if raw_bytes:
            try:
                import piexif
                data = piexif.load(raw_bytes)
                data["0th"][piexif.ImageIFD.Orientation] = 1
                data.pop("thumbnail", None)
                data["1st"] = {}
                if strip_location:
                    data["GPS"] = {}
                    data["0th"].pop(piexif.ImageIFD.GPSTag, None)
                if mode == "copyright":
                    keep = {piexif.ImageIFD.Artist, piexif.ImageIFD.Copyright}
                    data = {"0th": {k: v for k, v in data["0th"].items() if k in keep},
                            "Exif": {}, "GPS": {}, "1st": {}, "Interop": {}}
                    if not data["0th"]:
                        return None
                return piexif.dump(data)
            except Exception:
                pass
        exif = img.getexif()
        if not exif:
            return None
        exif[0x0112] = 1
        if strip_location:
            exif.pop(0x8825, None)
        if mode == "copyright":
            for tag in list(exif.keys()):
                if tag not in (0x013B, 0x8298):       # Artist, Copyright
                    del exif[tag]
            if not len(exif):
                return None
        return exif.tobytes()
    except Exception:
        return None


class Exporter:
    def __init__(self):
        pass

    SHARPEN = {"low": 0.35, "standard": 0.7, "high": 1.1}

    def save(self, image, output_path, quality=92, long_edge=None, exif=None,
             sharpen=None, max_kb=None):
        """Write an RGB picture. Works with any characters in the path, on every system.
        sharpen: None, "low", "standard" or "high" (for screen, after resizing).
        max_kb: for JPEG, lower the quality as little as needed to stay under this size."""
        if long_edge:
            h, w = image.shape[:2]
            k = long_edge / float(max(h, w))
            if k < 1.0:
                image = cv2.resize(image, (max(1, round(w * k)), max(1, round(h * k))),
                                   interpolation=cv2.INTER_AREA)
        if sharpen in self.SHARPEN:
            soft = cv2.GaussianBlur(image, (0, 0), 0.9)
            amount = self.SHARPEN[sharpen]
            image = cv2.addWeighted(image, 1.0 + amount, soft, -amount, 0)
        picture = Image.fromarray(np.ascontiguousarray(image))
        extension = os.path.splitext(output_path)[1].lower()
        options = {}
        if exif:
            options["exif"] = exif
        if extension in (".jpg", ".jpeg"):
            if max_kb:
                quality = self._quality_for_size(picture, int(quality), max_kb * 1024, options.get("exif"))
            options.update(quality=int(quality), subsampling=0 if quality >= 90 else 2, optimize=True)
            fmt = "JPEG"
        elif extension == ".png":
            fmt = "PNG"
        elif extension in (".tif", ".tiff"):
            fmt = "TIFF"
            options["compression"] = "tiff_lzw"
        else:
            raise ValueError("Unsupported export format")
        try:
            picture.save(output_path, fmt, **options)
        except Exception:
            if "exif" not in options:
                raise
            options.pop("exif")                     # odd camera data: save without it
            picture.save(output_path, fmt, **options)

    @staticmethod
    def _quality_for_size(picture, best, limit, exif=None):
        """Highest JPEG quality (up to best) whose file fits under limit bytes."""
        def size(q):
            buf = io.BytesIO()
            extra = {"exif": exif} if exif else {}
            picture.save(buf, "JPEG", quality=q, subsampling=0 if q >= 90 else 2, optimize=True, **extra)
            return buf.tell()
        if size(best) <= limit:
            return best
        lo, hi = 10, best - 1
        found = 10
        while lo <= hi:
            mid = (lo + hi) // 2
            if size(mid) <= limit:
                found, lo = mid, mid + 1
            else:
                hi = mid - 1
        return found
