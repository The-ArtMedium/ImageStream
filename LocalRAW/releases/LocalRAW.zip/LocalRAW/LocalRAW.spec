# LocalRAW.spec
# PyInstaller build configuration for Windows and macOS
# Run with: pyinstaller LocalRAW.spec

import sys
from PyInstaller.building.build_main import Analysis, PYZ, EXE, BUNDLE, COLLECT

block_cipher = None

a = Analysis(
    ['main.py'],
    pathex=['.'],
    binaries=[],
    datas=[
        ('resources/style.qss',               'resources'),
        ('resources/translations/*.json',      'resources/translations'),
    ],
    hiddenimports=[
        'rawpy',
        'PySide6.QtCore',
        'PySide6.QtGui',
        'PySide6.QtWidgets',
        'cv2',
        'numpy',
        'PIL',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

# ─────────────────────────────────────────
# WINDOWS: Single .exe
# ─────────────────────────────────────────
exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='LocalRAW',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,                  # No terminal window
    disable_windowed_traceback=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon='resources/icon.ico',      # Add your icon here
    onefile=True,
)

# ─────────────────────────────────────────
# macOS: .app Bundle
# ─────────────────────────────────────────
if sys.platform == 'darwin':
    app = BUNDLE(
        exe,
        name='LocalRAW.app',
        icon='resources/icon.icns',     # Add your icon here
        bundle_identifier='com.localraw.app',
        info_plist={
            'CFBundleName': 'LocalRAW',
            'CFBundleDisplayName': 'LocalRAW',
            'CFBundleVersion': '1.0.0',
            'CFBundleShortVersionString': '1.0.0',
            'NSHighResolutionCapable': True,
            'NSRequiresAquaSystemAppearance': False,  # Supports dark mode
        },
    )
