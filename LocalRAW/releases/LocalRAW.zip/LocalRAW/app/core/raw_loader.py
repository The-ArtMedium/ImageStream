import rawpy
import numpy as np
import os

from app.utils.file_utils import RAW_EXTENSIONS


class RawLoader:
    def __init__(self):
        pass

    def load_image(self, file_path):
        extension = os.path.splitext(file_path)[1].lower()

        if extension in RAW_EXTENSIONS:
            with rawpy.imread(file_path) as raw:
                rgb = raw.postprocess()
            return rgb
        else:
            from PIL import Image, ImageOps
            image = Image.open(file_path)
            image = ImageOps.exif_transpose(image).convert("RGB")   # vertical shots upright
            return np.array(image)
