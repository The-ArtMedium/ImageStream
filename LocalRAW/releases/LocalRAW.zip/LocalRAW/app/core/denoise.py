"""Noise reduction that measures the noise of each photo first.

Brightness noise and colour noise are treated separately: brightness with non-local
means, colour with wavelet layers (fine grain to coarse blotches), in each case only
removing what is weaker than the noise measured on this photo.

Because the strength follows the measured noise, the same slider position does
about the same job at ISO 400 and at ISO 12800, on the preview and on the export."""
import cv2
import numpy as np

_B3 = np.array([1, 4, 6, 4, 1], np.float32) / 16.0
# how much white noise of strength 1 is left in each wavelet layer of this filter
_NOISE_PER_LEVEL = [0.8907, 0.2007, 0.0856, 0.0413, 0.0205, 0.0103]


def _smooth(img, level):
    step = 2 ** level
    kernel = np.zeros(4 * step + 1, np.float32)
    kernel[::step] = _B3
    return cv2.sepFilter2D(img, -1, kernel, kernel, borderType=cv2.BORDER_REFLECT)


def noise_sigma(channel):
    """Noise of one channel (same units as the channel), from its finest layer."""
    fine = channel - _smooth(channel, 0)
    mad = float(np.median(np.abs(fine - np.median(fine))))
    return mad / 0.6745 / _NOISE_PER_LEVEL[0]


def _wavelet_shrink(channel, sigma, strength, levels, weights):
    """Remove from each layer what is weaker than (strength x weight x noise)."""
    out = np.zeros_like(channel)
    current = channel
    for j in range(levels):
        smooth = _smooth(current, j)
        detail = current - smooth
        t = strength * weights[j] * sigma * _NOISE_PER_LEVEL[j]
        if t > 0:
            # soft shrink, rounded near the threshold so it doesn't leave a "plastic" look
            mag = np.abs(detail)
            detail = detail * np.clip((mag - t) / np.maximum(mag, 1e-6), 0, 1) ** 0.75
        out += detail
        current = smooth
    return out + current


def denoise(rgb, luminance=0.0, color=0.0, sigma=None):
    """rgb: float 0..1. luminance and color: 0..1 slider strengths.
    sigma: noise measured on the full photo (optional) so a crop is treated alike.

    Brightness noise: non-local means (it compares small patches across the area and
    averages the ones that match, so edges and texture survive), with its strength
    set from the measured noise. Colour noise: wavelet layers, so blotches go without
    colours bleeding over edges."""
    if luminance <= 0 and color <= 0:
        return rgb
    lab = cv2.cvtColor(rgb.astype(np.float32), cv2.COLOR_RGB2Lab)
    L, a, b = lab[..., 0], lab[..., 1], lab[..., 2]
    s = sigma or measure(rgb)
    if luminance > 0 and s["L"] > 0:
        h = (0.4 + 0.9 * luminance) * s["L"] * 2.55          # in the 0..255 scale used below
        if h >= 0.5:
            L8 = np.clip(L * 2.55, 0, 255).astype(np.uint8)
            search = 15 if L8.size > 1_000_000 else 21          # faster on big pictures, same look
            L = cv2.fastNlMeansDenoising(L8, h=float(h), templateWindowSize=7,
                                         searchWindowSize=search).astype(np.float32) / 2.55
    if color > 0:
        strength = 1.0 + 1.5 * color
        weights = [1.4, 1.4, 1.2, 1.0, 0.8]
        if s["a"] > 0:
            a = _wavelet_shrink(a, s["a"], strength, 5, weights)
        if s["b"] > 0:
            b = _wavelet_shrink(b, s["b"], strength, 5, weights)
    out = cv2.cvtColor(np.dstack([L, a, b]).astype(np.float32), cv2.COLOR_Lab2RGB)
    return np.clip(out, 0, 1)


def measure(rgb):
    """Noise of a photo in each Lab channel (measured on a centre crop for speed)."""
    h, w = rgb.shape[:2]
    if h * w > 4_000_000:
        ch, cw = int(h * 0.5), int(w * 0.5)
        y0, x0 = (h - ch) // 2, (w - cw) // 2
        rgb = rgb[y0:y0 + ch, x0:x0 + cw]
    lab = cv2.cvtColor(rgb.astype(np.float32), cv2.COLOR_RGB2Lab)
    return {"L": noise_sigma(lab[..., 0]), "a": noise_sigma(lab[..., 1]), "b": noise_sigma(lab[..., 2])}


def describe(sigma_l):
    """In words, for the panel."""
    if sigma_l < 0.6:
        return "very low"
    if sigma_l < 1.2:
        return "low"
    if sigma_l < 2.2:
        return "medium"
    if sigma_l < 3.5:
        return "high"
    return "very high"


def suggest(sigma):
    """Slider positions (0..100) that suit the measured noise."""
    sl, sc = sigma["L"], max(sigma["a"], sigma["b"])
    lum = 0 if sl < 0.5 else 40 if sl < 1.0 else 60 if sl < 3.0 else 70
    col = 0 if sc < 0.6 else 40 if sc < 2.0 else 50 if sc < 6.0 else 70
    return lum, col
