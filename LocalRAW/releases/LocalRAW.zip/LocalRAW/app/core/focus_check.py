"""Focus Check engine, merged into LocalRAW from the FocusCheck tool.

Scores every photo by Laplacian variance, sets the sharp / fixable / rejected
limits relative to the shoot itself, and reads the shutter speed to tell
motion blur from a focus error."""
import os
from fractions import Fraction

import cv2
import numpy as np

from app.utils.file_utils import is_raw

SCORE_LONG_SIDE = 1600           # every photo is scored at the same size
MOTION_SHUTTER = Fraction(1, 250)


def _gray_for_scoring(path):
    gray = None
    if is_raw(path):
        import rawpy
        with rawpy.imread(path) as raw:
            try:   # the camera's embedded preview is much faster than developing the RAW
                thumb = raw.extract_thumb()
                if thumb.format == rawpy.ThumbFormat.JPEG:
                    g = cv2.imdecode(np.frombuffer(thumb.data, np.uint8), cv2.IMREAD_GRAYSCALE)
                    if g is not None and max(g.shape) >= 1000:
                        gray = g
            except Exception:
                gray = None
            if gray is None:
                rgb = raw.postprocess(use_camera_wb=True, half_size=True, output_bps=8)
                gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
    else:
        data = np.fromfile(path, dtype=np.uint8)      # works with accented folder names too
        # big files are decoded at half size: twice as fast, and still above scoring size
        flag = cv2.IMREAD_REDUCED_GRAYSCALE_2 if data.size > 4_000_000 else cv2.IMREAD_GRAYSCALE
        gray = cv2.imdecode(data, flag)
    if gray is None:
        return None
    h, w = gray.shape[:2]
    k = SCORE_LONG_SIDE / float(max(h, w))
    if k < 1.0:
        gray = cv2.resize(gray, (int(w * k), int(h * k)), interpolation=cv2.INTER_AREA)
    return gray


def score_image(path):
    try:
        gray = _gray_for_scoring(path)
        if gray is None:
            return 0.0
        return float(cv2.Laplacian(gray, cv2.CV_64F).var())
    except Exception:
        return 0.0


def get_shutter(path):
    """Exposure time as a Fraction of a second, or None if it cannot be read."""
    try:
        from PIL import Image
        with Image.open(path) as img:
            exif = img.getexif()
            value = exif.get_ifd(0x8769).get(0x829A) or exif.get(0x829A)
        if value is None:
            return None
        if isinstance(value, tuple):
            return Fraction(int(value[0]), int(value[1]))
        return Fraction(float(value)).limit_denominator(100000)
    except Exception:
        return None


def blur_type(shutter):
    if shutter is None:
        return "unknown"
    return "motion" if shutter >= MOTION_SHUTTER else "focus"


def shutter_str(shutter):
    if shutter is None:
        return ""
    if shutter >= 1:
        return f"{float(shutter):.1f}s"
    return f"1/{int(round(1 / shutter))}s"


def calibrate(scores):
    """Limits relative to this shoot: (sharp_limit, fixable_limit)."""
    if not scores:
        return 150.0, 50.0
    s = sorted(scores)
    n = len(s)
    return max(s[int(n * 0.60)], 80.0), max(s[int(n * 0.30)], 20.0)


def category(score, sharp_t, fix_t):
    if score >= sharp_t:
        return "sharp"
    if score >= fix_t:
        return "fixable"
    return "rejected"


def recovery_level(score, sharp_t):
    """0 = already sharp, 1 gentle, 2 medium, 3 strong."""
    deficit = sharp_t - score
    if deficit <= 0:
        return 0
    if deficit <= sharp_t * 0.3:
        return 1
    if deficit <= sharp_t * 0.7:
        return 2
    return 3
