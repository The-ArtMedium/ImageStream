"""Subject-aware Focus Check: judge sharpness on the people, not the whole frame.

A small face finder (YuNet, MIT licence, about 230 KB, runs on the computer,
nothing is uploaded) locates the faces. Sharpness is then measured on the main
faces and their eyes. When the background is clearly sharper than the faces, the
photo is reported as "focus behind the subject". Photos without a usable face
fall back to the whole-photo measure.

Also reads the capture time, so bursts (fast series) can be grouped and the
sharpest frame of each burst marked."""
import io
import os
import sys
import threading
from datetime import datetime
from fractions import Fraction

import cv2
import numpy as np

from app.utils.file_utils import is_raw

ANALYSIS_LONG_SIDE = 1600       # every photo is examined at the same size
DETECT_LONG_SIDE = 960          # faces are found on a smaller copy (fast), then measured at full size
MIN_FACE = 26                   # faces narrower than this (at 1600 px) are crowd, not subject
MIN_CONFIDENCE = 0.80
BEHIND_RATIO = 1.8              # background this much sharper than the face = focus missed behind
BURST_GAP = 1.0                 # seconds between frames of one burst

_local = threading.local()


def _model_path():
    here = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    base = getattr(sys, "_MEIPASS", here)
    return os.path.join(base, "resources", "models", "face_detection_yunet_2023mar.onnx")


def face_finder_available():
    return os.path.exists(_model_path()) and hasattr(cv2, "FaceDetectorYN")


def _detector():
    det = getattr(_local, "detector", None)
    if det is None:
        try:
            cv2.setLogLevel(0) if hasattr(cv2, "setLogLevel") else None
        except Exception:
            pass
        det = cv2.FaceDetectorYN.create(_model_path(), "", (320, 320), MIN_CONFIDENCE, 0.3, 50)
        _local.detector = det
    return det


# ───────────────────────── loading ─────────────────────────

def _rotate_for_raw(img, flip):
    # LibRaw "flip": 3 = 180°, 5 = 90° counter-clockwise, 6 = 90° clockwise
    if flip == 3:
        return cv2.rotate(img, cv2.ROTATE_180)
    if flip == 5:
        return cv2.rotate(img, cv2.ROTATE_90_COUNTERCLOCKWISE)
    if flip == 6:
        return cv2.rotate(img, cv2.ROTATE_90_CLOCKWISE)
    return img


def load_for_analysis(path):
    """(colour image BGR at <= 1600 px, upright; EXIF bytes or None)."""
    img, exif = None, None
    if is_raw(path):
        import rawpy
        with rawpy.imread(path) as raw:
            flip = raw.sizes.flip
            try:
                thumb = raw.extract_thumb()
                if thumb.format == rawpy.ThumbFormat.JPEG:
                    data = bytes(thumb.data)
                    exif = _exif_from_jpeg(data)
                    # read the preview as stored, then turn it upright ourselves
                    pic = cv2.imdecode(np.frombuffer(data, np.uint8),
                                       cv2.IMREAD_COLOR | cv2.IMREAD_IGNORE_ORIENTATION)
                    if pic is not None and max(pic.shape[:2]) >= 1000:
                        img = _rotate_for_raw(pic, flip)
            except Exception:
                img = None
            if img is None:
                rgb = raw.postprocess(use_camera_wb=True, half_size=True, output_bps=8)
                img = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)       # postprocess is already upright
    else:
        data = np.fromfile(path, dtype=np.uint8)        # works with any characters in the path
        flag = cv2.IMREAD_REDUCED_COLOR_2 if data.size > 4_000_000 else cv2.IMREAD_COLOR
        img = cv2.imdecode(data, flag)                  # follows the EXIF orientation
        try:
            exif = _exif_from_jpeg(data.tobytes())
        except Exception:
            exif = None
    if img is None:
        return None, exif
    h, w = img.shape[:2]
    k = ANALYSIS_LONG_SIDE / float(max(h, w))
    if k < 1.0:
        img = cv2.resize(img, (int(w * k), int(h * k)), interpolation=cv2.INTER_AREA)
    return img, exif


def _exif_from_jpeg(data):
    try:
        from PIL import Image
        with Image.open(io.BytesIO(data)) as im:
            return im.info.get("exif")
    except Exception:
        return None


# ───────────────────────── measuring ─────────────────────────

def _lap_var(gray, mask=None):
    lap = cv2.Laplacian(gray, cv2.CV_32F)
    if mask is not None:
        vals = lap[mask]
        return float(vals.var()) if vals.size > 50 else 0.0
    return float(lap.var())


def _normalised(gray, mask=None):
    """Sharpness that does not change with brightness or contrast: the energy of the
    finest detail compared with the overall variation of that area."""
    g = gray.astype(np.float32)
    if mask is not None:
        vals = g[mask]
        if vals.size <= 50:
            return 0.0
        spread = float(vals.var())
    else:
        spread = float(g.var())
    return _lap_var(gray, mask) / (spread + 60.0) * 100.0


def _patch(gray, cx, cy, size):
    h, w = gray.shape[:2]
    half = max(4, int(size / 2))
    x0, y0 = max(0, int(cx - half)), max(0, int(cy - half))
    x1, y1 = min(w, int(cx + half)), min(h, int(cy + half))
    return gray[y0:y1, x0:x1]


def _face_sharpness(gray, face):
    """Sharpness of one face: the whole face, and its sharper eye."""
    x, y, fw, fh = face[:4]
    crop = gray[max(0, int(y)):int(y + fh), max(0, int(x)):int(x + fw)]
    if crop.size == 0:
        return 0.0, 0.0
    # compare faces of different sizes fairly: measure every face at the same width
    target = 160
    if crop.shape[1] > target:
        k = target / crop.shape[1]
        crop = cv2.resize(crop, (target, max(4, int(crop.shape[0] * k))), interpolation=cv2.INTER_AREA)
    face_score = _normalised(crop)
    eyes = []
    if fw >= 60:                                    # eyes are only measurable on bigger faces
        size = max(10, fw * 0.28)
        for ex, ey in ((face[4], face[5]), (face[6], face[7])):
            p = _patch(gray, ex, ey, size)
            if p.size:
                if p.shape[1] > 48:
                    p = cv2.resize(p, (48, 48), interpolation=cv2.INTER_AREA)
                eyes.append(_normalised(p))
    eye_score = max(eyes) if eyes else 0.0
    return face_score, eye_score


def analyze(path, use_faces=True):
    """Everything Focus Check needs to know about one photo."""
    result = {"score": 0.0, "subject": None, "faces": [], "behind": False,
              "shutter": None, "time": None}
    img, exif = load_for_analysis(path)
    meta = read_exif(exif)
    result["shutter"], result["time"] = meta.get("shutter"), meta.get("time")
    if img is None:
        return result
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    result["score"] = _lap_var(gray)                 # the whole-photo measure, as before
    if not (use_faces and face_finder_available()):
        return result
    try:
        h, w = gray.shape[:2]
        k = min(1.0, DETECT_LONG_SIDE / float(max(h, w)))
        small = cv2.resize(img, (int(w * k), int(h * k)), interpolation=cv2.INTER_AREA) if k < 1 else img
        det = _detector()
        det.setInputSize((small.shape[1], small.shape[0]))
        _n, found = det.detect(small)
    except Exception:
        return result
    if found is None or not len(found):
        return result
    faces = []
    for f in found:
        f = f.astype(np.float64)
        f[:14] /= k                                  # back to the 1600 px copy
        if f[14] < MIN_CONFIDENCE or f[2] < MIN_FACE:
            continue
        faces.append(f)
    if not faces:
        return result
    biggest = max(f[2] for f in faces)
    main = [f for f in faces if f[2] >= 0.45 * biggest]     # the subject, not the crowd behind
    best = None
    mask = np.ones(gray.shape, bool)
    for f in faces:
        x, y, fw, fh = f[:4]
        pad = 0.25
        mask[max(0, int(y - fh * pad)):int(y + fh * (1 + pad)),
             max(0, int(x - fw * pad)):int(x + fw * (1 + pad))] = False
    for f in main:
        face_score, eye_score = _face_sharpness(gray, f)
        subject = max(face_score, 0.5 * (face_score + eye_score)) if eye_score else face_score
        entry = {"box": [float(f[0] / w), float(f[1] / h), float(f[2] / w), float(f[3] / h)],
                 "score": round(subject, 2), "eye": round(eye_score, 2)}
        result["faces"].append(entry)
        if best is None or subject > best[0]:
            best = (subject, f)
    result["subject"] = round(best[0], 2)
    # is the background clearly sharper than the face? then focus landed behind the subject
    x, y, fw, fh = best[1][:4]
    face_native = _normalised(gray[max(0, int(y)):int(y + fh), max(0, int(x)):int(x + fw)])
    bg = _normalised(gray, mask)
    result["behind"] = bool(bg > BEHIND_RATIO * face_native and bg > 3.0)
    result["face_native"], result["background"] = round(face_native, 2), round(bg, 2)
    return result


# ───────────────────────── camera data ─────────────────────────

def read_exif(exif_bytes):
    out = {}
    if not exif_bytes:
        return out
    try:
        import piexif
        d = piexif.load(exif_bytes)
        ex = d.get("Exif", {})
        t = ex.get(piexif.ExifIFD.ExposureTime)
        if t and t[1]:
            out["shutter"] = Fraction(int(t[0]), int(t[1]))
        stamp = ex.get(piexif.ExifIFD.DateTimeOriginal) or d.get("0th", {}).get(piexif.ImageIFD.DateTime)
        if stamp:
            when = datetime.strptime(stamp.decode("ascii", "ignore").strip("\x00 "), "%Y:%m:%d %H:%M:%S")
            sub = ex.get(piexif.ExifIFD.SubSecTimeOriginal)
            seconds = when.timestamp()
            if sub:
                digits = "".join(ch for ch in sub.decode("ascii", "ignore") if ch.isdigit())
                if digits:
                    seconds += int(digits) / (10 ** len(digits))
            out["time"] = seconds
    except Exception:
        pass
    return out


def group_bursts(times, gap=BURST_GAP):
    """times: {path: seconds or None}. Returns lists of paths shot in quick series."""
    known = sorted((t, p) for p, t in times.items() if t is not None)
    groups, current, last = [], [], None
    for t, p in known:
        if last is not None and t - last <= gap:
            current.append(p)
        else:
            if len(current) > 1:
                groups.append(current)
            current = [p]
        last = t
    if len(current) > 1:
        groups.append(current)
    return groups


def calibrate(values, floor_sharp, floor_fix):
    """Limits relative to this shoot: (sharp_limit, fixable_limit)."""
    if not values:
        return floor_sharp, floor_fix
    s = sorted(values)
    n = len(s)
    return max(s[int(n * 0.60)], floor_sharp), max(s[int(n * 0.30)], floor_fix)
