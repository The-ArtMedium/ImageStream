"""Auto Neutral: one-click white balance that only acts when it is sure.

The colour of every bright, usable pixel is placed on a map of colour casts
(red-to-green against blue-to-green, on a log scale, where a colour cast simply moves
everything by the same amount). Groups of similar colour are found on that map.
Real light sources lie close to one line on it (from warm tungsten to cool shade),
while grass, red seats or a blue kit lie far from it. The brightest sizeable group
close to that line is taken as "white under this light", and the cast is removed.
If no group qualifies, nothing is changed and the reason is given.
"""
import cv2
import numpy as np

SIDE = 640


def _prepare(rgb8):
    h, w = rgb8.shape[:2]
    k = SIDE / float(max(h, w))
    img = cv2.resize(rgb8, (max(8, int(w * k)), max(8, int(h * k))), interpolation=cv2.INTER_AREA) if k < 1 else rgb8
    return img.astype(np.float32) / 255.0


def _dominant_colour_mask(img):
    """True where a pixel belongs to a big area of one strong colour (grass, seats, sky...)."""
    hsv = cv2.cvtColor(img, cv2.COLOR_RGB2HSV)            # H 0..360, S 0..1, V 0..1
    sat, val, hue = hsv[..., 1], hsv[..., 2], hsv[..., 0]
    coloured = (sat > 0.28) & (val > 0.08)
    mask = np.zeros(sat.shape, bool)
    if coloured.mean() < 0.05:
        return mask
    bins = (hue[coloured] / 15).astype(int) % 24
    counts = np.bincount(bins, minlength=24)
    total = sat.size
    for b in np.nonzero(counts > 0.08 * total)[0]:          # a hue that covers more than 8 % of the frame
        lo, hi = b * 15 - 15, b * 15 + 30
        in_hue = ((hue >= lo % 360) & (hue < hi % 360)) if lo >= 0 and hi <= 360 else \
                 ((hue >= lo % 360) | (hue < hi % 360))
        mask |= coloured & in_hue
    return cv2.dilate(mask.astype(np.uint8), np.ones((5, 5), np.uint8)).astype(bool)


def _normalise(v):
    v = np.asarray(v, np.float64)
    n = np.linalg.norm(v)
    return v / n if n > 0 else v


def _angle(u, v):
    u, v = _normalise(u), _normalise(v)
    return float(np.degrees(np.arccos(np.clip(np.dot(u, v), -1, 1))))


LOCUS_SLOPE = -1.6     # light sources from tungsten to shade lie near  v = -1.6 u  on the map
NEAR_LOCUS = 0.35
BIN = 0.04
SPAN = 1.6


def estimate(rgb8, faces=None):
    """rgb8: the photo (uint8 RGB) as it looks now.
    Returns dict(light=(r,g,b) or None, confidence 'high'|'medium'|'low', reason=str)."""
    img = _prepare(rgb8)
    lum = img.mean(axis=2)
    usable = (img.max(axis=2) < 0.97) & (img.min(axis=2) > 0.02) & (lum > 0.08)
    if usable.sum() < 500:
        return {"light": None, "confidence": "low", "reason": "No reliable neutral found: the photo is too dark or too blown out."}
    bright_limit = np.percentile(lum[usable], 40)
    cand = usable & (lum >= bright_limit)
    px = img[cand]
    w = lum[cand]
    u = np.log(px[:, 0] / px[:, 1])
    v = np.log(px[:, 2] / px[:, 1])
    n = int(2 * SPAN / BIN)
    iu = np.clip(((u + SPAN) / BIN).astype(int), 0, n - 1)
    iv = np.clip(((v + SPAN) / BIN).astype(int), 0, n - 1)
    hist = np.zeros((n, n), np.float32)
    np.add.at(hist, (iv, iu), w)
    hist = cv2.GaussianBlur(hist, (0, 0), 1.2)
    total = float(hist.sum())
    peaks = (hist == cv2.dilate(hist, np.ones((7, 7), np.uint8))) & (hist > 0)
    groups = []
    for pv, pu in zip(*np.nonzero(peaks)):
        near = (np.abs(iu - pu) <= 3) & (np.abs(iv - pv) <= 3)
        mass = float(w[near].sum()) / float(w.sum())
        if mass < 0.02:
            continue
        cu, cv_ = (pu + 0.5) * BIN - SPAN, (pv + 0.5) * BIN - SPAN
        dist = abs(cv_ - LOCUS_SLOPE * cu) / np.sqrt(1 + LOCUS_SLOPE ** 2)
        groups.append({"mass": mass, "dist": float(dist), "bright": float(np.mean(lum[cand][near])),
                       "rgb": px[near].mean(axis=0), "uv": (cu, cv_)})
    on_line = [g for g in groups if g["dist"] < NEAR_LOCUS]
    if not on_line:
        return {"light": None, "confidence": "low",
                "reason": "No reliable neutral found: no white or grey areas, only strong colours."}
    best = max(on_line, key=lambda g: (g["bright"], g["mass"]))
    others = [g for g in on_line if g is not best and g["mass"] > 0.5 * best["mass"]
              and np.hypot(g["uv"][0] - best["uv"][0], g["uv"][1] - best["uv"][1]) > 0.25]
    top = np.percentile(lum[usable], 75)
    if best["bright"] >= top and best["mass"] >= 0.05 and best["dist"] < 0.2 and not others:
        confidence, reason = "high", "found clear white or grey areas."
    else:
        confidence = "medium"
        reason = ("corrected for the main light; the light looks mixed." if others
                  else "found some white or grey areas.")
    return {"light": tuple(float(c) for c in _normalise(best["rgb"])), "confidence": confidence, "reason": reason}


def sliders_for(light_rgb, temperature, tint):
    """Temperature and tint (the app's own -100..100 scales) that make this light neutral,
    starting from the current ones. Mirrors the white balance step of the pipeline."""
    c = np.array(light_rgb, np.float32)
    c = c / max(float(c.max()), 1e-6) * 0.7                    # a light grey of that colour
    lab = cv2.cvtColor(c.reshape(1, 1, 3), cv2.COLOR_RGB2Lab)[0, 0]
    a0, b0 = float(lab[1]), float(lab[2])
    # the pipeline adds  b += t/50*15 ;  a += t/50*3 + tint/50*15   on top of the current values
    t = temperature - b0 * 50.0 / 15.0
    shift_a = a0 + (t - temperature) / 50.0 * 3.0
    n = tint - shift_a * 50.0 / 15.0
    return float(np.clip(t, -100, 100)), float(np.clip(n, -100, 100))


def skin_ok(rgb8, boxes):
    """True when the faces' skin still looks like skin (not grey, green or blue)."""
    if not boxes:
        return True
    h, w = rgb8.shape[:2]
    lab = cv2.cvtColor(rgb8, cv2.COLOR_RGB2Lab).astype(np.float32)
    good = 0
    for fx, fy, fw, fh in boxes:
        x0, y0 = int((fx + fw * 0.3) * w), int((fy + fh * 0.45) * h)        # cheeks and nose
        x1, y1 = int((fx + fw * 0.7) * w), int((fy + fh * 0.75) * h)
        patch = lab[y0:y1, x0:x1]
        if patch.size == 0:
            continue
        a, b = float(patch[..., 1].mean()) - 128, float(patch[..., 2].mean()) - 128
        hue = np.degrees(np.arctan2(b, a))
        if a > 2 and b > 2 and 15 <= hue <= 80:
            good += 1
    return good > 0
