from PySide6.QtWidgets import QLabel
from PySide6.QtCore import Qt, QRectF, QPointF, QEvent, Signal
from PySide6.QtGui import QPainter, QColor, QPen


class PreviewWidget(QLabel):
    def __init__(self):
        super().__init__()
        self.setAlignment(Qt.AlignCenter)
        self.setText("Preview Area")
        self.setStyleSheet("background-color: #222; color: white;")


class CropLabel(QLabel):
    """Preview that lets the user drag a crop rectangle over the photo.

    The selection is kept as fractions of the picture (x0, y0, x1, y1),
    so it works the same on the small preview and the full-size export."""

    zoomRequested = Signal(float, QPointF)   # factor, position of the pointer
    panned = Signal(float, float)            # pixels dragged
    doubleClicked = Signal(QPointF)
    clicked = Signal(QPointF)                # a click on the photo, without dragging

    def __init__(self, text=""):
        super().__init__(text)
        self._pan_from = None
        self._mode = None
        self.setMouseTracking(True)
        self.crop_mode = False
        self.aspect = None        # width / height, or None for free shape
        self.selection = None     # (x0, y0, x1, y1) in 0..1
        self._anchor = None

    def set_crop_mode(self, on):
        self.crop_mode = on
        self._anchor = None
        self.setCursor(Qt.CrossCursor if on else Qt.ArrowCursor)
        self.update()

    def image_rect(self):
        pm = self.pixmap()
        if pm is None or pm.isNull():
            return None
        w, h = pm.width(), pm.height()
        return QRectF((self.width() - w) / 2.0, (self.height() - h) / 2.0, w, h)

    def default_selection(self):
        """Biggest centred rectangle of the chosen shape."""
        r = self.image_rect()
        if r is None or not self.aspect:
            return (0.08, 0.08, 0.92, 0.92)     # a little inside, so the grips are easy to see
        w, h = r.width(), r.height()
        cw = min(w, h * self.aspect)
        ch = cw / self.aspect
        x0 = (w - cw) / 2.0 / w
        y0 = (h - ch) / 2.0 / h
        return (x0, y0, x0 + cw / w, y0 + ch / h)

    def _clamp(self, pos, r):
        return QPointF(min(max(pos.x(), r.left()), r.right()),
                       min(max(pos.y(), r.top()), r.bottom()))

    # ── the crop frame can be drawn, moved, and pulled by its corners and sides ──

    GRIP = 14      # how close (in pixels) the pointer must be to grab a corner or side

    def _sel_rect(self, r):
        x0, y0, x1, y1 = self.selection
        return QRectF(r.left() + x0 * r.width(), r.top() + y0 * r.height(),
                      (x1 - x0) * r.width(), (y1 - y0) * r.height())

    def _store(self, rect, r):
        self.selection = ((rect.left() - r.left()) / r.width(), (rect.top() - r.top()) / r.height(),
                          (rect.right() - r.left()) / r.width(), (rect.bottom() - r.top()) / r.height())
        self.update()

    def _zone(self, pos, r):
        """What the pointer would grab: a corner, a side, the frame itself, or nothing."""
        if not self.selection:
            return "new"
        sel = self._sel_rect(r)
        g = self.GRIP
        near_l, near_r = abs(pos.x() - sel.left()) <= g, abs(pos.x() - sel.right()) <= g
        near_t, near_b = abs(pos.y() - sel.top()) <= g, abs(pos.y() - sel.bottom()) <= g
        in_x = sel.left() - g <= pos.x() <= sel.right() + g
        in_y = sel.top() - g <= pos.y() <= sel.bottom() + g
        if in_x and in_y:
            if near_t and near_l: return "tl"
            if near_t and near_r: return "tr"
            if near_b and near_l: return "bl"
            if near_b and near_r: return "br"
            if near_l: return "l"
            if near_r: return "r"
            if near_t: return "t"
            if near_b: return "b"
            if sel.contains(pos): return "move"
        return "new"

    _CURSORS = {"tl": Qt.SizeFDiagCursor, "br": Qt.SizeFDiagCursor, "tr": Qt.SizeBDiagCursor,
                "bl": Qt.SizeBDiagCursor, "l": Qt.SizeHorCursor, "r": Qt.SizeHorCursor,
                "t": Qt.SizeVerCursor, "b": Qt.SizeVerCursor, "move": Qt.SizeAllCursor,
                "new": Qt.CrossCursor}

    def _draw_from_anchor(self, p, r):
        a = self._anchor
        dx, dy = p.x() - a.x(), p.y() - a.y()
        if self.aspect:
            sx = 1 if dx >= 0 else -1
            sy = 1 if dy >= 0 else -1
            room_x = (r.right() - a.x()) if sx > 0 else (a.x() - r.left())
            room_y = (r.bottom() - a.y()) if sy > 0 else (a.y() - r.top())
            w = min(abs(dx), room_x, room_y * self.aspect)
            dx, dy = sx * w, sy * w / self.aspect
        x0, x1 = sorted((a.x(), a.x() + dx))
        y0, y1 = sorted((a.y(), a.y() + dy))
        self._store(QRectF(x0, y0, x1 - x0, y1 - y0), r)

    def _pull_side(self, p, r):
        sel = QRectF(self._start_rect)
        side, small = self._mode, 12.0
        if side == "l":
            sel.setLeft(min(max(p.x(), r.left()), sel.right() - small))
        elif side == "r":
            sel.setRight(max(min(p.x(), r.right()), sel.left() + small))
        elif side == "t":
            sel.setTop(min(max(p.y(), r.top()), sel.bottom() - small))
        else:
            sel.setBottom(max(min(p.y(), r.bottom()), sel.top() + small))
        if self.aspect:      # keep the chosen shape: the other direction follows, centred
            start = self._start_rect
            if side in ("l", "r"):
                w = min(sel.width(), 2 * min(start.center().y() - r.top(), r.bottom() - start.center().y()) * self.aspect)
                h = w / self.aspect
                left = sel.right() - w if side == "l" else sel.left()
                sel = QRectF(left, start.center().y() - h / 2, w, h)
            else:
                h = min(sel.height(), 2 * min(start.center().x() - r.left(), r.right() - start.center().x()) / self.aspect)
                w = h * self.aspect
                top = sel.bottom() - h if side == "t" else sel.top()
                sel = QRectF(start.center().x() - w / 2, top, w, h)
        self._store(sel, r)

    def mousePressEvent(self, event):
        r = self.image_rect()
        if self.crop_mode and r is not None and event.button() == Qt.LeftButton:
            pos = event.position()
            self._mode = self._zone(pos, r)
            if self._mode == "new":
                self._anchor = self._clamp(pos, r)
            elif self._mode == "move":
                self._start_rect = self._sel_rect(r)
                self._grab = pos
            elif len(self._mode) == 2:          # a corner: redraw from the opposite corner
                sel = self._sel_rect(r)
                self._anchor = QPointF(sel.right() if "l" in self._mode else sel.left(),
                                       sel.bottom() if "t" in self._mode else sel.top())
            else:
                self._start_rect = self._sel_rect(r)
        elif not self.crop_mode and r is not None and event.button() == Qt.LeftButton:
            self._pan_from = event.position()
            self._press_at = event.position()
            self._dragged = False
        else:
            super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        r = self.image_rect()
        if not self.crop_mode and self._pan_from is not None:
            far = event.position() - self._press_at
            if not self._dragged and abs(far.x()) + abs(far.y()) < 5:
                return                      # still a click, not a drag
            if not self._dragged:
                self._dragged = True
                self.setCursor(Qt.ClosedHandCursor)
            d = event.position() - self._pan_from
            self._pan_from = event.position()
            self.panned.emit(d.x(), d.y())
            return
        if not (self.crop_mode and r is not None):
            return super().mouseMoveEvent(event)
        pos = event.position()
        mode = getattr(self, "_mode", None)
        if mode is None:                                            # just hovering
            self.setCursor(self._CURSORS[self._zone(pos, r)])       # show what can be grabbed
            return
        if mode == "move":
            sel = QRectF(self._start_rect)
            dx = min(max(pos.x() - self._grab.x(), r.left() - sel.left()), r.right() - sel.right())
            dy = min(max(pos.y() - self._grab.y(), r.top() - sel.top()), r.bottom() - sel.bottom())
            sel.translate(dx, dy)
            self._store(sel, r)
        elif mode in ("l", "r", "t", "b"):
            self._pull_side(self._clamp(pos, r), r)
        else:
            self._draw_from_anchor(self._clamp(pos, r), r)

    def mouseReleaseEvent(self, event):
        if self.crop_mode:
            self._anchor = None
            self._mode = None
            s = self.selection
            if s and (s[2] - s[0] < 0.03 or s[3] - s[1] < 0.03):
                self.selection = self.default_selection()   # a tap, not a drag
                self.update()
        elif self._pan_from is not None:
            self._pan_from = None
            self.setCursor(Qt.ArrowCursor)
            if not self._dragged:
                self.clicked.emit(event.position())
        else:
            super().mouseReleaseEvent(event)

    def mouseDoubleClickEvent(self, event):
        pass        # one click already zooms; a double-click must not zoom twice

    def wheelEvent(self, event):
        dy = event.angleDelta().y()
        if dy and not self.crop_mode:
            self.zoomRequested.emit(1.25 ** (dy / 120.0), event.position())
        event.accept()

    def event(self, e):
        # two-finger pinch on a Mac trackpad
        if e.type() == QEvent.NativeGesture:
            try:
                if e.gestureType() == Qt.ZoomNativeGesture and not self.crop_mode:
                    self.zoomRequested.emit(1.0 + float(e.value()), e.position())
                    return True
            except Exception:
                pass
        return super().event(e)

    def paintEvent(self, event):
        super().paintEvent(event)
        r = self.image_rect()
        if not (self.crop_mode and self.selection and r is not None):
            return
        x0, y0, x1, y1 = self.selection
        sel = QRectF(r.left() + x0 * r.width(), r.top() + y0 * r.height(),
                     (x1 - x0) * r.width(), (y1 - y0) * r.height())
        p = QPainter(self)
        shade = QColor(0, 0, 0, 150)
        p.fillRect(QRectF(r.left(), r.top(), r.width(), sel.top() - r.top()), shade)
        p.fillRect(QRectF(r.left(), sel.bottom(), r.width(), r.bottom() - sel.bottom()), shade)
        p.fillRect(QRectF(r.left(), sel.top(), sel.left() - r.left(), sel.height()), shade)
        p.fillRect(QRectF(sel.right(), sel.top(), r.right() - sel.right(), sel.height()), shade)
        p.setPen(QPen(QColor("#f5a623"), 2))
        p.drawRect(sel)
        p.setBrush(QColor("#f5a623"))
        for hx in (sel.left(), sel.center().x(), sel.right()):       # grips: corners and sides
            for hy in (sel.top(), sel.center().y(), sel.bottom()):
                if not (hx == sel.center().x() and hy == sel.center().y()):
                    p.drawRect(QRectF(hx - 5, hy - 5, 10, 10))
        p.setBrush(Qt.NoBrush)
        p.setPen(QPen(QColor(255, 255, 255, 110), 1))
        for i in (1, 2):   # rule-of-thirds guides
            p.drawLine(QPointF(sel.left() + sel.width() * i / 3, sel.top()),
                       QPointF(sel.left() + sel.width() * i / 3, sel.bottom()))
            p.drawLine(QPointF(sel.left(), sel.top() + sel.height() * i / 3),
                       QPointF(sel.right(), sel.top() + sel.height() * i / 3))
        p.end()
