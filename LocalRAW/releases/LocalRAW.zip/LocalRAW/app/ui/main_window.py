import os
import numpy as np

from PySide6.QtWidgets import (
    QMainWindow, QWidget, QHBoxLayout,
    QVBoxLayout, QPushButton, QFileDialog,
    QLabel, QScrollArea, QGridLayout,
    QSlider, QGroupBox, QMessageBox,
    QSizePolicy, QInputDialog, QLineEdit,
    QDialog, QFormLayout, QDialogButtonBox,
    QComboBox, QTextEdit, QApplication
)
from PySide6.QtGui import QPixmap, QImage, QColor, QPainter, QKeySequence, QShortcut
from PySide6.QtCore import Qt, QTimer

from app.ui.preview_widget import CropLabel
from app.core.pipeline import Pipeline
from app.core.exporter import Exporter
from app.core.raw_loader import RawLoader
from app.core.batch_renamer import BatchRenamer
from app.core.watermarker import Watermarker
from app.core.metadata_editor import MetadataEditor
from app.utils.file_utils import get_files_in_folder, is_raw
from app.utils.image_utils import numpy_to_pixmap, resize_for_preview


PREVIEW_MAX = 1200


THUMB_SIZE = 150


def _rgb_to_pixmap(rgb):
    rgb = np.ascontiguousarray(rgb)
    h, w, _ = rgb.shape
    image = QImage(rgb.data, w, h, 3 * w, QImage.Format_RGB888).copy()
    return QPixmap.fromImage(image)


def _placeholder_pixmap(name):
    pixmap = QPixmap(THUMB_SIZE, THUMB_SIZE)
    pixmap.fill(QColor("#2a2a2a"))
    painter = QPainter(pixmap)
    painter.setPen(QColor("#bbbbbb"))
    painter.drawText(pixmap.rect(), Qt.AlignCenter | Qt.TextWordWrap, name)
    painter.end()
    return pixmap


def make_thumbnail(file_path):
    """Return a small preview for any supported file. RAW files use the camera's
    embedded preview (fast); if that is missing, a quick half-size render is used.
    A file that cannot be previewed gets a labelled placeholder instead of vanishing."""
    name = os.path.basename(file_path)
    pixmap = QPixmap()
    try:
        if is_raw(file_path):
            import rawpy
            with rawpy.imread(file_path) as raw:
                try:
                    thumb = raw.extract_thumb()
                    if thumb.format == rawpy.ThumbFormat.JPEG:
                        pixmap.loadFromData(thumb.data)
                    elif thumb.format == rawpy.ThumbFormat.BITMAP:
                        pixmap = _rgb_to_pixmap(thumb.data)
                except Exception:
                    pixmap = QPixmap()
                if pixmap.isNull():
                    rgb = raw.postprocess(half_size=True, use_camera_wb=True)
                    pixmap = _rgb_to_pixmap(rgb)
        else:
            pixmap = QPixmap(file_path)
    except Exception:
        pixmap = QPixmap()
    if pixmap.isNull():
        return _placeholder_pixmap(name)
    return pixmap.scaled(THUMB_SIZE, THUMB_SIZE, Qt.KeepAspectRatio, Qt.SmoothTransformation)



class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("LocalRAW v1.2.0")
        self.setMinimumSize(1000, 600)

        self.pipeline = Pipeline()
        self.exporter = Exporter()
        self.raw_loader = RawLoader()
        self.batch_renamer = BatchRenamer()
        self.watermarker = Watermarker()
        self.metadata_editor = MetadataEditor()

        self.current_image = None
        self.current_file_path = None
        self.preview_image = None
        self.image_files = []

        self._preview_timer = QTimer()
        self._preview_timer.setSingleShot(True)
        self._preview_timer.setInterval(80)
        self._preview_timer.timeout.connect(self.apply_pipeline)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QHBoxLayout()
        central_widget.setLayout(main_layout)

        # ===== LEFT PANEL
        left_layout = QVBoxLayout()
        self.import_button = QPushButton("Import Folder")
        self.import_button.clicked.connect(self.import_folder)
        self.status_label = QLabel("No folder loaded")
        left_layout.addWidget(self.import_button)
        left_layout.addWidget(self.status_label)

        self.scroll_area = QScrollArea()
        self.scroll_widget = QWidget()
        self.grid_layout = QGridLayout()
        self.scroll_widget.setLayout(self.grid_layout)
        self.scroll_area.setWidget(self.scroll_widget)
        self.scroll_area.setWidgetResizable(True)
        left_layout.addWidget(self.scroll_area)

        # Tools row
        tools_layout = QVBoxLayout()
        self.batch_rename_button = QPushButton("Batch Rename")
        self.batch_rename_button.clicked.connect(self.open_batch_rename)
        self.metadata_button = QPushButton("Metadata")
        self.metadata_button.clicked.connect(self.open_metadata)
        tools_layout.addWidget(self.batch_rename_button)
        tools_layout.addWidget(self.metadata_button)
        left_layout.addLayout(tools_layout)

        # ===== CENTER PANEL
        self.preview_label = CropLabel("Open a folder and select an image")
        self.preview_label.setAlignment(Qt.AlignCenter)
        self.preview_label.setStyleSheet("background-color: #1a1a1a; color: #555;")
        self.preview_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        # ===== RIGHT PANEL
        right_layout = QVBoxLayout()

        # Rotate & Straighten
        rot_group = QGroupBox("Rotate && Straighten")
        rot_buttons = QHBoxLayout()
        self.rotate_left_button = QPushButton("\u21ba 90\u00b0")
        self.rotate_right_button = QPushButton("\u21bb 90\u00b0")
        self.flip_button = QPushButton("Flip")
        self.rotate_left_button.clicked.connect(lambda: self.rotate_image(-1))
        self.rotate_right_button.clicked.connect(lambda: self.rotate_image(1))
        self.flip_button.clicked.connect(self.flip_image)
        rot_buttons.addWidget(self.rotate_left_button)
        rot_buttons.addWidget(self.rotate_right_button)
        rot_buttons.addWidget(self.flip_button)
        self.straighten_slider = self._make_slider(-150, 150, 0)
        self.straighten_label = QLabel("Straighten: 0.0\u00b0")
        rot_layout = QVBoxLayout()
        rot_layout.addLayout(rot_buttons)
        rot_layout.addWidget(self.straighten_label)
        rot_layout.addWidget(self.straighten_slider)
        rot_group.setLayout(rot_layout)

        # White Balance
        wb_group = QGroupBox("White Balance")
        self.temp_slider = self._make_slider(-50, 50, 0)
        self.tint_slider = self._make_slider(-50, 50, 0)
        wb_layout = QVBoxLayout()
        wb_layout.addWidget(QLabel("Temperature"))
        wb_layout.addWidget(self.temp_slider)
        wb_layout.addWidget(QLabel("Tint"))
        wb_layout.addWidget(self.tint_slider)
        wb_group.setLayout(wb_layout)

        # Tone
        tone_group = QGroupBox("Tone")
        self.exposure_slider = self._make_slider(-30, 30, 0)
        self.contrast_slider = self._make_slider(-50, 50, 0)
        tone_layout = QVBoxLayout()
        tone_layout.addWidget(QLabel("Exposure"))
        tone_layout.addWidget(self.exposure_slider)
        tone_layout.addWidget(QLabel("Contrast"))
        tone_layout.addWidget(self.contrast_slider)
        tone_group.setLayout(tone_layout)

        # Detail
        detail_group = QGroupBox("Detail")
        self.sharpen_slider = self._make_slider(0, 20, 0)
        detail_layout = QVBoxLayout()
        detail_layout.addWidget(QLabel("Sharpen"))
        detail_layout.addWidget(self.sharpen_slider)
        detail_group.setLayout(detail_layout)

        # Noise Reduction
        nr_group = QGroupBox("Noise Reduction")
        self.nr_lum_slider = self._make_slider(0, 100, 0)
        self.nr_color_slider = self._make_slider(0, 100, 0)
        nr_layout = QVBoxLayout()
        nr_layout.addWidget(QLabel("Luminance"))
        nr_layout.addWidget(self.nr_lum_slider)
        nr_layout.addWidget(QLabel("Color"))
        nr_layout.addWidget(self.nr_color_slider)
        nr_group.setLayout(nr_layout)

        # Dehaze
        dehaze_group = QGroupBox("Dehaze")
        self.dehaze_slider = self._make_slider(0, 100, 0)
        dehaze_layout = QVBoxLayout()
        dehaze_layout.addWidget(QLabel("Amount"))
        dehaze_layout.addWidget(self.dehaze_slider)
        dehaze_group.setLayout(dehaze_layout)

        # Watermark
        wm_group = QGroupBox("Watermark")
        self.watermark_button = QPushButton("Add Watermark...")
        self.watermark_button.clicked.connect(self.open_watermark)
        wm_layout = QVBoxLayout()
        wm_layout.addWidget(self.watermark_button)
        wm_group.setLayout(wm_layout)

        # Reset + Export
        self.reset_button = QPushButton("Reset All")
        self.reset_button.clicked.connect(self.reset_sliders)
        self.export_button = QPushButton("Export Image")
        self.export_button.clicked.connect(self.export_image)

        # Crop
        crop_group = QGroupBox("Crop")
        self.crop_shape = QComboBox()
        for name, value in [("Free shape", None), ("Original shape", "orig"), ("Square 1:1", 1.0),
                            ("Portrait 4:5", 4 / 5), ("Photo 3:2", 3 / 2), ("Photo 2:3", 2 / 3),
                            ("Wide 16:9", 16 / 9), ("Tall 9:16", 9 / 16)]:
            self.crop_shape.addItem(name, value)
        self.crop_shape.currentIndexChanged.connect(self.crop_shape_changed)
        self.crop_button = QPushButton("\u2702  Crop")
        self.crop_button.clicked.connect(self.toggle_crop)
        self.crop_cancel_button = QPushButton("Cancel")
        self.crop_cancel_button.clicked.connect(self.cancel_crop)
        self.crop_cancel_button.setVisible(False)
        self.crop_clear_button = QPushButton("Remove Crop")
        self.crop_clear_button.clicked.connect(self.clear_crop)
        self.crop_hint = QLabel("")
        self.crop_hint.setWordWrap(True)
        self.crop_hint.setStyleSheet("color: #f5a623;")
        crop_row = QHBoxLayout()
        crop_row.addWidget(self.crop_button)
        crop_row.addWidget(self.crop_cancel_button)
        crop_layout = QVBoxLayout()
        crop_layout.addWidget(self.crop_shape)
        crop_layout.addLayout(crop_row)
        crop_layout.addWidget(self.crop_clear_button)
        crop_layout.addWidget(self.crop_hint)
        crop_group.setLayout(crop_layout)

        right_layout.addWidget(crop_group)
        right_layout.addWidget(rot_group)
        right_layout.addWidget(wb_group)
        right_layout.addWidget(tone_group)
        right_layout.addWidget(detail_group)
        right_layout.addWidget(nr_group)
        right_layout.addWidget(dehaze_group)
        right_layout.addWidget(wm_group)
        right_layout.addStretch()

        main_layout.addLayout(left_layout, 3)
        center_layout = QVBoxLayout()
        top_bar = QHBoxLayout()
        self.prev_button = QPushButton("\u25c0  Previous")
        self.next_button = QPushButton("Next  \u25b6")
        self.delete_button = QPushButton("\U0001F5D1  Delete")
        self.delete_button.setToolTip("Move this photo to the Trash (Delete key)")
        self.delete_button.setStyleSheet("QPushButton { color: #ff8a80; font-weight: bold; }")
        self.prev_button.clicked.connect(lambda: self.show_neighbor(-1))
        self.next_button.clicked.connect(lambda: self.show_neighbor(1))
        self.delete_button.clicked.connect(self.delete_current_photo)
        self.info_label = QLabel("")
        self.info_label.setAlignment(Qt.AlignCenter)
        self.info_label.setStyleSheet("color: #f5a623; font-weight: bold; padding: 4px;")
        top_bar.addWidget(self.prev_button)
        top_bar.addWidget(self.info_label, 1)
        top_bar.addWidget(self.next_button)
        top_bar.addWidget(self.delete_button)
        center_layout.addLayout(top_bar)
        center_layout.addWidget(self.preview_label, 1)
        main_layout.addLayout(center_layout, 6)
        screen = QApplication.primaryScreen()
        if screen is not None:
            area = screen.availableGeometry()
            self.resize(min(1400, area.width() - 40), min(850, area.height() - 60))
        right_widget = QWidget()
        right_widget.setLayout(right_layout)
        right_scroll = QScrollArea()
        right_scroll.setWidget(right_widget)
        right_scroll.setWidgetResizable(True)
        right_scroll.setMinimumWidth(300)
        right_outer = QVBoxLayout()
        right_outer.addWidget(right_scroll, 1)
        # Reset and Export stay pinned at the bottom, always visible
        right_outer.addWidget(self.reset_button)
        right_outer.addWidget(self.export_button)
        main_layout.addLayout(right_outer, 3)

        # Keyboard: Delete / Backspace moves the current photo to the Trash
        QShortcut(QKeySequence(Qt.Key_Delete), self, activated=self.delete_current_photo)
        QShortcut(QKeySequence(Qt.Key_Left), self, activated=lambda: self.show_neighbor(-1))
        QShortcut(QKeySequence(Qt.Key_Right), self, activated=lambda: self.show_neighbor(1))

    # ─────────────────────────────────────────────────

    def _make_slider(self, min_val, max_val, default):
        slider = QSlider(Qt.Horizontal)
        slider.setRange(min_val, max_val)
        slider.setValue(default)
        slider.valueChanged.connect(self._on_slider_changed)
        return slider

    def _on_slider_changed(self):
        self._preview_timer.start()

    # ─────────────────────────────────────────────────

    def import_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Select Folder")
        if folder:
            self.image_files = get_files_in_folder(folder)
            self.status_label.setText(f"{len(self.image_files)} images found")
            self.display_thumbnails()

    def display_thumbnails(self):
        for i in reversed(range(self.grid_layout.count())):
            widget = self.grid_layout.itemAt(i).widget()
            if widget:
                widget.setParent(None)

        self.thumb_labels = {}
        row, col = 0, 0
        for file_path in self.image_files:
            pixmap = make_thumbnail(file_path)
            label = QLabel()
            label.setPixmap(pixmap)
            label.setCursor(Qt.PointingHandCursor)
            label.setToolTip(os.path.basename(file_path))
            label.setStyleSheet("border: 3px solid transparent;")
            self.thumb_labels[file_path] = label
            label.mousePressEvent = lambda event, path=file_path: self.load_image(path)
            self.grid_layout.addWidget(label, row, col)
            col += 1
            if col > 1:
                col = 0
                row += 1

    # ─────────────────────────────────────────────────

    def load_image(self, file_path):
        try:
            image = self.raw_loader.load_image(file_path)
        except Exception as e:
            QMessageBox.critical(self, "Load Error", str(e))
            return
        if image is None:
            return
        self.current_image = image
        self.current_file_path = file_path
        self.preview_image = resize_for_preview(image, max_size=PREVIEW_MAX)
        # a new photo starts upright; rotation and straightening belong to one photo
        self.pipeline.rotation = 0
        self.pipeline.flip = False
        self.pipeline.crop = None
        self._end_crop_mode()
        self.highlight_current()
        self.straighten_slider.blockSignals(True)
        self.straighten_slider.setValue(0)
        self.straighten_slider.blockSignals(False)
        self.apply_pipeline()

    # ─────────────────────────────────────────────────

    def update_pipeline_values(self):
        self.pipeline.temperature = self.temp_slider.value()
        self.pipeline.tint = self.tint_slider.value()
        self.pipeline.exposure = self.exposure_slider.value() / 10.0
        self.pipeline.contrast = self.contrast_slider.value()
        self.pipeline.sharpen_amount = self.sharpen_slider.value() / 10.0
        self.pipeline.nr_luminance = self.nr_lum_slider.value() / 100.0
        self.pipeline.nr_color = self.nr_color_slider.value() / 100.0
        self.pipeline.dehaze = self.dehaze_slider.value() / 100.0
        self.pipeline.straighten = self.straighten_slider.value() / 10.0
        self.straighten_label.setText(f"Straighten: {self.pipeline.straighten:+.1f}\u00b0")

    def apply_pipeline(self):
        if self.preview_image is None:
            return
        self.update_pipeline_values()
        # while the crop frame is being drawn, show the whole photo
        processed = self.pipeline.apply(self.preview_image, use_crop=not self.preview_label.crop_mode)
        pixmap = numpy_to_pixmap(processed)
        self.preview_label.setPixmap(
            pixmap.scaled(self.preview_label.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
        )

    # ─────────────────────────────────────────────────

    def reset_sliders(self):
        for slider in [
            self.temp_slider, self.tint_slider,
            self.exposure_slider, self.contrast_slider,
            self.sharpen_slider, self.nr_lum_slider,
            self.nr_color_slider, self.dehaze_slider,
            self.straighten_slider
        ]:
            slider.blockSignals(True)
            slider.setValue(0)
            slider.blockSignals(False)
        self.pipeline.reset()
        self._end_crop_mode()
        self.apply_pipeline()

    # ─────────────────────────────────────────────────

    def highlight_current(self):
        """Light up the thumbnail being edited and say which photo it is."""
        labels = getattr(self, "thumb_labels", {})
        for path, label in labels.items():
            label.setStyleSheet(
                "border: 3px solid #f5a623;" if path == self.current_file_path
                else "border: 3px solid transparent;"
            )
        if self.current_file_path in labels:
            self.scroll_area.ensureWidgetVisible(labels[self.current_file_path])
        if self.current_file_path and self.current_file_path in self.image_files:
            position = self.image_files.index(self.current_file_path) + 1
            self.info_label.setText(
                f"{os.path.basename(self.current_file_path)}   \u00b7   {position} of {len(self.image_files)}"
            )
        else:
            self.info_label.setText("")

    def show_neighbor(self, step):
        if not self.image_files:
            return
        if self.current_file_path in self.image_files:
            index = self.image_files.index(self.current_file_path) + step
        else:
            index = 0
        if 0 <= index < len(self.image_files):
            self.load_image(self.image_files[index])

    # ─────────────────────────────────────────────────

    def _crop_aspect(self):
        value = self.crop_shape.currentData()
        if value == "orig":
            r = self.preview_label.image_rect()
            return (r.width() / r.height()) if r is not None and r.height() else None
        return value

    def _end_crop_mode(self):
        self.preview_label.set_crop_mode(False)
        self.crop_button.setText("\u2702  Crop")
        self.crop_cancel_button.setVisible(False)
        self.crop_hint.setText("")

    def toggle_crop(self):
        if self.preview_image is None:
            return
        label = self.preview_label
        if not label.crop_mode:
            # start: show the whole photo with a frame on it
            label.crop_mode = True
            self.apply_pipeline()
            label.aspect = self._crop_aspect()
            label.selection = self.pipeline.crop or label.default_selection()
            label.set_crop_mode(True)
            self.crop_button.setText("\u2713  Apply Crop")
            self.crop_cancel_button.setVisible(True)
            self.crop_hint.setText("Drag on the photo to draw the frame, then press Apply Crop.")
        else:
            sel = label.selection
            full = sel is None or (sel[0] <= 0.001 and sel[1] <= 0.001 and sel[2] >= 0.999 and sel[3] >= 0.999)
            self.pipeline.crop = None if full else sel
            self._end_crop_mode()
            self.apply_pipeline()

    def cancel_crop(self):
        self._end_crop_mode()
        self.apply_pipeline()

    def clear_crop(self):
        self.pipeline.crop = None
        self._end_crop_mode()
        self.apply_pipeline()

    def crop_shape_changed(self):
        label = self.preview_label
        if label.crop_mode:
            label.aspect = self._crop_aspect()
            label.selection = label.default_selection()
            label.update()

    def rotate_image(self, direction):
        if self.preview_image is None:
            return
        self.pipeline.rotation = (self.pipeline.rotation + direction) % 4
        self.pipeline.crop = None      # the frame no longer fits a turned photo
        self._end_crop_mode()
        self.apply_pipeline()

    def flip_image(self):
        if self.preview_image is None:
            return
        self.pipeline.flip = not self.pipeline.flip
        if self.pipeline.crop:
            x0, y0, x1, y1 = self.pipeline.crop
            self.pipeline.crop = (1 - x1, y0, 1 - x0, y1)
        self.apply_pipeline()

    # ─────────────────────────────────────────────────

    def delete_current_photo(self):
        path = self.current_file_path
        if not path:
            QMessageBox.information(self, "Delete Photo", "Click a photo first, then delete it.")
            return
        name = os.path.basename(path)
        answer = QMessageBox.question(
            self, "Delete Photo",
            f"Move '{name}' to the Trash?\n\nYou can restore it from the Trash if you change your mind.",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if answer != QMessageBox.Yes:
            return
        try:
            from send2trash import send2trash
            send2trash(path)
        except Exception as e:
            QMessageBox.critical(self, "Delete Photo", f"Could not move the photo to the Trash.\n\n{e}")
            return
        index = self.image_files.index(path) if path in self.image_files else 0
        if path in self.image_files:
            self.image_files.remove(path)
        self.current_image = None
        self.current_file_path = None
        self.preview_image = None
        self.preview_label.clear()
        self.preview_label.setText("Photo moved to the Trash")
        self.status_label.setText(f"{len(self.image_files)} images found")
        self.display_thumbnails()
        self.highlight_current()
        if self.image_files:
            self.load_image(self.image_files[min(index, len(self.image_files) - 1)])

    # ─────────────────────────────────────────────────

    def export_image(self):
        if self.current_image is None:
            QMessageBox.warning(self, "Export", "No image loaded.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Export Image", "", "JPEG (*.jpg);;PNG (*.png)"
        )
        if path:
            self.update_pipeline_values()
            processed = self.pipeline.apply(self.current_image)
            self.exporter.save(processed, path)
            QMessageBox.information(self, "Export", "Image exported successfully.")

    # ─────────────────────────────────────────────────

    def open_batch_rename(self):
        if not self.image_files:
            QMessageBox.warning(self, "Batch Rename", "No folder loaded.")
            return

        dialog = QDialog(self)
        dialog.setWindowTitle("Batch Rename")
        dialog.setMinimumWidth(500)
        layout = QFormLayout()

        pattern_input = QLineEdit("{prefix}_{date}_{n}")
        prefix_input = QLineEdit()
        preview_box = QTextEdit()
        preview_box.setReadOnly(True)
        preview_box.setMaximumHeight(200)

        def update_preview():
            results = self.batch_renamer.preview(
                self.image_files,
                pattern_input.text(),
                prefix_input.text()
            )
            lines = [f"{os.path.basename(old)} → {new}" for old, new in results[:10]]
            if len(self.image_files) > 10:
                lines.append(f"... and {len(self.image_files) - 10} more")
            preview_box.setText("\n".join(lines))

        pattern_input.textChanged.connect(update_preview)
        prefix_input.textChanged.connect(update_preview)

        layout.addRow("Pattern:", pattern_input)
        layout.addRow("Prefix:", prefix_input)
        layout.addRow("Preview:", preview_box)

        hint = QLabel("Tokens: {name} {n} {date} {prefix} {ext}")
        hint.setStyleSheet("color: #888; font-size: 11px;")
        layout.addRow(hint)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addRow(buttons)

        dialog.setLayout(layout)
        update_preview()

        if dialog.exec() == QDialog.Accepted:
            results = self.batch_renamer.execute(
                self.image_files,
                pattern_input.text(),
                prefix_input.text()
            )
            success = sum(1 for _, _, ok, _ in results if ok)
            failed = [(old, err) for old, _, ok, err in results if not ok]

            msg = f"{success} files renamed successfully."
            if failed:
                msg += f"\n{len(failed)} failed."
            QMessageBox.information(self, "Batch Rename", msg)
            self.import_folder()

    # ─────────────────────────────────────────────────

    def open_watermark(self):
        if self.current_image is None:
            QMessageBox.warning(self, "Watermark", "No image loaded.")
            return

        dialog = QDialog(self)
        dialog.setWindowTitle("Add Watermark")
        layout = QFormLayout()

        text_input = QLineEdit("© Your Name")
        position_combo = QComboBox()
        position_combo.addItems(self.watermarker.POSITIONS)
        position_combo.setCurrentText("bottom_right")

        opacity_slider = QSlider(Qt.Horizontal)
        opacity_slider.setRange(10, 100)
        opacity_slider.setValue(60)

        layout.addRow("Text:", text_input)
        layout.addRow("Position:", position_combo)
        layout.addRow("Opacity:", opacity_slider)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addRow(buttons)
        dialog.setLayout(layout)

        if dialog.exec() == QDialog.Accepted:
            self.update_pipeline_values()
            processed = self.pipeline.apply(self.current_image)
            watermarked = self.watermarker.apply_text(
                processed,
                text=text_input.text(),
                position=position_combo.currentText(),
                opacity=opacity_slider.value() / 100.0
            )
            path, _ = QFileDialog.getSaveFileName(
                self, "Export Watermarked Image", "", "JPEG (*.jpg);;PNG (*.png)"
            )
            if path:
                self.exporter.save(watermarked, path)
                QMessageBox.information(self, "Watermark", "Watermarked image exported.")

    # ─────────────────────────────────────────────────

    def open_metadata(self):
        if not self.current_file_path:
            QMessageBox.warning(self, "Metadata", "No image loaded.")
            return

        dialog = QDialog(self)
        dialog.setWindowTitle("Metadata Editor")
        dialog.setMinimumWidth(480)
        layout = QFormLayout()

        summary = self.metadata_editor.summary(self.current_file_path)
        exif_box = QTextEdit(summary)
        exif_box.setReadOnly(True)
        exif_box.setMaximumHeight(180)

        artist_input = QLineEdit()
        copyright_input = QLineEdit()
        description_input = QLineEdit()

        layout.addRow("EXIF Data:", exif_box)
        layout.addRow("Artist:", artist_input)
        layout.addRow("Copyright:", copyright_input)
        layout.addRow("Description:", description_input)

        note = QLabel("Changes are written to exported JPEG files only.")
        note.setStyleSheet("color: #888; font-size: 11px;")
        layout.addRow(note)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addRow(buttons)
        dialog.setLayout(layout)

        if dialog.exec() == QDialog.Accepted:
            ext = os.path.splitext(self.current_file_path)[1].lower()
            if ext not in [".jpg", ".jpeg"]:
                QMessageBox.information(self, "Metadata", "Metadata writing is only supported for JPEG files.\nExport as JPEG first.")
                return
            try:
                self.metadata_editor.write(
                    self.current_file_path,
                    artist=artist_input.text(),
                    copyright=copyright_input.text(),
                    description=description_input.text()
                )
                QMessageBox.information(self, "Metadata", "Metadata saved successfully.")
            except Exception as e:
                QMessageBox.critical(self, "Metadata Error", str(e))
