import os
import numpy as np
import cv2

from PySide6.QtWidgets import (
    QMainWindow, QWidget, QHBoxLayout,
    QVBoxLayout, QPushButton, QFileDialog,
    QLabel, QScrollArea, QGridLayout,
    QSlider, QGroupBox, QMessageBox,
    QSizePolicy, QInputDialog, QLineEdit,
    QDialog, QFormLayout, QDialogButtonBox,
    QComboBox, QTextEdit, QApplication, QSpinBox, QCheckBox, QProgressDialog
)
from PySide6.QtGui import (QDesktopServices, QPixmap, QImage, QColor, QPainter, QKeySequence, QShortcut,
                           QImageReader, QImageIOHandler, QTransform)
from PySide6.QtCore import Qt, QTimer, QThread, Signal, QBuffer, QByteArray, QIODevice, QUrl, QSettings
import json

from app.ui.preview_widget import CropLabel
from app.ui.export_dialog import ExportDialog, name_for
from app.core import focus_check
from app.core import subject_focus
from app.core import auto_neutral
from app.core import denoise
from app.core.pipeline import Pipeline
from app.core.exporter import Exporter, camera_exif, with_meta
from app.core.raw_loader import RawLoader
from app.core.batch_renamer import BatchRenamer
from app.core.watermarker import Watermarker
from app.core.metadata_editor import MetadataEditor
from app.utils.file_utils import get_files_in_folder, is_raw
from app.utils.image_utils import numpy_to_pixmap, resize_for_preview


PREVIEW_MAX = 1200


THUMB_H = 124                 # thumbnails fill the strip; each keeps its own shape (up to 16:9 wide)
THUMB_W = 220
THUMB_SIZE = THUMB_W          # kept for older code that asks for one size
THUMB_FRAME = "background: #1b1b1b; border-radius: 4px; "


def _rgb_to_pixmap(rgb):
    rgb = np.ascontiguousarray(rgb)
    h, w, _ = rgb.shape
    image = QImage(rgb.data, w, h, 3 * w, QImage.Format_RGB888).copy()
    return QPixmap.fromImage(image)


def _placeholder_pixmap(name):
    pixmap = QPixmap(THUMB_W, THUMB_H)
    pixmap.fill(QColor("#2a2a2a"))
    painter = QPainter(pixmap)
    painter.setPen(QColor("#bbbbbb"))
    painter.drawText(pixmap.rect(), Qt.AlignCenter | Qt.TextWordWrap, name)
    painter.end()
    return pixmap


def _read_scaled(source):
    """Decode a picture straight to thumbnail size (fast even for huge JPEGs),
    upright according to its orientation tag. Returns (pixmap, was_rotated)."""
    reader = QImageReader(source)
    reader.setAutoTransform(True)
    rotated = reader.transformation() != QImageIOHandler.TransformationNone
    size = reader.size()
    if size.isValid() and (size.width() > THUMB_W * 2 or size.height() > THUMB_H * 2):
        size.scale(THUMB_W * 2, THUMB_H * 2, Qt.KeepAspectRatio)
        reader.setScaledSize(size)
    image = reader.read()
    return (QPixmap() if image.isNull() else QPixmap.fromImage(image)), rotated


def make_thumbnail(file_path):
    """Return a small preview for any supported file. RAW files use the camera's
    embedded preview (fast); if that is missing, a quick half-size render is used.
    A file that cannot be previewed gets a labelled placeholder instead of vanishing."""
    name = os.path.basename(file_path)
    pixmap = QPixmap()
    try:
        if is_raw(file_path):
            import rawpy
            with rawpy.imread(file_path) as raw:
                try:
                    thumb = raw.extract_thumb()
                    if thumb.format == rawpy.ThumbFormat.JPEG:
                        buffer = QBuffer()
                        buffer.setData(QByteArray(bytes(thumb.data)))
                        buffer.open(QIODevice.ReadOnly)
                        pixmap, rotated = _read_scaled(buffer)
                        # vertical shots: the preview may carry no orientation tag of its own
                        angle = {3: 180, 5: -90, 6: 90}.get(raw.sizes.flip, 0)
                        if angle and not rotated and not pixmap.isNull():
                            pixmap = pixmap.transformed(QTransform().rotate(angle))
                    elif thumb.format == rawpy.ThumbFormat.BITMAP:
                        pixmap = _rgb_to_pixmap(thumb.data)
                except Exception:
                    pixmap = QPixmap()
                if pixmap.isNull():
                    rgb = raw.postprocess(half_size=True, use_camera_wb=True)
                    pixmap = _rgb_to_pixmap(rgb)
        else:
            pixmap, _ = _read_scaled(file_path)
    except Exception:
        pixmap = QPixmap()
    if pixmap.isNull():
        return _placeholder_pixmap(name)
    return pixmap.scaled(THUMB_W, THUMB_H, Qt.KeepAspectRatio, Qt.SmoothTransformation)



APP_VERSION = "3.2"      # shown in the window title, so an old copy is easy to spot
def auto_tone_values(lum):
    """From the brightness of a photo (0..1): exposure in stops, then
    (highlights, shadows, whites, blacks), each -1..1."""
    hi = float(np.percentile(lum, 99.5))
    # an underexposed photo is first lifted so its brightest tones reach near white
    stops = min(2.5, max(0.0, float(np.log2(0.96 / max(hi, 0.02))))) if hi < 0.90 else 0.0
    lum = np.clip(lum * (2.0 ** stops), 0, 1)
    lo, hi = np.percentile(lum, 0.5), np.percentile(lum, 99.5)
    blacks = -min(1.0, lo / 0.12) if lo > 0.01 else 0.0          # darkest tones down to black
    whites = min(1.0, max(0.0, (1.0 - hi) / 0.20))               # brightest tones up to white
    black_point, white_point = -blacks * 0.12, 1.0 - whites * 0.20
    mid = (float(np.median(lum)) - black_point) / max(0.05, white_point - black_point)
    shadows = min(0.7, (0.32 - mid) / 0.32 * 1.2) if mid < 0.32 else 0.0      # dark photo: open it
    highlights = -min(0.6, (mid - 0.62) / 0.38) if mid > 0.62 else 0.0        # bright photo: hold it
    return stops, highlights, shadows, whites, blacks


# every slider: (name kept in the edits file, slider attribute, pipeline attribute, scale)
SLIDERS = [
    ("temperature", "temp_slider", "temperature", 1.0),
    ("tint", "tint_slider", "tint", 1.0),
    ("exposure", "exposure_slider", "exposure", 10.0),
    ("contrast", "contrast_slider", "contrast", 1.0),
    ("highlights", "highlights_slider", "highlights", 100.0),
    ("shadows", "shadows_slider", "shadows", 100.0),
    ("whites", "whites_slider", "whites", 100.0),
    ("blacks", "blacks_slider", "blacks", 100.0),
    ("saturation", "saturation_slider", "saturation", 100.0),
    ("sharpen", "sharpen_slider", "sharpen_amount", 10.0),
    ("nr_luminance", "nr_lum_slider", "nr_luminance", 100.0),
    ("nr_color", "nr_color_slider", "nr_color", 100.0),
    ("dehaze", "dehaze_slider", "dehaze", 100.0),
    ("straighten", "straighten_slider", "straighten", 10.0),
]
EDITS_FILE = ".localraw-edits.json"     # kept next to the photos; originals are never changed
SELECT_COLOR = "#4aa3ff"
STAR = "\u2605"


def settings_to_pipeline(settings, pipeline):
    """Put a photo's saved edits into a pipeline (used for preview and export alike)."""
    sliders = (settings or {}).get("sliders", {})
    for name, _attr, target, scale in SLIDERS:
        setattr(pipeline, target, sliders.get(name, 0) / scale)
    pipeline.rotation = int((settings or {}).get("rotation", 0)) % 4
    pipeline.flip = bool((settings or {}).get("flip", False))
    crop = (settings or {}).get("crop")
    pipeline.crop = tuple(crop) if crop else None
    return pipeline


def focus_peaking(rgb):
    """Paint the sharpest edges red: shows at a glance where the focus landed."""
    gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
    edges = np.abs(cv2.Laplacian(cv2.GaussianBlur(gray, (0, 0), 0.6), cv2.CV_32F))
    limit = max(28.0, float(np.percentile(edges, 97.5)))
    mask = edges >= limit
    if not mask.any():
        return rgb
    out = rgb.copy()
    out[mask] = (255, 40, 40)
    return out


FOCUS_COLORS = {"sharp": "#4caf50", "fixable": "#ffd54f", "rejected": "#ff6b6b"}
FOCUS_NAMES = {"sharp": "IN FOCUS", "fixable": "FIXABLE", "rejected": "REJECTED"}
SHOW_NAMES = {"sharp": "In focus", "fixable": "Fixable", "rejected": "Rejected"}


class FocusWorker(QThread):
    """Scores the whole folder in the background so the window stays usable."""
    progress = Signal(int, int)
    finished_scan = Signal(dict, bool)

    def __init__(self, files):
        super().__init__()
        self.files = list(files)

    def run(self):
        results = {}
        total = len(self.files)
        for i, path in enumerate(self.files, 1):
            if self.isInterruptionRequested():
                self.finished_scan.emit(results, False)
                return
            try:
                results[path] = subject_focus.analyze(path, use_faces=True)
            except Exception:
                results[path] = {"score": focus_check.score_image(path), "subject": None,
                                 "faces": [], "behind": False, "shutter": None, "time": None}
            self.progress.emit(i, total)
        self.finished_scan.emit(results, True)


class FilmStrip(QScrollArea):
    """Horizontal strip: the mouse wheel scrolls it sideways."""

    def wheelEvent(self, event):
        delta = event.angleDelta()
        step = delta.x() if abs(delta.x()) > abs(delta.y()) else delta.y()
        bar = self.horizontalScrollBar()
        bar.setValue(bar.value() - step)
        event.accept()


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle(f"LocalRAW {APP_VERSION}  \u2014  RAW + JPG editor with Focus Check")
        self.setMinimumSize(1220, 620)

        self.pipeline = Pipeline()
        self.exporter = Exporter()
        self.raw_loader = RawLoader()
        self.batch_renamer = BatchRenamer()
        self.watermarker = Watermarker()
        self.metadata_editor = MetadataEditor()

        self.current_image = None
        self.current_file_path = None
        self.preview_image = None
        self.image_files = []
        self.focus = {}             # Focus Check results per photo
        self.focus_limits = None
        self._focus_worker = None
        self._thumb_cache = {}
        self.folder = None
        self.edits = {}             # saved edits per photo: path -> settings
        self.selected = set()       # photos chosen for export or paste
        self.ratings = {}           # path -> 1..5 stars
        self.copied = None          # edits copied with Copy Edits
        self.saved_copies = {}      # original -> its saved finished copy
        self.saved_settings = {}    # original -> the edits it had when it was saved
        self._last_clicked = None
        self._edits_timer = QTimer()
        self._edits_timer.setSingleShot(True)
        self._edits_timer.setInterval(1200)
        self._edits_timer.timeout.connect(self._save_edits_file)
        self.zoom_scale = None      # None = fit the window; 1.0 = 100 %
        self.zoom_center = None     # point of the photo in the middle of the view
        self._view_origin = (0, 0)
        self._geo_cache = (None, None)

        self._preview_timer = QTimer()
        self._preview_timer.setSingleShot(True)
        self._preview_timer.setInterval(80)
        self._preview_timer.timeout.connect(self.apply_pipeline)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        window_layout = QVBoxLayout()
        window_layout.setContentsMargins(6, 6, 6, 6)
        window_layout.setSpacing(4)
        central_widget.setLayout(window_layout)
        main_layout = QHBoxLayout()
        window_layout.addLayout(main_layout, 1)

        # ===== LEFT PANEL
        left_layout = QVBoxLayout()
        self.import_button = QPushButton("Import Folder")
        self.import_button.clicked.connect(self.import_folder)
        self.status_label = QLabel("No folder loaded")
        self.status_label.setWordWrap(True)          # long messages wrap, never widen the panel
        left_layout.addWidget(self.import_button)
        left_layout.addWidget(self.status_label)

        # Focus Check
        focus_group = QGroupBox("Focus Check")
        self.focus_button = QPushButton("\U0001F50D  Check Focus of Folder")
        self.focus_button.setToolTip("Scores every photo: sharp, fixable or rejected")
        self.focus_button.clicked.connect(self.run_focus_check)
        self.focus_summary = QLabel("")
        self.focus_summary.setWordWrap(True)
        # one strip of four toggles: shooting order, greens, yellows, reds
        self.focus_show = set()                  # empty = everything, in shooting order
        show_row = QGridLayout()
        show_row.setSpacing(3)
        self.show_order_btn = QPushButton("Order")
        self.show_order_btn.setCheckable(True)
        self.show_order_btn.setChecked(True)
        self.show_order_btn.setToolTip("All photos, in shooting order")
        self.show_order_btn.clicked.connect(self._show_order_clicked)
        show_row.addWidget(self.show_order_btn, 0, 0)
        self.show_btns = {}
        for (cat, tip), cell in zip([("sharp", "Green: photos in focus"),
                                     ("fixable", "Yellow: slightly soft, can be recovered"),
                                     ("rejected", "Red: the softest photos of this folder")],
                                    [(0, 1), (1, 0), (1, 1)]):
            btn = QPushButton(SHOW_NAMES[cat])
            btn.setCheckable(True)
            btn.setToolTip(tip + ".\nSwitch on one, two or all three. Inside each colour the\n"
                                 "photos stay in shooting order. Files on disk are not touched.")
            btn.setStyleSheet(
                f"QPushButton {{ color: {FOCUS_COLORS[cat]}; font-weight: bold; padding: 4px 2px; }}"
                f"QPushButton:checked {{ background-color: {FOCUS_COLORS[cat]}; color: #111; }}"
                f"QPushButton:disabled {{ color: #666; }}")
            btn.clicked.connect(lambda _on=False, c=cat: self._show_group_clicked(c))
            show_row.addWidget(btn, *cell)
            self.show_btns[cat] = btn
        self.focus_recover_button = QPushButton("Recover Sharpness")
        self.focus_recover_button.clicked.connect(self.recover_current)
        self.focus_trash_button = QPushButton("Trash All Rejected...")
        self.focus_trash_button.setStyleSheet("QPushButton { color: #ff8a80; }")
        self.focus_trash_button.clicked.connect(self.trash_rejected)
        focus_layout = QVBoxLayout()
        judge_row = QHBoxLayout()
        judge_row.addWidget(QLabel("Judge by:"))
        self.judge_by = QComboBox()
        self.judge_by.addItem("Faces (people)", "faces")
        self.judge_by.addItem("Whole photo", "photo")
        self.judge_by.setToolTip("Faces: sharpness is measured on the people's faces and eyes, so a\n"
                                 "sharp background no longer hides a soft face. Photos with no face\n"
                                 "are judged on the whole photo.\n"
                                 "Whole photo: for crowds, landscapes, or when you focused on the background.")
        self.judge_by.currentIndexChanged.connect(lambda _i: self._recategorize())
        judge_row.addWidget(self.judge_by, 1)
        self.best_only = QCheckBox("\u2605 Best of burst only")
        self.best_only.setToolTip("Photos shot in a fast series (less than a second apart) form a burst.\n"
                                  "With this on, the strip shows only the sharpest frame of each burst.")
        self.best_only.toggled.connect(lambda _on: self._show_changed())
        focus_layout.addWidget(self.focus_button)
        focus_layout.addLayout(judge_row)
        focus_layout.addWidget(self.focus_summary)
        focus_layout.addLayout(show_row)
        focus_layout.addWidget(self.best_only)
        focus_layout.addWidget(self.focus_recover_button)
        focus_layout.addWidget(self.focus_trash_button)
        focus_group.setLayout(focus_layout)
        left_layout.addWidget(focus_group)
        for wdg in (self.show_order_btn, *self.show_btns.values(), self.best_only,
                    self.focus_recover_button, self.focus_trash_button):
            wdg.setEnabled(False)

        # the filmstrip: one row of thumbnails along the bottom of the window
        self.scroll_area = FilmStrip()
        self.scroll_widget = QWidget()
        self.grid_layout = QGridLayout()
        self.grid_layout.setContentsMargins(4, 2, 4, 2)
        self.grid_layout.setSpacing(6)
        self.grid_layout.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.scroll_widget.setLayout(self.grid_layout)
        self.scroll_area.setWidget(self.scroll_widget)
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        self.scroll_area.setFixedHeight(THUMB_H + 50)
        left_layout.addStretch(1)

        self.select_label = QLabel("Click: open  \u00b7  \u2318/Ctrl-click or Shift-click: select")
        self.select_label.setStyleSheet("color: #888;")
        self.select_label.setWordWrap(True)
        sel_row = QHBoxLayout()
        self.select_all_button = QPushButton("Select All")
        self.select_all_button.setToolTip("Select every photo in the strip (it follows the In focus / Fixable / Rejected buttons)")
        self.select_all_button.clicked.connect(self.select_all_shown)
        self.select_none_button = QPushButton("Select None")
        self.select_none_button.clicked.connect(self.select_none)

        paste_row = QHBoxLayout()
        self.copy_button = QPushButton("Copy Edits")
        self.copy_button.setToolTip("Copy the colour, tone and detail settings of this photo")
        self.copy_button.clicked.connect(self.copy_edits)
        self.paste_button = QPushButton("Paste Edits")
        self.paste_button.setToolTip("Paste them on this photo, or on all selected photos.\n"
                                     "Crop, rotation and straightening stay per photo.")
        self.paste_button.clicked.connect(self.paste_edits)
        self.paste_button.setEnabled(False)
        paste_row.addWidget(self.copy_button)
        paste_row.addWidget(self.paste_button)
        left_layout.addLayout(paste_row)
        self.carry_box = QCheckBox("Carry last edit to new photos")
        self.carry_box.setToolTip("When you move to a photo you haven't edited yet, it gets the colour,\n"
                                  "tone and detail of the last photo you edited. Crop and rotation\n"
                                  "stay per photo. Change anything and it's that photo's own edit.")
        self.carry_box.setChecked(QSettings("ImageStream", "LocalRAW").value("carry", False, type=bool))
        self.carry_box.toggled.connect(lambda on: QSettings("ImageStream", "LocalRAW").setValue("carry", on))
        left_layout.addWidget(self.carry_box)
        self.large_text_box = QCheckBox("Larger text")
        self.large_text_box.setChecked(QSettings("ImageStream", "LocalRAW").value("large_text", False, type=bool))
        self.large_text_box.toggled.connect(self._large_text_toggled)
        QTimer.singleShot(0, lambda: self._fit_to_text_size(self.large_text_box.isChecked()))
        QTimer.singleShot(0, lambda: self.panel_button.setChecked(
            QSettings("ImageStream", "LocalRAW").value("panel_hidden", False, type=bool)))
        left_layout.addWidget(self.large_text_box)

        # Tools row
        tools_layout = QVBoxLayout()
        self.batch_rename_button = QPushButton("Batch Rename")
        self.batch_rename_button.clicked.connect(self.open_batch_rename)
        self.metadata_button = QPushButton("Metadata")
        self.metadata_button.clicked.connect(self.open_metadata)
        tools_layout.addWidget(self.batch_rename_button)
        tools_layout.addWidget(self.metadata_button)
        left_layout.addLayout(tools_layout)

        # ===== CENTER PANEL
        self.preview_label = CropLabel("Open a folder and select an image")
        self.preview_label.setAlignment(Qt.AlignCenter)
        self.preview_label.setStyleSheet("background-color: #1a1a1a; color: #555;")
        self.preview_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        # ===== RIGHT PANEL
        right_layout = QVBoxLayout()

        # Rotate & Straighten
        rot_group = QGroupBox("Rotate && Straighten")
        rot_buttons = QHBoxLayout()
        self.rotate_left_button = QPushButton("\u21ba 90\u00b0")
        self.rotate_right_button = QPushButton("\u21bb 90\u00b0")
        self.flip_button = QPushButton("Flip")
        self.rotate_left_button.clicked.connect(lambda: self.rotate_image(-1))
        self.rotate_right_button.clicked.connect(lambda: self.rotate_image(1))
        self.flip_button.clicked.connect(self.flip_image)
        rot_buttons.addWidget(self.rotate_left_button)
        rot_buttons.addWidget(self.rotate_right_button)
        rot_buttons.addWidget(self.flip_button)
        self.straighten_slider = self._make_slider(-150, 150, 0)
        self.straighten_label = QLabel("+0.0\u00b0")
        self.straighten_label.setMinimumWidth(42)
        self.straighten_slider.setMinimumWidth(60)
        self.straighten_slider.setToolTip("Straighten: level a tilted horizon or field line.\n"
                                          "Double-click the number to set it back to 0.")
        self.straighten_label.mouseDoubleClickEvent = lambda e: self.straighten_slider.setValue(0)
        rot_layout = QVBoxLayout()
        rot_layout.addLayout(rot_buttons)
        rot_group.setLayout(rot_layout)
        rot_group.setTitle("Rotate")

        # White Balance
        wb_group = QGroupBox("White Balance")
        self.temp_slider = self._make_slider(-100, 100, 0)
        self.tint_slider = self._make_slider(-100, 100, 0)
        wb_layout = QVBoxLayout()
        self.grey_button = QPushButton("\U0001F4A7  Pick Neutral")
        self.grey_button.setCheckable(True)
        self.grey_button.setToolTip("Press, then click something in the photo that should be neutral\n"
                                    "grey or white: a white jersey, a grey wall, the lines on the field.\n"
                                    "Temperature and Tint are set so that spot has no colour cast.")
        self.grey_button.toggled.connect(self._grey_toggled)
        self.grey_hint = QLabel("")
        self.grey_hint.setWordWrap(True)
        self.grey_hint.setStyleSheet("color: #f5a623;")
        self.neutral_button = QPushButton("\u2728  Auto Neutral")
        self.neutral_button.setToolTip("Finds the colour of the light by itself and removes the colour cast.\n"
                                       "It changes nothing when it isn't sure (mixed light, no neutral areas),\n"
                                       "and it checks that faces still look like skin.")
        self.neutral_button.clicked.connect(self.auto_neutral)
        wb_row = QHBoxLayout()
        wb_row.addWidget(self.neutral_button)
        wb_row.addWidget(self.grey_button)
        wb_layout.addLayout(wb_row)
        wb_layout.addWidget(self.grey_hint)
        wb_layout.addWidget(QLabel("Temperature"))
        wb_layout.addWidget(self.temp_slider)
        wb_layout.addWidget(QLabel("Tint"))
        wb_layout.addWidget(self.tint_slider)
        wb_group.setLayout(wb_layout)

        # Tone
        tone_group = QGroupBox("Tone")
        self.exposure_slider = self._make_slider(-30, 30, 0)
        self.contrast_slider = self._make_slider(-50, 50, 0)
        tone_layout = QVBoxLayout()
        self.auto_button = QPushButton("\u2728  Auto Tone")
        self.auto_button.setToolTip("Sets exposure, white point, black point, shadows and highlights\n"
                                    "from this photo. A starting point: adjust after.")
        self.auto_button.clicked.connect(self.auto_tone)
        tone_layout.addWidget(self.auto_button)
        tone_layout.addWidget(QLabel("Exposure"))
        tone_layout.addWidget(self.exposure_slider)
        tone_layout.addWidget(QLabel("Contrast"))
        tone_layout.addWidget(self.contrast_slider)
        self.highlights_slider = self._make_slider(-100, 100, 0)
        self.shadows_slider = self._make_slider(-100, 100, 0)
        self.whites_slider = self._make_slider(-100, 100, 0)
        self.blacks_slider = self._make_slider(-100, 100, 0)
        self.saturation_slider = self._make_slider(-100, 100, 0)
        for name, slider in [("Highlights", self.highlights_slider), ("Shadows", self.shadows_slider),
                             ("Whites (white point)", self.whites_slider),
                             ("Blacks (black point)", self.blacks_slider),
                             ("Saturation", self.saturation_slider)]:
            tone_layout.addWidget(QLabel(name))
            tone_layout.addWidget(slider)
        tone_group.setLayout(tone_layout)

        # Detail
        detail_group = QGroupBox("Detail")
        self.sharpen_slider = self._make_slider(0, 20, 0)
        detail_layout = QVBoxLayout()
        detail_layout.addWidget(QLabel("Sharpen"))
        detail_layout.addWidget(self.sharpen_slider)
        detail_group.setLayout(detail_layout)

        # Noise Reduction
        nr_group = QGroupBox("Noise Reduction")
        self.nr_lum_slider = self._make_slider(0, 100, 0)
        self.nr_color_slider = self._make_slider(0, 100, 0)
        nr_layout = QVBoxLayout()
        nr_row = QHBoxLayout()
        self.noise_label = QLabel("Noise: \u2014")
        self.noise_label.setToolTip("Measured on this photo. The sliders remove noise relative to this level,\n"
                                    "so the same setting works at low and high ISO.")
        self.noise_auto_button = QPushButton("Auto")
        self.noise_auto_button.setToolTip("Set both sliders to suit the noise measured in this photo")
        self.noise_auto_button.clicked.connect(self.auto_noise)
        nr_row.addWidget(self.noise_label, 1)
        nr_row.addWidget(self.noise_auto_button)
        nr_layout.addLayout(nr_row)
        nr_layout.addWidget(QLabel("Luminance"))
        nr_layout.addWidget(self.nr_lum_slider)
        nr_layout.addWidget(QLabel("Color"))
        nr_layout.addWidget(self.nr_color_slider)
        nr_group.setLayout(nr_layout)

        # Dehaze
        dehaze_group = QGroupBox("Dehaze")
        self.dehaze_slider = self._make_slider(0, 100, 0)
        dehaze_layout = QVBoxLayout()
        dehaze_layout.addWidget(QLabel("Amount"))
        dehaze_layout.addWidget(self.dehaze_slider)
        dehaze_group.setLayout(dehaze_layout)

        # Watermark
        wm_group = QGroupBox("Watermark")
        self.watermark_button = QPushButton("Add Watermark...")
        self.watermark_button.clicked.connect(self.open_watermark)
        wm_layout = QVBoxLayout()
        wm_layout.addWidget(self.watermark_button)
        wm_group.setLayout(wm_layout)

        # Reset + Export
        self.reset_button = QPushButton("Reset All")
        self.reset_button.clicked.connect(self.reset_sliders)
        self.export_button = QPushButton("Export...")
        self.export_button.setToolTip("Export this photo, the selected photos, or all edited photos")
        self.export_button.setStyleSheet("QPushButton { font-weight: bold; }")
        self.export_button.clicked.connect(self.export_image)

        # Crop
        crop_group = QGroupBox("Crop")
        self.crop_shape = QComboBox()
        for name, value in [("Free shape", None), ("Original shape", "orig"), ("Square 1:1", 1.0),
                            ("Portrait 4:5", 4 / 5), ("Photo 3:2", 3 / 2), ("Photo 2:3", 2 / 3),
                            ("Wide 16:9", 16 / 9), ("Tall 9:16", 9 / 16)]:
            self.crop_shape.addItem(name, value)
        self.crop_shape.currentIndexChanged.connect(self.crop_shape_changed)
        self.crop_button = QPushButton("\u2702  Crop")
        self.crop_button.clicked.connect(self.toggle_crop)
        self.crop_cancel_button = QPushButton("Cancel")
        self.crop_cancel_button.clicked.connect(self.cancel_crop)
        self.crop_cancel_button.setVisible(False)
        self.crop_clear_button = QPushButton("Remove Crop")
        self.crop_clear_button.clicked.connect(self.clear_crop)
        self.crop_hint = QLabel("")
        self.crop_hint.setWordWrap(True)
        self.crop_hint.setStyleSheet("color: #f5a623;")
        crop_layout = QVBoxLayout()
        crop_layout.addWidget(QLabel("Crop shape"))
        crop_layout.addWidget(self.crop_shape)
        crop_layout.addWidget(self.crop_clear_button)
        crop_group.setLayout(crop_layout)

        right_layout.addWidget(wb_group)
        right_layout.addWidget(tone_group)
        right_layout.addWidget(crop_group)
        right_layout.addWidget(rot_group)
        right_layout.addWidget(detail_group)
        right_layout.addWidget(nr_group)
        right_layout.addWidget(dehaze_group)
        right_layout.addWidget(wm_group)
        right_layout.addStretch()

        left_panel = QWidget()
        left_panel.setLayout(left_layout)
        left_layout.setContentsMargins(0, 0, 0, 0)
        # the left panel scrolls if the window is short (or the text is large), so it
        # never squeezes the photo
        self.left_scroll = QScrollArea()
        left_panel.setMinimumWidth(0)
        self.left_scroll.setWidget(left_panel)
        self.left_scroll.setWidgetResizable(True)
        self.left_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        main_layout.addWidget(self.left_scroll)
        center_layout = QVBoxLayout()
        top_bar = QHBoxLayout()
        self.compare_button = QPushButton("Before | After")
        self.compare_button.setCheckable(True)
        self.compare_button.setToolTip("Left half: before your corrections. Right half: after.")
        self.compare_button.toggled.connect(lambda _on: self.apply_pipeline())
        self.compare_button_placeholder = self.compare_button
        self.prev_button = QPushButton("\u25c0  Previous")
        self.next_button = QPushButton("Next  \u25b6")
        self.delete_button = QPushButton("\U0001F5D1  Delete")
        self.delete_button.setToolTip("Move this photo to the Trash (Delete key)")
        self.delete_button.setStyleSheet("QPushButton { color: #ff8a80; font-weight: bold; }")
        self.prev_button.clicked.connect(lambda: self.show_neighbor(-1))
        self.next_button.clicked.connect(lambda: self.show_neighbor(1))
        self.delete_button.clicked.connect(self.delete_current_photo)
        self.info_label = QLabel("")
        self.info_label.setAlignment(Qt.AlignCenter)
        self.info_label.setStyleSheet("color: #f5a623; font-weight: bold; padding: 4px;")
        self.info_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.info_label.setMinimumWidth(0)
        self.info_label.setWordWrap(False)
        self.info_label.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)   # a long name never pushes buttons away
        self.save_button = QPushButton("\U0001F4BE  Save")
        self.save_button.setToolTip("Save the finished photo as a full-size JPEG copy (\u2318S),\n"
                                    "in the 'Edited' folder inside your photo folder.\n"
                                    "Saving again updates that copy. Your original is never changed.\n"
                                    "For many photos at once, use Export.")
        self.save_button.setStyleSheet("QPushButton { font-weight: bold; }")
        self.save_button.clicked.connect(self.save_now)
        self.last_edit_button = QPushButton("\u2935  Last Edit")
        self.last_edit_button.setToolTip("Give this photo the colour, tone and detail of the photo you\n"
                                         "edited just before (\u2318\u21e7V). Crop and rotation stay as they are.")
        self.last_edit_button.clicked.connect(self.apply_last_edit)
        top_bar.addWidget(self.last_edit_button)
        top_bar.addWidget(self.save_button)
        top_bar.addWidget(self.delete_button)
        top_bar.addWidget(self.compare_button_placeholder)
        top_bar.addSpacing(8)
        top_bar.addWidget(self.info_label, 1)
        self.panel_button = QPushButton("\u25e8  Hide Panel")
        self.panel_button.setCheckable(True)
        self.panel_button.setToolTip("Hide or show the adjustments column, for a bigger photo (\u2318\\)")
        self.panel_button.toggled.connect(self._toggle_right_panel)
        top_bar.addWidget(self.panel_button)
        center_layout.addLayout(top_bar)
        zoom_bar = QHBoxLayout()
        self.zoom_out_button = QPushButton("\u2212")
        self.zoom_fit_button = QPushButton("Fit")
        self.zoom_100_button = QPushButton("100%")
        self.zoom_in_button = QPushButton("+")
        self.zoom_label = QLabel("Fit")
        self.zoom_label.setStyleSheet("color: #aaa; padding: 0 8px;")
        # compact zoom buttons, so Crop and Apply always have room
        for b in (self.zoom_out_button, self.zoom_in_button, self.zoom_fit_button, self.zoom_100_button):
            b.setStyleSheet("QPushButton { padding: 4px 6px; }")      # compact, but never narrower than its text
        self.zoom_out_button.setToolTip("Zoom out")
        self.zoom_in_button.setToolTip("Zoom in (or use the mouse wheel / pinch)")
        self.zoom_fit_button.setToolTip("Show the whole photo")
        self.zoom_100_button.setToolTip("Real size, to check sharpness. You can also just click on the photo.")
        self.zoom_out_button.clicked.connect(lambda: self.zoom_by(1 / 1.5))
        self.zoom_in_button.clicked.connect(lambda: self.zoom_by(1.5))
        self.zoom_fit_button.clicked.connect(self.zoom_fit)
        self.zoom_100_button.clicked.connect(lambda: self.zoom_to(1.0))
        self.verdict_label = QLabel("")
        self.verdict_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.verdict_label.setMinimumWidth(0)
        self.verdict_label.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)
        zoom_bar.addStretch(1)                    # equal room both sides keeps zoom and crop centred
        zoom_bar.addWidget(self.zoom_out_button)
        zoom_bar.addWidget(self.zoom_fit_button)
        zoom_bar.addWidget(self.zoom_100_button)
        zoom_bar.addWidget(self.zoom_in_button)
        zoom_bar.addWidget(self.zoom_label)
        self.zoom_label.setMinimumWidth(40)
        self.loupe_button = QPushButton("\U0001F50E  Loupe")
        self.loupe_button.setCheckable(True)
        self.loupe_button.setToolTip("Magnifier: move the pointer over the photo to see that spot\n"
                                     "enlarged to 200 %, to check noise, sharpness and defects (L)")
        self.loupe_button.toggled.connect(self._loupe_toggled)
        zoom_bar.addWidget(self.loupe_button)
        self.peaking_button = QPushButton("Peaking")
        self.peaking_button.setCheckable(True)
        self.peaking_button.setToolTip("Focus peaking: paints the sharpest edges red, so you see at a glance\n"
                                       "where the focus landed (P)")
        self.peaking_button.toggled.connect(lambda _on: self.apply_pipeline())
        zoom_bar.addWidget(self.peaking_button)
        self.faces_button = QPushButton("\u263a Faces")
        self.faces_button.setCheckable(True)
        self.faces_button.setToolTip("After Check Focus: show a frame around each face Focus Check judged,\n"
                                     "green, yellow or red by its sharpness (F)")
        self.faces_button.toggled.connect(lambda _on: self._update_overlays())
        zoom_bar.addWidget(self.faces_button)
        zoom_bar.addSpacing(10)
        self.crop_button.setStyleSheet("QPushButton { font-weight: bold; }")
        self.crop_button.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)     # never squeezed
        self._verdict_slot = True
        self.crop_cancel_button.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)
        zoom_bar.addWidget(self.crop_button)
        zoom_bar.addWidget(self.crop_cancel_button)
        zoom_bar.addSpacing(10)
        zoom_bar.addStretch(1)
        self.crop_hint.setAlignment(Qt.AlignCenter)
        self.crop_hint.setVisible(False)
        center_layout.addLayout(zoom_bar)
        # buttons in the two bars keep their full text; the file name gives way instead
        for bar in (top_bar, zoom_bar):
            for i in range(bar.count()):
                widget = bar.itemAt(i).widget()
                if isinstance(widget, QPushButton):
                    widget.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)
        self.crop_bar = QWidget()
        crop_row = QHBoxLayout(self.crop_bar)
        crop_row.setContentsMargins(0, 0, 0, 0)
        crop_row.setSpacing(3)
        shape_label = QLabel("Shape:")
        shape_label.setStyleSheet("color: #f5a623; font-weight: bold;")
        crop_row.addStretch(1)
        crop_row.addWidget(shape_label)
        self.shape_buttons = []
        for i, short in enumerate(["Free", "Original", "1:1 Square", "4:5", "3:2", "2:3", "16:9", "9:16"]):
            b = QPushButton(short)
            b.setCheckable(True)
            b.setToolTip(self.crop_shape.itemText(i))
            b.setStyleSheet("QPushButton:checked { background-color: #f5a623; color: #111; font-weight: bold; }")
            b.clicked.connect(lambda _on=False, idx=i: self.crop_shape.setCurrentIndex(idx))
            crop_row.addWidget(b)
            self.shape_buttons.append(b)
        crop_row.addStretch(1)
        self.crop_shape.currentIndexChanged.connect(self._paint_shape_buttons)
        self._paint_shape_buttons()
        self.crop_bar.setVisible(False)
        center_layout.addWidget(self.crop_bar)
        self.level_bar = QWidget()
        level_row = QHBoxLayout(self.level_bar)
        level_row.setContentsMargins(0, 0, 0, 0)
        level_row.addStretch(1)
        level = QLabel("Straighten")
        level.setStyleSheet("color: #f5a623; font-weight: bold;")
        level_row.addWidget(level)
        self.straighten_slider.setFixedWidth(220)
        level_row.addWidget(self.straighten_slider)
        level_row.addWidget(self.straighten_label)
        level_row.addStretch(1)
        self.level_bar.setVisible(False)
        center_layout.addWidget(self.level_bar)
        center_layout.addWidget(self.crop_hint)
        self.preview_label.setMinimumSize(200, 200)
        self.preview_label.setFocusPolicy(Qt.StrongFocus)
        self.preview_label.zoomRequested.connect(self.zoom_by)
        self.preview_label.panned.connect(self.pan_view)
        self.preview_label.clicked.connect(self.toggle_zoom)
        self.preview_label.hovered.connect(self._loupe_moved)
        self._loupe_timer = QTimer()
        self._loupe_timer.setSingleShot(True)
        self._loupe_timer.setInterval(15)
        self._loupe_timer.timeout.connect(self._draw_loupe)
        self._loupe_at = None
        center_layout.addWidget(self.preview_label, 1)
        main_layout.addLayout(center_layout, 1)
        screen = QApplication.primaryScreen()
        if screen is not None:
            area = screen.availableGeometry()
            self.resize(min(1400, area.width() - 40), min(850, area.height() - 60))
        right_widget = QWidget()
        right_widget.setLayout(right_layout)
        right_scroll = QScrollArea()
        right_scroll.setWidget(right_widget)
        right_scroll.setWidgetResizable(True)
        right_scroll.setMinimumWidth(300)
        right_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        right_outer_widget = QWidget()
        right_outer_widget.setFixedWidth(320)
        self.right_outer_widget = right_outer_widget
        right_outer = QVBoxLayout(right_outer_widget)
        right_outer.setContentsMargins(0, 0, 0, 0)
        right_outer.addWidget(right_scroll, 1)
        # Reset and Export stay pinned at the bottom, always visible
        right_outer.addWidget(self.reset_button)
        right_outer.addWidget(self.export_button)
        main_layout.addWidget(right_outer_widget)
        # just above the thumbnails: move through them, and choose which ones to use
        strip_bar = QHBoxLayout()
        strip_bar.setSpacing(6)
        for b in (self.prev_button, self.next_button):
            b.setStyleSheet("QPushButton { font-weight: bold; padding: 6px 18px; }")
            b.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)
        strip_bar.addWidget(self.prev_button)
        strip_bar.addWidget(self.next_button)
        strip_bar.addSpacing(16)
        strip_bar.addWidget(self.select_all_button)
        strip_bar.addWidget(self.select_none_button)
        strip_bar.addSpacing(10)
        strip_bar.addWidget(self.select_label, 1)
        rate_label = QLabel("Rate:")
        rate_label.setStyleSheet("color: #aaa;")
        strip_bar.addWidget(rate_label)
        self.star_buttons = []
        for n in range(1, 6):
            b = QPushButton("\u2606")
            b.setToolTip(f"{n} star{'s' if n > 1 else ''}  (key {n}).  Key 0 removes the stars.\n"
                         "With several photos selected, all of them get the rating.")
            b.setFixedWidth(34)
            b.setStyleSheet("QPushButton { font-size: 18px; padding: 0px; color: #f5c542; border: none; background: transparent; }"
                            "QPushButton:hover { color: #ffe08a; }")
            b.clicked.connect(lambda _=False, k=n: self.set_rating(0 if self.ratings.get(self.current_file_path) == k else k))
            strip_bar.addWidget(b)
            self.star_buttons.append(b)
        strip_bar.addSpacing(12)
        self.rating_filter = QComboBox()
        for text, value in [("Show: all", 0), ("\u2605 and up", 1), ("\u2605\u2605 and up", 2),
                            ("\u2605\u2605\u2605 and up", 3), ("\u2605\u2605\u2605\u2605 and up", 4),
                            ("\u2605\u2605\u2605\u2605\u2605 only", 5)]:
            self.rating_filter.addItem(text, value)
        self.rating_filter.setToolTip("Show only the photos with at least this many stars.\n"
                                      "Then Select All and Export them.")
        self.rating_filter.currentIndexChanged.connect(lambda _i: self._show_changed())
        strip_bar.addWidget(self.rating_filter)
        self.select_label.setWordWrap(False)
        window_layout.addLayout(strip_bar)
        window_layout.addWidget(self.scroll_area)

        # Keyboard: Delete / Backspace moves the current photo to the Trash
        QShortcut(QKeySequence(Qt.Key_Delete), self, activated=self.delete_current_photo)
        QShortcut(QKeySequence(Qt.Key_Backspace), self, activated=self.delete_current_photo)  # the Mac delete key
        QShortcut(QKeySequence(Qt.Key_Left), self, activated=lambda: self.show_neighbor(-1))
        QShortcut(QKeySequence(Qt.Key_Right), self, activated=lambda: self.show_neighbor(1))
        QShortcut(QKeySequence(QKeySequence.ZoomIn), self, activated=lambda: self.zoom_by(1.5))
        QShortcut(QKeySequence("Ctrl+="), self, activated=lambda: self.zoom_by(1.5))
        QShortcut(QKeySequence(QKeySequence.ZoomOut), self, activated=lambda: self.zoom_by(1 / 1.5))
        QShortcut(QKeySequence("Ctrl+0"), self, activated=self.zoom_fit)
        QShortcut(QKeySequence("Ctrl+S"), self, activated=self.save_now)
        QShortcut(QKeySequence("Ctrl+Shift+V"), self, activated=self.apply_last_edit)
        for n in range(0, 6):
            QShortcut(QKeySequence(str(n)), self, activated=lambda k=n: self.set_rating(k))
        QShortcut(QKeySequence("Ctrl+\\"), self, activated=lambda: self.panel_button.toggle())
        QShortcut(QKeySequence("L"), self, activated=self.loupe_button.toggle)
        QShortcut(QKeySequence("P"), self, activated=self.peaking_button.toggle)
        QShortcut(QKeySequence("F"), self, activated=self.faces_button.toggle)
        QShortcut(QKeySequence("Ctrl+1"), self, activated=lambda: self.zoom_to(1.0))

    # ─────────────────────────────────────────────────

    def _make_slider(self, min_val, max_val, default):
        slider = QSlider(Qt.Horizontal)
        slider.setRange(min_val, max_val)
        slider.setValue(default)
        slider.valueChanged.connect(self._on_slider_changed)
        return slider

    def _on_slider_changed(self):
        self._preview_timer.start()

    # ─────────────────────────────────────────────────

    def import_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Select Folder")
        if folder:
            self.stop_focus_check()
            self._save_edits_file()
            self.folder = folder
            self.image_files = get_files_in_folder(folder)
            self._thumb_cache = {}
            self.selected = set()
            self._last_clicked = None
            self._load_edits_file()
            edited_dir = os.path.join(folder, "Edited")
            self.saved_copies = {}
            self.saved_settings = {}
            for p in self.image_files:
                target = self._final_name(p, edited_dir)
                if os.path.exists(target):
                    self.saved_copies[p] = target
            self._set_focus_results({}, None)
            self.status_label.setText(f"{len(self.image_files)} images found")
            self.display_thumbnails()

    def _shown_files(self):
        """Photos in the strip: all of them, or only one Focus Check group."""
        files = self.image_files
        least = self.rating_filter.currentData() if getattr(self, "rating_filter", None) is not None else 0
        if least:
            files = [p for p in files if self.ratings.get(p, 0) >= least]
        if self.focus and getattr(self, "best_only", None) is not None and self.best_only.isChecked():
            files = [p for p in files if not self.focus.get(p, {}).get("burst") or self.focus[p].get("best")]
        if not self.focus or not self.focus_show:
            return files
        # the chosen colours, greens then yellows then reds; the sort is stable, so
        # shooting order is kept inside each colour
        rank = {"sharp": 0, "fixable": 1, "rejected": 2}
        chosen = [p for p in files if self.focus.get(p, {}).get("cat") in self.focus_show]
        return sorted(chosen, key=lambda p: rank[self.focus[p]["cat"]])

    def _caption_for(self, path):
        parts, color = [], "#9ab"
        if path in self.selected:
            parts.append("\u2713")
        info = self.focus.get(path)
        if info:
            mark = "\u263a" if info.get("by") == "face" else ""
            if info.get("best"):
                mark += "\u2605"
            parts.append(f"\u25cf {FOCUS_NAMES[info['cat']]}{(' ' + mark) if mark else ''}")
            color = FOCUS_COLORS[info["cat"]]
        saved_as = self.saved_settings.get(path, "unknown")
        up_to_date = path in self.saved_copies and (saved_as == "unknown" or saved_as == self.edits.get(path))
        if up_to_date:
            parts.append("\U0001F4BE saved" if not info else "\U0001F4BE")
        elif path in self.edits:
            parts.append("\u270e edited" if not info else "\u270e")
        return "  ".join(parts), color

    def _refresh_caption(self, path):
        caption = getattr(self, "thumb_captions", {}).get(path)
        if caption is None:
            return
        self._fill_caption(caption, path)

    def _fill_caption(self, caption, path):
        text, color = self._caption_for(path)
        stars = self.ratings.get(path, 0)
        html = ""
        if stars:
            html += "<span style='color:#f5c542; font-size:13px;'>" + STAR * stars + "</span>&nbsp;&nbsp;"
        if text:
            html += f"<span style='color:{color or '#9ab'};'>{text}</span>"
        caption.setText(html)
        caption.setStyleSheet("font-size: 11px; font-weight: bold;")
        caption.setVisible(bool(html))

    def _wanted_thumb_cols(self):
        """The filmstrip is a single row."""
        return 10 ** 9

    def display_thumbnails(self):
        for i in reversed(range(self.grid_layout.count())):
            widget = self.grid_layout.itemAt(i).widget()
            if widget:
                widget.setParent(None)

        self.thumb_labels = {}
        self.thumb_captions = {}
        files = list(self._shown_files())
        self._thumb_cols = self._wanted_thumb_cols()
        row, col = 0, 0
        for n, file_path in enumerate(files):
            pixmap = self._thumb_cache.get(file_path)
            if pixmap is None:
                pixmap = make_thumbnail(file_path)
                self._thumb_cache[file_path] = pixmap
                if n % 6 == 0:      # keep the window alive while a big folder loads
                    self.status_label.setText(f"Loading previews... {n + 1} of {len(files)}")
                    QApplication.processEvents()
            cell = QWidget()
            cell_layout = QVBoxLayout(cell)
            cell_layout.setContentsMargins(0, 0, 0, 0)
            cell_layout.setSpacing(1)
            label = QLabel()
            label.setPixmap(pixmap)
            label.setAlignment(Qt.AlignCenter)
            label.setCursor(Qt.PointingHandCursor)
            label.setToolTip(os.path.basename(file_path))
            # the frame takes the shape of the photo: wide for a horizontal shot, narrow for a vertical one
            label.setFixedSize(max(pixmap.width(), 40) + 6, THUMB_H + 6)
            label.setStyleSheet(THUMB_FRAME + "border: 3px solid transparent;")
            caption = QLabel()
            caption.setAlignment(Qt.AlignCenter)
            caption.setFixedWidth(max(label.width(), 118))
            self._fill_caption(caption, file_path)
            cell_layout.addWidget(label)
            cell_layout.addWidget(caption)
            self.thumb_labels[file_path] = label
            self.thumb_captions[file_path] = caption
            label.mousePressEvent = lambda event, path=file_path: self._thumb_clicked(event, path)
            self.grid_layout.addWidget(cell, row, col)
            col += 1
            if col >= self._thumb_cols:
                col = 0
                row += 1
        shown, total = len(files), len(self.image_files)
        self.status_label.setText(
            f"{total} images found" if shown == total else f"Showing {shown} of {total} images")
        self.highlight_current()

    # ───────────────────── Focus Check ─────────────────────

    def stop_focus_check(self):
        worker = self._focus_worker
        if worker is not None and worker.isRunning():
            worker.requestInterruption()
            worker.wait(15000)
        self._focus_worker = None

    def run_focus_check(self):
        if self._focus_worker is not None and self._focus_worker.isRunning():
            self._focus_worker.requestInterruption()      # the button says Stop while scanning
            return
        if not self.image_files:
            QMessageBox.information(self, "Focus Check", "Import a folder first.")
            return
        self.focus_button.setText("Stop")
        self.focus_summary.setText("Checking focus...")
        self._focus_worker = FocusWorker(self.image_files)
        self._focus_worker.progress.connect(
            lambda i, n: self.focus_summary.setText(f"Checking focus... {i} of {n}"))
        self._focus_worker.finished_scan.connect(self._focus_done)
        self._focus_worker.start()

    def _focus_done(self, results, completed):
        self.focus_button.setText("\U0001F50D  Check Focus of Folder")
        if not completed:
            self.focus_summary.setText("Stopped. Nothing was changed.")
            return
        self._focus_raw = {p: r for p, r in results.items() if p in self.image_files}
        self._recategorize()

    def _recategorize(self):
        """Turn the measurements into In focus / Fixable / Rejected, and find the best of each burst."""
        raw = getattr(self, "_focus_raw", None)
        if not raw:
            return
        by_faces = self.judge_by.currentData() == "faces"
        photo_limits = focus_check.calibrate([r["score"] for r in raw.values()])
        face_values = [r["subject"] for r in raw.values() if r.get("subject") is not None]
        face_limits = subject_focus.calibrate(face_values, 4.0, 2.0)
        face_limits = (min(face_limits[0], 9.0), min(face_limits[1], face_limits[0] * 0.6))
        results = {}
        for path, m in raw.items():
            r = dict(m)
            if by_faces and m.get("subject") is not None:
                r["by"], r["value"], r["sharp_t"] = "face", m["subject"], face_limits[0]
                r["cat"] = focus_check.category(m["subject"], *face_limits)
            else:
                r["by"], r["value"], r["sharp_t"] = "photo", m["score"], photo_limits[0]
                r["cat"] = focus_check.category(m["score"], *photo_limits)
            r["blur"] = focus_check.blur_type(m.get("shutter"))
            r["burst"], r["best"] = None, False
            results[path] = r
        rank = {"sharp": 0, "fixable": 1, "rejected": 2}
        for group in subject_focus.group_bursts({p: r.get("time") for p, r in results.items()}):
            winner = min(group, key=lambda p: (rank[results[p]["cat"]],
                                               -results[p]["value"] / max(results[p]["sharp_t"], 1e-6)))
            for i, p in enumerate(sorted(group, key=lambda q: results[q].get("time") or 0), 1):
                results[p]["burst"] = (i, len(group))
            results[winner]["best"] = True
        self._set_focus_results(results, photo_limits)
        self.display_thumbnails()
        self._update_overlays()

    def _set_focus_results(self, results, limits):
        self.focus = results
        self.focus_limits = limits
        have = bool(results)
        if not have:
            self.focus_show.clear()
        for wdg in (self.show_order_btn, *self.show_btns.values(), self.best_only,
                    self.focus_recover_button, self.focus_trash_button):
            wdg.setEnabled(have)
        self._update_focus_summary()

    def _update_focus_summary(self):
        if not self.focus:
            self.focus_summary.setText("")
            self._paint_show_strip()
            return
        count = {"sharp": 0, "fixable": 0, "rejected": 0}
        for r in self.focus.values():
            count[r["cat"]] += 1
        self.focus_summary.setText(
            f"<span style='color:{FOCUS_COLORS['sharp']}'>In focus {count['sharp']}</span> \u00b7 "
            f"<span style='color:{FOCUS_COLORS['fixable']}'>Fixable {count['fixable']}</span> \u00b7 "
            f"<span style='color:{FOCUS_COLORS['rejected']}'>Rejected {count['rejected']}</span>")
        self._paint_show_strip(count)

    def _paint_show_strip(self, count=None):
        if count is None:
            count = {"sharp": 0, "fixable": 0, "rejected": 0}
            for r in self.focus.values():
                count[r["cat"]] += 1
        self.show_order_btn.setChecked(not self.focus_show)
        for cat, btn in self.show_btns.items():
            btn.setChecked(cat in self.focus_show)
            btn.setText(f"{SHOW_NAMES[cat]}  {count[cat]}" if self.focus else SHOW_NAMES[cat])

    def _show_order_clicked(self):
        self.focus_show.clear()
        self._show_changed()

    def _show_group_clicked(self, cat):
        self.focus_show.symmetric_difference_update({cat})
        self._show_changed()

    def _show_changed(self):
        self._paint_show_strip()
        self.display_thumbnails()
        shown = self._shown_files()
        if shown and self.current_file_path not in shown:
            self.load_image(shown[0])

    def recover_current(self):
        info = self.focus.get(self.current_file_path)
        if not info or self.focus_limits is None:
            QMessageBox.information(self, "Recover Sharpness", "Click a photo that Focus Check has scored.")
            return
        level = focus_check.recovery_level(info.get("value", info["score"]), info.get("sharp_t", self.focus_limits[0]))
        if level == 0:
            QMessageBox.information(self, "Recover Sharpness", "This photo is already sharp.")
            return
        self.sharpen_slider.setValue({1: 6, 2: 12, 3: 18}[level])
        self.compare_button.setChecked(True)      # show before | after straight away
        self.apply_pipeline()

    def trash_rejected(self):
        rejected = [p for p in self.image_files if self.focus.get(p, {}).get("cat") == "rejected"]
        if not rejected:
            QMessageBox.information(self, "Trash Rejected", "There are no rejected photos.")
            return
        answer = QMessageBox.question(
            self, "Trash Rejected",
            f"Move {len(rejected)} rejected photos to the Trash?\n\n"
            "Rejected means the softest photos of this folder. Look at them first with "
            "'Show: rejected' if you are not sure.\nYou can restore them from the Trash.",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if answer != QMessageBox.Yes:
            return
        from send2trash import send2trash
        failed = 0
        for path in rejected:
            try:
                send2trash(path)
            except Exception:
                failed += 1
                continue
            self.image_files.remove(path)
            self.focus.pop(path, None)
            self._thumb_cache.pop(path, None)
            self.edits.pop(path, None)
            self.selected.discard(path)
        self._edits_timer.start()
        if self.current_file_path not in self.image_files:
            self.current_image = None
            self.current_file_path = None
            self.preview_image = None
            self.preview_label.clear()
            self.preview_label.setText("Rejected photos moved to the Trash")
        self.focus_show.clear()
        self._update_focus_summary()
        self.display_thumbnails()
        if failed:
            QMessageBox.warning(self, "Trash Rejected", f"{failed} photos could not be moved to the Trash.")
        if self.current_file_path is None and self.image_files:
            self.load_image(self.image_files[0])

    def closeEvent(self, event):
        self.stop_focus_check()
        self._save_edits_file()
        super().closeEvent(event)

    # ─────────────────────────────────────────────────

    def load_image(self, file_path):
        if self.current_file_path and self.current_file_path != file_path:
            self._remember_current()
            looks = (self.edits.get(self.current_file_path) or {}).get("sliders") or {}
            looks = {k: v for k, v in looks.items() if k != "straighten"}
            if looks:
                self._last_edit = looks
        try:
            image = self.raw_loader.load_image(file_path)
        except Exception as e:
            QMessageBox.critical(self, "Load Error", str(e))
            return
        if image is None:
            return
        self.current_image = image
        self.current_file_path = file_path
        self.preview_image = resize_for_preview(image, max_size=PREVIEW_MAX)
        self._noise_full = None
        self._noise_preview = None
        self._measure_noise_later()
        # every photo keeps its own edits; a photo never edited starts clean
        # (or with the last edit, when "New photos start with the last edit" is on)
        own = self.edits.get(file_path)
        if own is None and self.carry_box.isChecked() and getattr(self, "_last_edit", None):
            own = {"sliders": dict(self._last_edit)}
        self._restore_settings(own)
        self.grey_button.setChecked(False)
        self.zoom_scale = None
        self.zoom_center = None
        self._geo_cache = (None, None)
        self._end_crop_mode()
        self.highlight_current()
        self.apply_pipeline()

    # ─────────────────────── edits kept per photo ───────────────────────

    def _current_settings(self):
        sliders = {}
        for name, attr, _target, _scale in SLIDERS:
            value = getattr(self, attr).value()
            if value:
                sliders[name] = value
        settings = {"sliders": sliders}
        if self.pipeline.rotation % 4:
            settings["rotation"] = self.pipeline.rotation % 4
        if self.pipeline.flip:
            settings["flip"] = True
        if self.pipeline.crop:
            settings["crop"] = [round(v, 5) for v in self.pipeline.crop]
        meta = (self.edits.get(self.current_file_path) or {}).get("meta")
        if meta:
            settings["meta"] = meta
        return settings

    @staticmethod
    def _is_untouched(settings):
        return not settings.get("sliders") and len(settings) == 1

    def _restore_settings(self, settings):
        sliders = (settings or {}).get("sliders", {})
        for name, attr, _target, _scale in SLIDERS:
            slider = getattr(self, attr)
            slider.blockSignals(True)
            slider.setValue(int(sliders.get(name, 0)))
            slider.blockSignals(False)
        settings_to_pipeline(settings, self.pipeline)

    def _remember_current(self):
        path = self.current_file_path
        if not path:
            return
        settings = self._current_settings()
        before = self.edits.get(path)
        if self._is_untouched(settings):
            self.edits.pop(path, None)
        else:
            self.edits[path] = settings
        if before != self.edits.get(path):
            self._refresh_caption(path)
            self._edits_timer.start()

    def _edits_path(self):
        return os.path.join(self.folder, EDITS_FILE) if self.folder else None

    def _backup_edits_path(self):
        """Where edits go when the photo folder can't be written to (a locked card, a disc)."""
        import hashlib
        from PySide6.QtCore import QStandardPaths
        base = QStandardPaths.writableLocation(QStandardPaths.AppDataLocation) or os.path.expanduser("~/.localraw")
        key = hashlib.sha1(os.path.abspath(self.folder).encode("utf-8")).hexdigest()[:16]
        return os.path.join(base, "edits", key + ".json")

    def _load_edits_file(self):
        self.edits = {}
        self.ratings = {}
        self._warned_read_only = False
        data, stars = None, {}
        for path in (self._edits_path(), self._backup_edits_path()):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    whole = json.load(f)
                data, stars = whole.get("photos", {}), whole.get("ratings", {})
                break
            except Exception:
                continue
        names = {os.path.basename(p): p for p in self.image_files}
        for name, n in (stars or {}).items():
            if name in names and isinstance(n, int) and 1 <= n <= 5:
                self.ratings[names[name]] = n
        if not data:
            return
        for name, settings in data.items():
            if name in names and isinstance(settings, dict):
                self.edits[names[name]] = settings

    def _save_edits_file(self):
        self._edits_timer.stop()
        path = self._edits_path()
        if not path:
            return
        data = {"app": "LocalRAW", "version": 1,
                "photos": {os.path.basename(p): s for p, s in self.edits.items()},
                "ratings": {os.path.basename(p): n for p, n in self.ratings.items()}}
        try:
            if not data["photos"] and not data["ratings"] and not os.path.exists(path):
                return
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=1)
            os.replace(tmp, path)
            self._edits_saved_ok = True
        except Exception:
            # the photo folder is read-only: keep the edits in LocalRAW's own storage instead
            try:
                backup = self._backup_edits_path()
                os.makedirs(os.path.dirname(backup), exist_ok=True)
                with open(backup, "w", encoding="utf-8") as f:
                    json.dump(dict(data, folder=os.path.abspath(self.folder)), f, indent=1)
                self._edits_saved_ok = True
                if not getattr(self, "_warned_read_only", False):
                    self._warned_read_only = True
                    QMessageBox.information(
                        self, "Edits kept safely",
                        "This folder can't be written to (it may be a locked card or a read-only drive).\n\n"
                        "Your edits are kept safely inside LocalRAW instead, and will be there when you open "
                        "this folder again.\n\nTo Save or Export copies, choose a folder you can write to, "
                        "for example in Pictures.")
            except Exception:
                self._edits_saved_ok = False
                if not getattr(self, "_warned_read_only", False):
                    self._warned_read_only = True
                    QMessageBox.warning(self, "Edits not saved",
                                        "Your edits could not be saved anywhere. They stay while LocalRAW is open; "
                                        "export your photos before closing.")

    # ─────────────────────── selection, copy and paste ───────────────────────

    def _thumb_clicked(self, event, path):
        mods = event.modifiers()
        if mods & Qt.ShiftModifier and self._last_clicked:
            shown = self._shown_files()
            if self._last_clicked in shown and path in shown:
                a, b = sorted((shown.index(self._last_clicked), shown.index(path)))
                self.selected.update(shown[a:b + 1])
            else:
                self.selected.add(path)
        elif mods & (Qt.ControlModifier | Qt.MetaModifier):
            self.selected.symmetric_difference_update({path})
        else:
            self._last_clicked = path
            self.load_image(path)
            return
        self._last_clicked = path
        self._selection_changed()

    def _selection_changed(self):
        self.selected &= set(self.image_files)
        for path in getattr(self, "thumb_captions", {}):
            self._refresh_caption(path)
        self.highlight_current()
        n = len(self.selected)
        self.select_label.setText(
            f"{n} selected" if n else "Click: open  \u00b7  \u2318/Ctrl-click or Shift-click: select")
        self.select_label.setStyleSheet(
            f"color: {SELECT_COLOR if n else '#888'}; font-weight: {'bold' if n else 'normal'};")

    def select_all_shown(self):
        self.selected = set(self._shown_files())
        self._selection_changed()

    def select_none(self):
        self.selected = set()
        self._selection_changed()

    def copy_edits(self):
        if self.current_file_path is None:
            return
        sliders = dict(self._current_settings()["sliders"])
        sliders.pop("straighten", None)
        self.copied = sliders
        self.paste_button.setEnabled(True)
        self.paste_button.setToolTip(f"Paste {len(sliders)} settings on this photo, or on all selected photos.\n"
                                     "Crop, rotation and straightening stay per photo.")
        self.status_label.setText("Edits copied. Select photos, then press Paste Edits.")

    def paste_edits(self):
        if self.copied is None:
            return
        targets = [p for p in self.image_files if p in self.selected] or (
            [self.current_file_path] if self.current_file_path else [])
        for path in targets:
            if path == self.current_file_path:
                continue
            settings = dict(self.edits.get(path, {"sliders": {}}))
            own = settings.get("sliders", {})
            sliders = dict(self.copied)
            if own.get("straighten"):
                sliders["straighten"] = own["straighten"]
            settings["sliders"] = sliders
            if self._is_untouched(settings):
                self.edits.pop(path, None)
            else:
                self.edits[path] = settings
            self._refresh_caption(path)
        if self.current_file_path in targets:
            settings = self._current_settings()
            straighten = settings["sliders"].get("straighten")
            settings["sliders"] = dict(self.copied)
            if straighten:
                settings["sliders"]["straighten"] = straighten
            self._restore_settings(settings)
            self.apply_pipeline()
        self._edits_timer.start()
        self.status_label.setText(f"Edits pasted on {len(targets)} photo{'s' if len(targets) != 1 else ''}.")

    # ─────────────────────────────────────────────────

    def update_pipeline_values(self):
        for _name, attr, target, scale in SLIDERS:
            setattr(self.pipeline, target, getattr(self, attr).value() / scale)
        self.straighten_label.setText(f"{self.pipeline.straighten:+.1f}\u00b0")

    def apply_pipeline(self):
        if self.preview_image is None:
            return
        self.update_pipeline_values()
        self._remember_current()
        if self.zoom_scale is not None and not self.preview_label.crop_mode:
            self._render_zoomed()
            return
        self.zoom_label.setText("Fit")
        # while the crop frame is being drawn, show the whole photo
        use_crop = not self.preview_label.crop_mode
        if self.pipeline.nr_luminance > 0 or self.pipeline.nr_color > 0:
            if getattr(self, "_noise_preview", None) is None:          # measured once per photo
                self._noise_preview = denoise.measure(self.preview_image.astype(np.float32) / 255.0)
            self.pipeline.noise_hint = self._noise_preview
        processed = self.pipeline.apply(self.preview_image, use_crop=use_crop)
        self.pipeline.noise_hint = None
        if self.compare_button.isChecked() and not self.preview_label.crop_mode:
            before = self.pipeline._geometry(self.preview_image, use_crop)
            processed = self._split(before, processed)
        if self.peaking_button.isChecked():
            processed = focus_peaking(processed)
        pixmap = numpy_to_pixmap(processed)
        self.preview_label.setPixmap(
            pixmap.scaled(self.preview_label.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
        )
        self._update_overlays()

    # ─────────────────────────────────────────────────

    # ───────────────────── grey picker (white balance) ─────────────────────

    def _grey_toggled(self, on):
        if on and self.preview_image is None:
            self.grey_button.setChecked(False)
            return
        if on and self.preview_label.crop_mode:
            self.cancel_crop()
        self.preview_label.setCursor(Qt.CrossCursor if on else Qt.ArrowCursor)
        self.grey_hint.setText("Now click something that should be neutral grey or white." if on else "")

    def _patch_lab(self, pos):
        """Average colour (Lab) of a small patch of the picture on screen, or None."""
        r = self.preview_label.image_rect()
        pm = self.preview_label.pixmap()
        if r is None or pm is None or not r.contains(pos):
            return None
        image = pm.toImage().convertToFormat(QImage.Format_RGB888)
        x, y = int(pos.x() - r.left()), int(pos.y() - r.top())
        x0, y0 = max(0, x - 5), max(0, y - 5)
        x1, y1 = min(image.width(), x + 6), min(image.height(), y + 6)
        if x1 <= x0 or y1 <= y0:
            return None
        patch = image.copy(x0, y0, x1 - x0, y1 - y0)
        arr = np.frombuffer(patch.constBits(), np.uint8, patch.sizeInBytes())
        arr = arr.reshape(patch.height(), patch.bytesPerLine())[:, :patch.width() * 3]
        rgb = arr.reshape(patch.height(), patch.width(), 3).astype(np.float32).mean(axis=(0, 1)) / 255.0
        return cv2.cvtColor(rgb.reshape(1, 1, 3), cv2.COLOR_RGB2Lab)[0, 0]

    def set_rating(self, stars):
        """Stars for this photo, or for all selected photos when this one is among them."""
        if self.current_file_path is None:
            return
        targets = [self.current_file_path]
        if self.current_file_path in self.selected and len(self.selected) > 1:
            targets = [p for p in self.image_files if p in self.selected]
        for path in targets:
            if stars:
                self.ratings[path] = stars
            else:
                self.ratings.pop(path, None)
            self._refresh_caption(path)
        self._paint_stars()
        self.highlight_current()
        self._edits_timer.start()
        word = STAR * stars if stars else "no stars"
        self.status_label.setText(f"{word} for {len(targets)} photo{'s' if len(targets) != 1 else ''}.")
        if self.rating_filter.currentData():
            self._show_changed()

    def _paint_stars(self):
        stars = self.ratings.get(self.current_file_path, 0) if self.current_file_path else 0
        for i, b in enumerate(getattr(self, "star_buttons", []), 1):
            b.setText("\u2605" if i <= stars else "\u2606")

    def _toggle_right_panel(self, hidden):
        self.right_outer_widget.setVisible(not hidden)
        self.panel_button.setText("\u25e8  Show Panel" if hidden else "\u25e8  Hide Panel")
        QSettings("ImageStream", "LocalRAW").setValue("panel_hidden", hidden)
        if self.preview_image is not None:
            self._preview_timer.start()

    def apply_last_edit(self):
        """This photo gets the look of the photo edited just before it."""
        if self.current_file_path is None:
            return
        last = getattr(self, "_last_edit", None)
        if not last:
            self.status_label.setText("Edit a photo first, then move to the next one and press Last Edit.")
            return
        settings = self._current_settings()
        straighten = settings["sliders"].get("straighten")
        settings["sliders"] = dict(last)
        if straighten:
            settings["sliders"]["straighten"] = straighten
        self._restore_settings(settings)
        self.apply_pipeline()
        self.status_label.setText("\u2713 Last edit applied.")

    def _large_text_toggled(self, on):
        QSettings("ImageStream", "LocalRAW").setValue("large_text", on)
        if hasattr(self, "apply_theme"):
            self.apply_theme(on)
        self._fit_to_text_size(on)

    def _fit_to_text_size(self, large):
        """Panels and the smallest window size follow the text size, so no button is ever cut off."""
        self.left_scroll.setFixedWidth(318 if large else 280)
        self.right_outer_widget.setFixedWidth(360 if large else 320)
        self.setMinimumWidth(1400 if large else 1220)

    def _set_info(self, text):
        """The file name line: shortened in the middle with "..." when there's no room, never wrapped."""
        self._info_full = text
        label = self.info_label
        width = max(20, label.width() - 4)
        label.setText(label.fontMetrics().elidedText(text, Qt.ElideMiddle, width))
        label.setToolTip(text)

    def _paint_shape_buttons(self, *_):
        for i, b in enumerate(getattr(self, "shape_buttons", [])):
            b.setChecked(i == self.crop_shape.currentIndex())

    def pick_grey(self, pos):
        peaking = self.peaking_button.isChecked()
        if peaking:                                  # read the photo, not the red peaking marks
            self.peaking_button.blockSignals(True)
            self.peaking_button.setChecked(False)
            self.peaking_button.blockSignals(False)
            self.apply_pipeline()
        try:
            self._pick_grey(pos)
        finally:
            if peaking:
                self.peaking_button.setChecked(True)

    def _pick_grey(self, pos):
        compare = self.compare_button.isChecked()
        if compare:                                  # measure the corrected picture, not the "before" half
            self.compare_button.blockSignals(True)
            self.compare_button.setChecked(False)
            self.compare_button.blockSignals(False)
            self.apply_pipeline()
        lab = self._patch_lab(pos)
        message = ""
        if lab is None:
            message = "Click on the photo itself."
        elif lab[0] < 6 or lab[0] > 98:
            message = "That spot is too dark or too bright to read. Try another one."
        else:
            # a few rounds: set, look at the same spot again, refine
            for _round in range(4):
                temp = self.temp_slider.value() - lab[2] * 50.0 / 15.0
                temp = max(-100.0, min(100.0, temp))
                a_left = lab[1] + (temp - self.temp_slider.value()) / 50.0 * 3.0
                tint = max(-100.0, min(100.0, self.tint_slider.value() - a_left * 50.0 / 15.0))
                for slider, value in ((self.temp_slider, temp), (self.tint_slider, tint)):
                    slider.blockSignals(True)
                    slider.setValue(int(round(value)))
                    slider.blockSignals(False)
                self.apply_pipeline()
                lab = self._patch_lab(pos)
                if lab is None or (abs(lab[1]) < 0.7 and abs(lab[2]) < 0.7):
                    break
            if abs(self.temp_slider.value()) == 100 or abs(self.tint_slider.value()) == 100:
                message = "That spot has a very strong colour. It may not be a neutral surface."
        if compare:
            self.compare_button.setChecked(True)
        self.grey_button.setChecked(False)
        self.grey_hint.setText(message)

    def auto_tone(self):
        if self.preview_image is None:
            return
        tone = (self.exposure_slider, self.highlights_slider, self.shadows_slider,
                self.whites_slider, self.blacks_slider)
        for slider in tone:
            slider.blockSignals(True)
            slider.setValue(0)
        self.update_pipeline_values()
        # measure the photo as it is with the other corrections, before these four
        small = self.preview_image[::2, ::2]
        out = self.pipeline.apply(small, geometry=False).astype(np.float32) / 255.0
        lum = out[..., 0] * 0.299 + out[..., 1] * 0.587 + out[..., 2] * 0.114
        stops, hl, sh, wh, bl = auto_tone_values(lum)
        for slider, value in zip(tone, (stops * 10, hl * 100, sh * 100, wh * 100, bl * 100)):
            slider.setValue(int(round(value)))
            slider.blockSignals(False)
        self.apply_pipeline()

    def reset_sliders(self):
        for slider in [
            self.temp_slider, self.tint_slider,
            self.exposure_slider, self.contrast_slider,
            self.highlights_slider, self.shadows_slider, self.whites_slider,
            self.blacks_slider, self.saturation_slider,
            self.sharpen_slider, self.nr_lum_slider,
            self.nr_color_slider, self.dehaze_slider,
            self.straighten_slider
        ]:
            slider.blockSignals(True)
            slider.setValue(0)
            slider.blockSignals(False)
        self.pipeline.reset()
        self._end_crop_mode()
        self.apply_pipeline()

    # ─────────────────────────────────────────────────

    def highlight_current(self):
        """Light up the thumbnail being edited and say which photo it is."""
        self._paint_stars()
        if QApplication.focusWidget() is None and hasattr(self, "preview_label"):
            self.preview_label.setFocus()      # keys (stars, arrows) keep working after the strip is rebuilt
        labels = getattr(self, "thumb_labels", {})
        for path, label in labels.items():
            if path == self.current_file_path:
                label.setStyleSheet(THUMB_FRAME + "border: 3px solid #f5a623;")
            elif path in self.selected:
                label.setStyleSheet(THUMB_FRAME + f"border: 3px solid {SELECT_COLOR};")
            else:
                label.setStyleSheet(THUMB_FRAME + "border: 3px solid transparent;")
        if self.current_file_path in labels:
            self.scroll_area.ensureWidgetVisible(labels[self.current_file_path])
        shown = self._shown_files()
        if self.current_file_path and self.current_file_path in shown:
            position = shown.index(self.current_file_path) + 1
            self._set_info(f"{os.path.basename(self.current_file_path)}   \u00b7   {position} of {len(shown)}")
            info = self.focus.get(self.current_file_path)
            text = ""
            if info:
                text = f"\u25cf {FOCUS_NAMES[info['cat']]}"
                if info.get("by") == "face":
                    n = len(info.get("faces") or [])
                    if info.get("behind") and info["cat"] != "sharp":
                        text += " \u2014 focus behind the face"
                    else:
                        text += " \u2014 face"
                elif self.judge_by.currentData() == "faces":
                    text += " \u2014 no face, whole photo"
                if info["cat"] != "sharp" and info["blur"] == "motion" and not info.get("behind"):
                    text += f" (maybe motion blur, {focus_check.shutter_str(info['shutter'])})"
                if info.get("burst"):
                    i, n = info["burst"]
                    star = "\u2605 best of %d" % n if info.get("best") else "burst %d/%d" % (i, n)
                    text += "   \u00b7   " + star
            # a small badge on the photo itself: always readable, takes no room from the bars
            stars = self.ratings.get(self.current_file_path, 0)
            star_text = ("   " + "\u2605" * stars) if stars else ""
            lines = [(f"{os.path.basename(self.current_file_path)}   \u00b7   {position} of {len(shown)}{star_text}", "#ececec")]
            if info:
                lines.append((text, FOCUS_COLORS[info["cat"]]))
            self.preview_label.badge_lines = lines
            self.preview_label.update()
        else:
            self._set_info("")
            self.preview_label.badge_lines = []
            self.preview_label.update()

    def show_neighbor(self, step):
        shown = self._shown_files()
        if not shown:
            return
        if self.current_file_path in shown:
            index = shown.index(self.current_file_path) + step
        else:
            index = 0
        if 0 <= index < len(shown):
            self.load_image(shown[index])

    # ─────────────────────────────────────────────────

    # ───────────────────────── zoom ─────────────────────────

    @staticmethod
    def _split(before, after):
        """Left half before the corrections, right half after, white line between."""
        out = np.ascontiguousarray(after).copy()
        h, w = out.shape[:2]
        if before.shape[:2] != (h, w):
            return out
        mid = w // 2
        out[:, :mid] = before[:, :mid]
        out[:, max(0, mid - 1):mid + 1] = 255
        return out

    def _geo_source(self):
        """Full-size photo after rotate / straighten / crop (kept until they change)."""
        p = self.pipeline
        key = (self.current_file_path, p.rotation, p.flip, p.straighten, p.crop)
        if self._geo_cache[0] != key:
            self._geo_cache = (key, p._geometry(self.current_image, True))
        return self._geo_cache[1]

    def _fit_scale(self, src):
        h, w = src.shape[:2]
        return min(self.preview_label.width() / float(w), self.preview_label.height() / float(h))

    def _render_zoomed(self):
        src = self._geo_source()
        H, W = src.shape[:2]
        s = self.zoom_scale
        lw, lh = self.preview_label.width(), self.preview_label.height()
        vw, vh = min(W, lw / s), min(H, lh / s)          # part of the photo on screen
        cx, cy = self.zoom_center or (W / 2.0, H / 2.0)
        cx = min(max(cx, vw / 2.0), W - vw / 2.0)
        cy = min(max(cy, vh / 2.0), H - vh / 2.0)
        self.zoom_center = (cx, cy)
        x0, y0 = int(cx - vw / 2.0), int(cy - vh / 2.0)
        x1, y1 = min(W, x0 + int(round(vw))), min(H, y0 + int(round(vh)))
        self._view_origin = (x0, y0)
        m = 24                                           # margin so edges are processed cleanly
        ex0, ey0, ex1, ey1 = max(0, x0 - m), max(0, y0 - m), min(W, x1 + m), min(H, y1 + m)
        region = np.ascontiguousarray(src[ey0:ey1, ex0:ex1])
        k = min(s, 1.0)
        if k < 1.0:
            region = cv2.resize(region, (max(1, int(round(region.shape[1] * k))),
                                         max(1, int(round(region.shape[0] * k)))),
                                interpolation=cv2.INTER_AREA)
        self.pipeline.noise_hint = self._region_noise(k)
        processed = self.pipeline.apply(region, geometry=False)
        self.pipeline.noise_hint = None
        ix0, iy0 = int(round((x0 - ex0) * k)), int(round((y0 - ey0) * k))
        iw, ih = max(1, int(round((x1 - x0) * k))), max(1, int(round((y1 - y0) * k)))
        view = processed[iy0:iy0 + ih, ix0:ix0 + iw]
        if self.compare_button.isChecked():
            view = self._split(region[iy0:iy0 + ih, ix0:ix0 + iw], view)
        if s > 1.0:
            view = cv2.resize(view, (int(round((x1 - x0) * s)), int(round((y1 - y0) * s))),
                              interpolation=cv2.INTER_NEAREST if s >= 3 else cv2.INTER_LINEAR)
        if self.peaking_button.isChecked():
            view = focus_peaking(view)
        view = np.ascontiguousarray(view)
        self.preview_label.setPixmap(numpy_to_pixmap(view).copy())
        self.zoom_label.setText(f"{s * 100:.0f}%")
        self._update_overlays()

    def zoom_to(self, scale, pos=None):
        if self.current_image is None or self.preview_label.crop_mode:
            return
        src = self._geo_source()
        H, W = src.shape[:2]
        fit = self._fit_scale(src)
        scale = min(scale, max(4.0, fit))
        if scale <= fit * 1.01 and fit <= 1.0:
            return self.zoom_fit()
        r = self.preview_label.image_rect()
        if pos is not None and r is not None and r.contains(pos):
            # keep the spot under the pointer where it is
            if self.zoom_scale is None:
                px = (pos.x() - r.left()) / r.width() * W
                py = (pos.y() - r.top()) / r.height() * H
            else:
                px = self._view_origin[0] + (pos.x() - r.left()) / self.zoom_scale
                py = self._view_origin[1] + (pos.y() - r.top()) / self.zoom_scale
            lw, lh = self.preview_label.width(), self.preview_label.height()
            self.zoom_center = (px - (pos.x() - lw / 2.0) / scale, py - (pos.y() - lh / 2.0) / scale)
        elif self.zoom_center is None:
            self.zoom_center = (W / 2.0, H / 2.0)
        self.zoom_scale = scale
        self.apply_pipeline()

    def zoom_by(self, factor, pos=None):
        if self.current_image is None or self.preview_label.crop_mode:
            return
        current = self.zoom_scale or self._fit_scale(self._geo_source())
        self.zoom_to(current * factor, pos)

    def zoom_fit(self):
        self.zoom_scale = None
        self.zoom_center = None
        self.apply_pipeline()

    def toggle_zoom(self, pos=None):
        """Click on the photo: jump to 100 % on that spot; click again for the whole photo."""
        if self.grey_button.isChecked():
            return self.pick_grey(pos)
        if self.zoom_scale is None:
            self.zoom_to(1.0, pos)
        else:
            self.zoom_fit()

    # ───────────────────── noise: measured per photo ─────────────────────

    def _measure_noise_later(self):
        QTimer.singleShot(0, self._measure_noise)

    def _measure_noise(self):
        if self.current_image is None or self._noise_full is not None:
            return
        rgb = self.current_image.astype(np.float32) / 255.0 if self.current_image.dtype == np.uint8 \
            else self.current_image.astype(np.float32)
        self._noise_full = denoise.measure(rgb)
        self.noise_label.setText(f"Noise: {denoise.describe(self._noise_full['L'])}")

    def _region_noise(self, k):
        """Noise of the full photo, for a piece of it shown at scale k."""
        self._measure_noise()
        n = self._noise_full
        if not n:
            return None
        if k >= 0.999:
            return n
        # shrinking a picture averages pixels together, which lowers its noise
        return {c: v * max(k, 0.05) for c, v in n.items()}

    def auto_noise(self):
        if self.current_image is None:
            return
        self._measure_noise()
        lum, col = denoise.suggest(self._noise_full)
        self.nr_lum_slider.setValue(lum)
        self.nr_color_slider.setValue(col)
        self.apply_pipeline()
        self.status_label.setText(f"Noise {denoise.describe(self._noise_full['L'])}: "
                                  f"luminance {lum}, colour {col}.")

    # ───────────────────── Auto Neutral (white balance) ─────────────────────

    def auto_neutral(self):
        if self.preview_image is None:
            return
        before = (self.temp_slider.value(), self.tint_slider.value())
        self.update_pipeline_values()
        look = self.pipeline.apply(self.preview_image, use_crop=False)
        result = auto_neutral.estimate(look)
        if result["light"] is None:
            self.grey_hint.setText(result["reason"] + " Try Pick Neutral on something white or grey.")
            return
        temp, tint = auto_neutral.sliders_for(result["light"], *before)
        boxes = [f["box"] for f in (self.focus.get(self.current_file_path) or {}).get("faces", [])]
        if not boxes:
            boxes = self._find_faces(look)
        note = ""
        for strength in (1.0, 0.5):
            t = before[0] + (temp - before[0]) * strength
            n = before[1] + (tint - before[1]) * strength
            self._set_wb(t, n)
            self.update_pipeline_values()
            if auto_neutral.skin_ok(self.pipeline.apply(self.preview_image, use_crop=False), boxes):
                if strength < 1.0:
                    note = " Softened so skin stays natural."
                break
        else:
            self._set_wb(*before)
            self.apply_pipeline()
            self.grey_hint.setText("Not applied: it would make skin look unnatural. Try Pick Neutral.")
            return
        self.apply_pipeline()
        sure = {"high": "Sure", "medium": "Fairly sure"}[result["confidence"]]
        self.grey_hint.setText(f"\u2713 {sure}: {result['reason']}{note}")

    def _set_wb(self, temp, tint):
        for slider, value in ((self.temp_slider, temp), (self.tint_slider, tint)):
            slider.blockSignals(True)
            slider.setValue(int(round(value)))
            slider.blockSignals(False)

    @staticmethod
    def _find_faces(rgb):
        try:
            if not subject_focus.face_finder_available():
                return []
            img = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
            h, w = img.shape[:2]
            det = subject_focus._detector()
            det.setInputSize((w, h))
            _n, found = det.detect(img)
            if found is None:
                return []
            return [[f[0] / w, f[1] / h, f[2] / w, f[3] / h] for f in found if f[14] >= 0.8 and f[2] >= 20]
        except Exception:
            return []

    # ───────────────────── face frames on the photo ─────────────────────

    def _update_overlays(self):
        label = self.preview_label
        boxes = []
        info = self.focus.get(self.current_file_path) if self.current_file_path else None
        p = self.pipeline
        plain = not (p.rotation % 4 or p.flip or p.crop or abs(p.straighten) > 1e-6)
        if (getattr(self, "faces_button", None) is not None and self.faces_button.isChecked()
                and info and info.get("faces") and plain and not label.crop_mode):
            r = label.image_rect()
            if r is not None:
                sharp_t = info.get("sharp_t") or 1.0
                fix_t = sharp_t * 0.5
                for face in info["faces"]:
                    fx, fy, fw, fh = face["box"]
                    if self.zoom_scale is None:
                        rect = (r.left() + fx * r.width(), r.top() + fy * r.height(), fw * r.width(), fh * r.height())
                    else:
                        H, W = self._geo_source().shape[:2]
                        rect = (r.left() + (fx * W - self._view_origin[0]) * self.zoom_scale,
                                r.top() + (fy * H - self._view_origin[1]) * self.zoom_scale,
                                fw * W * self.zoom_scale, fh * H * self.zoom_scale)
                    cat = "sharp" if face["score"] >= sharp_t else "fixable" if face["score"] >= fix_t else "rejected"
                    boxes.append((rect, FOCUS_COLORS[cat], FOCUS_NAMES[cat]))
        label.face_boxes = boxes
        label.update()

    # ───────────────────── loupe (magnifier under the pointer) ─────────────────────

    LOUPE_SIZE = 260      # pixels on screen
    LOUPE_ZOOM = 2.0      # 200 %: every pixel of the photo shown as 2 x 2

    def _loupe_toggled(self, on):
        self.preview_label.loupe_on = on
        if not on:
            self.preview_label.set_loupe(None, None)
        self.preview_label.setCursor(Qt.CrossCursor if on else Qt.ArrowCursor)

    def _loupe_moved(self, pos):
        self._loupe_at = pos
        if not self._loupe_timer.isActive():
            self._loupe_timer.start()

    def _photo_point(self, pos):
        """Which pixel of the full-size photo (after rotate / straighten / crop) is under the pointer."""
        r = self.preview_label.image_rect()
        if r is None or not r.contains(pos):
            return None
        src = self._geo_source()
        H, W = src.shape[:2]
        if self.zoom_scale is None:
            return (pos.x() - r.left()) / r.width() * W, (pos.y() - r.top()) / r.height() * H
        return (self._view_origin[0] + (pos.x() - r.left()) / self.zoom_scale,
                self._view_origin[1] + (pos.y() - r.top()) / self.zoom_scale)

    def _draw_loupe(self):
        pos = self._loupe_at
        if self.current_image is None or pos is None or self.preview_label.crop_mode:
            return
        point = self._photo_point(pos)
        if point is None:
            self.preview_label.set_loupe(None, None)
            return
        src = self._geo_source()
        H, W = src.shape[:2]
        half = int(self.LOUPE_SIZE / self.LOUPE_ZOOM / 2)
        cx, cy = int(point[0]), int(point[1])
        m = 24                                     # margin so edges are processed cleanly
        x0, y0 = max(0, cx - half - m), max(0, cy - half - m)
        x1, y1 = min(W, cx + half + m), min(H, cy + half + m)
        region = np.ascontiguousarray(src[y0:y1, x0:x1])
        if region.size == 0:
            return
        self.pipeline.noise_hint = self._region_noise(1.0)
        out = self.pipeline.apply(region, geometry=False)
        self.pipeline.noise_hint = None
        # place the piece on a dark square so the spot under the pointer stays centred
        canvas = np.full((2 * half, 2 * half, 3), 30, np.uint8)
        sx0, sy0 = cx - half - x0, cy - half - y0
        ox, oy = max(0, -sx0), max(0, -sy0)
        piece = out[max(0, sy0):max(0, sy0) + 2 * half - oy, max(0, sx0):max(0, sx0) + 2 * half - ox]
        canvas[oy:oy + piece.shape[0], ox:ox + piece.shape[1]] = piece
        big = cv2.resize(canvas, (self.LOUPE_SIZE, self.LOUPE_SIZE), interpolation=cv2.INTER_NEAREST)
        self.preview_label.set_loupe(numpy_to_pixmap(np.ascontiguousarray(big)).copy(), pos,
                                     f"{self.LOUPE_ZOOM * 100:.0f}%")

    # ───────────────────── save ─────────────────────

    def _final_name(self, path, out_dir, ext=".jpg"):
        """Name of the finished copy: same name as the original. If a RAW and a JPEG
        of the same shot are both in the folder, the copy of the RAW says so."""
        stem, src_ext = os.path.splitext(os.path.basename(path))
        twins = [p for p in self.image_files
                 if p != path and os.path.splitext(os.path.basename(p))[0] == stem]
        if twins and is_raw(path):
            stem = f"{stem}_{src_ext.lstrip('.').upper()}"
        return os.path.join(out_dir, stem + ext)

    def save_now(self):
        """Save the finished photo as a full-size JPEG copy in the 'Edited' folder."""
        path = self.current_file_path
        if path is None or self.current_image is None:
            return
        self._remember_current()
        self._save_edits_file()
        out_dir = os.path.join(self.folder or os.path.dirname(path), "Edited")
        QApplication.setOverrideCursor(Qt.WaitCursor)
        self.status_label.setText("Saving...")
        QApplication.processEvents()
        try:
            os.makedirs(out_dir, exist_ok=True)
            target = self._final_name(path, out_dir)
            if os.path.abspath(target) == os.path.abspath(path):     # never write over the original
                raise ValueError("the copy would replace the original")
            processed = settings_to_pipeline(self.edits.get(path), Pipeline()).apply(self.current_image)
            exif = with_meta(camera_exif(path), (self.edits.get(path) or {}).get("meta"), self.ratings.get(path))
            self.exporter.save(processed, target, quality=95, exif=exif)
        except Exception as e:
            QApplication.restoreOverrideCursor()
            self.status_label.setText("Not saved.")
            QMessageBox.critical(self, "Save", f"Could not save the copy:\n{e}")
            return
        QApplication.restoreOverrideCursor()
        self.saved_copies[path] = target
        self.saved_settings[path] = json.loads(json.dumps(self.edits.get(path)))
        self._refresh_caption(path)
        self.status_label.setText(f"\u2713 Saved: Edited/{os.path.basename(target)}")
        self.save_button.setText("\u2713  Saved")
        QTimer.singleShot(1800, lambda: self.save_button.setText("\U0001F4BE  Save"))

    def pan_view(self, dx, dy):
        if self.zoom_scale is None or self.zoom_center is None:
            return
        self.zoom_center = (self.zoom_center[0] - dx / self.zoom_scale,
                            self.zoom_center[1] - dy / self.zoom_scale)
        self.apply_pipeline()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if getattr(self, "_info_full", None):
            QTimer.singleShot(0, lambda: self._set_info(self._info_full))
        if getattr(self, "preview_image", None) is not None:
            self._preview_timer.start()


    def _relayout_thumbs(self):
        if self._wanted_thumb_cols() != getattr(self, "_thumb_cols", 0):
            self.display_thumbnails()

    def _crop_aspect(self):
        value = self.crop_shape.currentData()
        if value == "orig":
            r = self.preview_label.image_rect()
            return (r.width() / r.height()) if r is not None and r.height() else None
        return value

    def _end_crop_mode(self):
        self.preview_label.set_crop_mode(False)
        self.crop_button.setText("\u2702  Crop")
        self.crop_cancel_button.setVisible(False)
        self.crop_hint.setText("")
        self.crop_hint.setVisible(False)
        self.crop_bar.setVisible(False)
        self.level_bar.setVisible(False)

    def toggle_crop(self):
        if self.preview_image is None:
            return
        label = self.preview_label
        self.grey_button.setChecked(False)
        self.loupe_button.setChecked(False)
        if not label.crop_mode:
            # start: show the whole photo with a frame on it
            self.zoom_scale = None
            label.crop_mode = True
            self.apply_pipeline()
            label.aspect = self._crop_aspect()
            label.selection = self.pipeline.crop or label.default_selection()
            label.set_crop_mode(True)
            self.crop_button.setText("\u2713  Apply")
            self.crop_cancel_button.setVisible(True)
            self.crop_hint.setText("Choose a shape, straighten if needed, pull the corners or sides, "
                                   "drag inside the frame to move it, then press Apply.")
            self.crop_hint.setVisible(False)       # the hint goes to the status line: more room for the photo
            self.status_label.setText(self.crop_hint.text())
            self.crop_bar.setVisible(True)
            self.level_bar.setVisible(True)
        else:
            sel = label.selection
            full = sel is None or (sel[0] <= 0.001 and sel[1] <= 0.001 and sel[2] >= 0.999 and sel[3] >= 0.999)
            self.pipeline.crop = None if full else sel
            self._end_crop_mode()
            self.apply_pipeline()

    def cancel_crop(self):
        self._end_crop_mode()
        self.apply_pipeline()

    def clear_crop(self):
        self.pipeline.crop = None
        self._end_crop_mode()
        self.apply_pipeline()

    def crop_shape_changed(self):
        label = self.preview_label
        if label.crop_mode:
            label.aspect = self._crop_aspect()
            label.selection = label.default_selection()
            label.update()

    def rotate_image(self, direction):
        if self.preview_image is None:
            return
        self.pipeline.rotation = (self.pipeline.rotation + direction) % 4
        self.pipeline.crop = None      # the frame no longer fits a turned photo
        self._end_crop_mode()
        self.apply_pipeline()

    def flip_image(self):
        if self.preview_image is None:
            return
        self.pipeline.flip = not self.pipeline.flip
        if self.pipeline.crop:
            x0, y0, x1, y1 = self.pipeline.crop
            self.pipeline.crop = (1 - x1, y0, 1 - x0, y1)
        self.apply_pipeline()

    # ─────────────────────────────────────────────────

    def delete_current_photo(self):
        path = self.current_file_path
        if not path:
            QMessageBox.information(self, "Delete Photo", "Click a photo first, then delete it.")
            return
        name = os.path.basename(path)
        answer = QMessageBox.question(
            self, "Delete Photo",
            f"Move '{name}' to the Trash?\n\nYou can restore it from the Trash if you change your mind.",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if answer != QMessageBox.Yes:
            return
        try:
            from send2trash import send2trash
            send2trash(path)
        except Exception as e:
            QMessageBox.critical(self, "Delete Photo", f"Could not move the photo to the Trash.\n\n{e}")
            return
        shown = self._shown_files()
        index = shown.index(path) if path in shown else 0
        if path in self.image_files:
            self.image_files.remove(path)
        self.focus.pop(path, None)
        self._thumb_cache.pop(path, None)
        if self.edits.pop(path, None) is not None:
            self._edits_timer.start()
        self.selected.discard(path)
        self.ratings.pop(path, None)
        self._update_focus_summary()
        self.current_image = None
        self.current_file_path = None
        self.preview_image = None
        self.preview_label.clear()
        self.preview_label.setText("Photo moved to the Trash")
        self.display_thumbnails()
        shown = self._shown_files()
        if shown:
            self.load_image(shown[min(index, len(shown) - 1)])

    # ─────────────────────────────────────────────────

    def export_image(self):
        """Lightroom-style export: tick the photos, choose the settings, export."""
        if not self.image_files and self.current_file_path is None:
            QMessageBox.warning(self, "Export", "Open a folder first.")
            return
        self._remember_current()
        files = self.image_files or [self.current_file_path]
        order = list(self._shown_files()) + [p for p in files if p not in self._shown_files()]
        photos = []
        for path in order:
            pixmap = self._thumb_cache.get(path)
            if pixmap is None:
                pixmap = make_thumbnail(path)
                self._thumb_cache[path] = pixmap
            note, color = self._caption_for(path)
            stars = self.ratings.get(path, 0)
            note = ("\u2605" * stars + "  " if stars else "") + note.replace("\u2713", "").strip()
            photos.append((path, pixmap, note.strip(), color if self.focus.get(path) else None))
        checked = set(self.selected) or ({self.current_file_path} if self.current_file_path else set())
        dialog = ExportDialog(self, photos, checked, self.folder)
        if dialog.exec() != QDialog.Accepted:
            return
        self.export_photos(dialog.options())

    def export_photos(self, opts):
        paths, out_dir = opts["paths"], opts["out_dir"]
        ext = {"JPEG": ".jpg", "TIFF": ".tif", "PNG": ".png"}[opts.get("fmt", "JPEG")]
        try:
            os.makedirs(out_dir, exist_ok=True)
        except Exception as e:
            QMessageBox.critical(self, "Export", f"Could not create the folder:\n{out_dir}\n\n{e}")
            return 0
        progress = QProgressDialog("Exporting...", "Stop", 0, len(paths), self)
        progress.setWindowTitle("Export")
        progress.setWindowModality(Qt.WindowModal)
        progress.setMinimumDuration(0)
        done, skipped, failed = 0, 0, []
        for i, path in enumerate(paths):
            if progress.wasCanceled():
                break
            progress.setLabelText(f"Exporting {i + 1} of {len(paths)}:  {os.path.basename(path)}")
            progress.setValue(i)
            QApplication.processEvents()
            try:
                base = name_for(path, i, opts.get("naming", 0), opts.get("custom", ""), opts.get("start", 1))
                target = os.path.join(out_dir, base + ext)
                same_as_original = os.path.abspath(target) == os.path.abspath(path)
                if os.path.exists(target) or same_as_original:
                    policy = opts.get("existing", 0)
                    if policy == 2 and not same_as_original:          # skip
                        skipped += 1
                        continue
                    if policy == 0 or same_as_original:              # keep both: new name
                        n = 1
                        while os.path.exists(target) or os.path.abspath(target) == os.path.abspath(path):
                            target = os.path.join(out_dir, f"{base}-{n}{ext}")
                            n += 1
                if path == self.current_file_path and self.current_image is not None:
                    image = self.current_image
                else:
                    image = self.raw_loader.load_image(path)
                processed = settings_to_pipeline(self.edits.get(path), Pipeline()).apply(image)
                mode = opts.get("meta", "all")
                exif = camera_exif(path, mode, opts.get("no_location", False))
                if mode != "none":
                    mine = (self.edits.get(path) or {}).get("meta") or {}
                    if mode == "copyright":
                        mine = {k: v for k, v in mine.items() if k in ("artist", "copyright")}
                    exif = with_meta(exif, mine, self.ratings.get(path))
                self.exporter.save(processed, target, quality=opts.get("quality", 92),
                                   long_edge=opts.get("long_edge") if opts.get("resize_on") else None,
                                   exif=exif, sharpen=opts.get("sharpen"),
                                   max_kb=opts.get("max_kb") if opts.get("limit_on") else None)
                done += 1
            except Exception as e:
                failed.append(f"{os.path.basename(path)}: {e}")
        progress.setValue(len(paths))
        progress.close()
        text = f"Exported {done} photo{'s' if done != 1 else ''} to:\n{out_dir}"
        if skipped:
            text += f"\n\n{skipped} skipped because they were already there."
        if failed:
            text += f"\n\n{len(failed)} could not be exported:\n" + "\n".join(failed[:5])
        self.status_label.setText(f"\u2713 Exported {done} photo{'s' if done != 1 else ''}.")
        if opts.get("open_after") and done:
            QDesktopServices.openUrl(QUrl.fromLocalFile(out_dir))
        if failed or skipped or not opts.get("open_after"):
            QMessageBox.information(self, "Export", text)
        return done

    # ─────────────────────────────────────────────────

    def open_batch_rename(self):
        if not self.image_files:
            QMessageBox.warning(self, "Batch Rename", "No folder loaded.")
            return

        dialog = QDialog(self)
        dialog.setWindowTitle("Batch Rename")
        dialog.setMinimumWidth(500)
        layout = QFormLayout()

        pattern_input = QLineEdit("{prefix}_{date}_{n}")
        prefix_input = QLineEdit()
        preview_box = QTextEdit()
        preview_box.setReadOnly(True)
        preview_box.setMaximumHeight(200)

        def update_preview():
            results = self.batch_renamer.preview(
                self.image_files,
                pattern_input.text(),
                prefix_input.text()
            )
            lines = [f"{os.path.basename(old)} → {new}" for old, new in results[:10]]
            if len(self.image_files) > 10:
                lines.append(f"... and {len(self.image_files) - 10} more")
            preview_box.setText("\n".join(lines))

        pattern_input.textChanged.connect(update_preview)
        prefix_input.textChanged.connect(update_preview)

        layout.addRow("Pattern:", pattern_input)
        layout.addRow("Prefix:", prefix_input)
        layout.addRow("Preview:", preview_box)

        hint = QLabel("Tokens: {name} {n} {date} {prefix} {ext}")
        hint.setStyleSheet("color: #888; font-size: 11px;")
        layout.addRow(hint)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addRow(buttons)

        dialog.setLayout(layout)
        update_preview()

        if dialog.exec() == QDialog.Accepted:
            self._remember_current()
            results = self.batch_renamer.execute(
                self.image_files,
                pattern_input.text(),
                prefix_input.text()
            )
            moved = {old: new for old, new, ok, _ in results if ok and old != new}
            self._follow_renames(moved)
            success = sum(1 for _, _, ok, _ in results if ok)
            failed = [(old, err) for old, _, ok, err in results if not ok]
            msg = f"{success} files renamed successfully. Their edits went with them."
            if failed:
                msg += f"\n{len(failed)} failed."
            QMessageBox.information(self, "Batch Rename", msg)

    def _follow_renames(self, moved):
        """After renaming files on disk, everything LocalRAW knows follows the new names."""
        if not moved:
            return
        fix = lambda p: moved.get(p, p)
        self.image_files = [fix(p) for p in self.image_files]
        for table in (self.edits, self.focus, self._thumb_cache, self.saved_copies, self.saved_settings, self.ratings):
            for old, new in moved.items():
                if old in table:
                    table[new] = table.pop(old)
        self.selected = {fix(p) for p in self.selected}
        self.current_file_path = fix(self.current_file_path) if self.current_file_path else None
        self._last_clicked = fix(self._last_clicked) if self._last_clicked else None
        self._save_edits_file()
        self.display_thumbnails()

    # ─────────────────────────────────────────────────

    def open_watermark(self):
        if self.current_image is None:
            QMessageBox.warning(self, "Watermark", "No image loaded.")
            return

        dialog = QDialog(self)
        dialog.setWindowTitle("Add Watermark")
        layout = QFormLayout()

        text_input = QLineEdit("© Your Name")
        position_combo = QComboBox()
        position_combo.addItems(self.watermarker.POSITIONS)
        position_combo.setCurrentText("bottom_right")

        opacity_slider = QSlider(Qt.Horizontal)
        opacity_slider.setRange(10, 100)
        opacity_slider.setValue(60)

        layout.addRow("Text:", text_input)
        layout.addRow("Position:", position_combo)
        layout.addRow("Opacity:", opacity_slider)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addRow(buttons)
        dialog.setLayout(layout)

        if dialog.exec() == QDialog.Accepted:
            self.update_pipeline_values()
            processed = self.pipeline.apply(self.current_image)
            watermarked = self.watermarker.apply_text(
                processed,
                text=text_input.text(),
                position=position_combo.currentText(),
                opacity=opacity_slider.value() / 100.0
            )
            path, _ = QFileDialog.getSaveFileName(
                self, "Export Watermarked Image", "", "JPEG (*.jpg);;PNG (*.png)"
            )
            if path:
                self.exporter.save(watermarked, path)
                QMessageBox.information(self, "Watermark", "Watermarked image exported.")

    # ─────────────────────────────────────────────────

    def open_metadata(self):
        """Author, copyright and caption. Kept with the edits and written into
        saved and exported copies; the original file is never changed."""
        if not self.current_file_path:
            QMessageBox.warning(self, "Metadata", "No image loaded.")
            return
        dialog = QDialog(self)
        dialog.setWindowTitle("Metadata")
        dialog.setMinimumWidth(480)
        layout = QFormLayout()
        exif_box = QTextEdit(self.metadata_editor.summary(self.current_file_path))
        exif_box.setReadOnly(True)
        exif_box.setMaximumHeight(160)
        mine = (self.edits.get(self.current_file_path) or {}).get("meta", {})
        camera = self._camera_meta(self.current_file_path)
        artist_input = QLineEdit(mine.get("artist", camera.get("artist", "")))
        copyright_input = QLineEdit(mine.get("copyright", camera.get("copyright", "")))
        description_input = QLineEdit(mine.get("description", camera.get("description", "")))
        layout.addRow("Camera data:", exif_box)
        layout.addRow("Author:", artist_input)
        layout.addRow("Copyright:", copyright_input)
        layout.addRow("Caption:", description_input)
        apply_to = QComboBox()
        apply_to.addItem("This photo", [self.current_file_path])
        if self.selected:
            apply_to.addItem(f"Selected photos ({len(self.selected)})",
                             [p for p in self.image_files if p in self.selected])
        if len(self.image_files) > 1:
            apply_to.addItem(f"All photos in this folder ({len(self.image_files)})", list(self.image_files))
        layout.addRow("Apply to:", apply_to)
        note = QLabel("Written into the copies you Save and Export. Your original files are never changed.")
        note.setWordWrap(True)
        note.setStyleSheet("color: #888; font-size: 11px;")
        layout.addRow(note)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addRow(buttons)
        dialog.setLayout(layout)
        if dialog.exec() != QDialog.Accepted:
            return
        meta = {k: v.strip() for k, v in (("artist", artist_input.text()), ("copyright", copyright_input.text()),
                                           ("description", description_input.text())) if v.strip()}
        targets = apply_to.currentData()
        for path in targets:
            settings = dict(self.edits.get(path) or {"sliders": {}})
            if meta:
                settings["meta"] = meta
            else:
                settings.pop("meta", None)
            if self._is_untouched(settings):
                self.edits.pop(path, None)
            else:
                self.edits[path] = settings
            self._refresh_caption(path)
        self._save_edits_file()
        self.status_label.setText(f"Metadata kept for {len(targets)} photo{'s' if len(targets) != 1 else ''}.")

    @staticmethod
    def _camera_meta(path):
        """Author, copyright and caption already in the camera file, to start from."""
        out = {}
        try:
            import piexif
            exif = camera_exif(path)
            data = piexif.load(exif) if exif else {}
            for key, tag in (("artist", 315), ("copyright", 33432), ("description", 270)):
                value = data.get("0th", {}).get(tag)
                if value:
                    out[key] = value.decode("utf-8", "ignore").strip("\x00 ")
        except Exception:
            pass
        return out
