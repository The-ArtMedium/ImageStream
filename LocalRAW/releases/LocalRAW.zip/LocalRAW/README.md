# LocalRAW

> **Professional RAW photo editing. No internet. No subscription. No compromise.**

Part of the [ImageStream](https://imagestream.com) creative suite.

---

## The Images Never Leave Your Drive.

LocalRAW is a free, open, local RAW photo editor built for photographers who work in the real world — in the field, in low-bandwidth regions, in schools without budgets, and in situations where privacy is not optional.

No cloud. No upload. No monthly fee. Ever.

---

## Features

| Tool | Description |
|------|-------------|
| **RAW Support** | CR2, NEF, ARW, DNG + JPG, PNG |
| **White Balance** | LAB colorspace temperature & tint |
| **Exposure** | Real stops-based control |
| **Contrast** | S-curve on luminance channel |
| **Noise Reduction** | Luminance (NL-means) + Color (LAB) |
| **Sharpen** | Luminance-only unsharp mask |
| **Dehaze** | Dark channel prior algorithm |
| **Batch Rename** | Pattern-based with live preview |
| **Watermark** | Text with position & opacity control |
| **Metadata Editor** | Read EXIF, write Artist/Copyright |
| **Live Preview** | Debounced, downscaled, instant |
| **Export** | JPEG 95% or lossless PNG |

---

## Who It's For

- 📸 **Photojournalists** — edit pitchside, transmit before the competition
- 🌍 **Photographers in emerging markets** — no cloud bills, no bandwidth costs
- 🎓 **Schools** — one USB drive, 30 students, zero ongoing cost
- 🐎 **Equestrian & sport** — no wifi at the arena, no problem
- 🎭 **Performing arts** — subjects' faces never reach a corporate server
- 🌿 **Documentary & nature** — remote locations, zero connectivity required

---

## Why Local?

When you upload a RAW file to a cloud editor you agree — in terms of service most people never read — that your images can be analyzed, stored, and in some cases used to train AI systems. Your metadata (GPS, timestamps, faces) travels with every file.

LocalRAW never connects to the internet. Not for licensing. Not for updates. Not for telemetry. Nothing.

**Your work belongs to you.**

---

## Languages

Available on day one in **5 languages**:

🇬🇧 English · 🇪🇸 Español · 🇧🇷 Português · 🇸🇦 العربية · 🇮🇳 हिन्दी

---

## Installation

### Run from source

```bash
git clone https://github.com/yourname/LocalRAW.git
cd LocalRAW
pip install -r requirements.txt
python main.py
```

### Requirements

```
PySide6
rawpy
numpy
opencv-python
Pillow
piexif
```

### Standalone builds

See [BUILD_GUIDE.md](BUILD_GUIDE.md) for instructions to build:

- `LocalRAW.exe` — Windows single file
- `LocalRAW-Setup.exe` — Windows installer wizard
- `LocalRAW.app` — macOS app bundle
- `LocalRAW-1.0.0-macOS.dmg` — macOS drag-to-install

---

## Project Structure

```
LocalRAW/
├── main.py                         # Entry point
├── requirements.txt
├── LocalRAW.spec                   # PyInstaller config
├── BUILD_GUIDE.md
├── app/
│   ├── config.py
│   ├── core/
│   │   ├── pipeline.py             # Image processing engine
│   │   ├── raw_loader.py           # RAW + standard image loader
│   │   ├── exporter.py             # JPG / PNG export
│   │   ├── batch_renamer.py        # Batch rename with patterns
│   │   ├── watermarker.py          # Text & image watermarking
│   │   └── metadata_editor.py      # EXIF read / write
│   ├── ui/
│   │   ├── main_window.py          # Main application window
│   │   ├── controls_panel.py
│   │   └── preview_widget.py
│   └── utils/
│       ├── file_utils.py
│       └── image_utils.py
├── resources/
│   ├── style.qss                   # Dark theme stylesheet
│   └── translations/
│       ├── en.json
│       ├── es.json
│       ├── pt.json
│       ├── ar.json
│       └── hi.json
└── installer/
    ├── windows.iss                 # Inno Setup script
    ├── build_windows.bat
    └── build_mac.sh
```

---

## Part of the ImageStream Suite

LocalRAW is one tool in a growing suite built on the same philosophy — local, private, free:

| Tool | Description | Status |
|------|-------------|--------|
| **LocalRAW** | RAW photo editor | ✅ Released |
| **LocalClip** | Precision video trimming, lossless | 🔧 In development |
| **LocalEdit** | 4-layer video editor with audio | 🔧 In development |
| **Bokeh Studio Pro** | Creative depth & bokeh tools | 🔧 In development |
| **ImageStream Archival Scanner** | Athlete & archive management | 🔧 In development |

---

## License

Free to use for personal and professional purposes.  
See [LICENSE](LICENSE) for details.

---

## Philosophy

> *Give the best for nothing. That is a brilliant form of freedom.*

Built with focus on independence and creative freedom.  
For the photographer in Lagos. For the student in São Paulo. For the journalist with one shot and a phone hotspot.

---

*Built by [ImageStream](https://imagestream.com)*
