import os
import sys

from PySide6.QtCore import QSettings
from PySide6.QtWidgets import QApplication

from app.ui.main_window import MainWindow


def resource(*parts):
    """A file shipped with the app, found both when run from source and when installed."""
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, "resources", *parts)


def apply_theme(app, large_text=None):
    """The suite's dark, high-contrast look. Large text makes everything easier to read."""
    if large_text is None:
        large_text = QSettings("ImageStream", "LocalRAW").value("large_text", False, type=bool)
    try:
        with open(resource("style.qss"), encoding="utf-8") as f:
            sheet = f.read()
    except Exception:
        return
    app.setStyleSheet(sheet.replace("{FONT}", "17" if large_text else "14"))


def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")                 # the same look on Mac and Windows
    apply_theme(app)
    window = MainWindow()
    window.apply_theme = lambda large: apply_theme(app, large)
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
