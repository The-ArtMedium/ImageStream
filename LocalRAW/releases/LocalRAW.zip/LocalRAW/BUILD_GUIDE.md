# LocalRAW — Build & Distribution Guide

## What You'll End Up With

| Platform | File | What it does |
|----------|------|--------------|
| Windows | `LocalRAW.exe` | Single file, double-click to run |
| Windows | `LocalRAW-Setup.exe` | Installer wizard (like real software) |
| macOS | `LocalRAW.app` | Double-click app bundle |
| macOS | `LocalRAW-1.0.0-macOS.dmg` | Drag to Applications installer |

---

## WINDOWS BUILD

### Step 1 — Install requirements

Open Command Prompt in the project folder and run:

```
pip install pyinstaller
pip install -r requirements.txt
```

### Step 2 — Build the .exe

Double-click `installer/build_windows.bat`
OR run in terminal:
```
pyinstaller LocalRAW.spec --clean
```

Your `LocalRAW.exe` will appear in the `dist/` folder.

### Step 3 — Create the installer wizard

1. Download and install **Inno Setup** from: https://jrsoftware.org/isinfo.php
2. Open Inno Setup
3. Open file: `installer/windows.iss`
4. Click **Build → Compile**
5. Your installer appears at: `dist/installer/LocalRAW-Setup-1.0.0-Windows.exe`

---

## macOS BUILD

### Step 1 — Install requirements

Open Terminal in the project folder and run:

```bash
pip install pyinstaller
pip install -r requirements.txt
brew install create-dmg
```

If you don't have Homebrew: https://brew.sh

### Step 2 — Run the build script

```bash
chmod +x installer/build_mac.sh
./installer/build_mac.sh
```

This will:
- Build `LocalRAW.app` using PyInstaller
- Package it into `LocalRAW-1.0.0-macOS.dmg`

Both files appear in the `dist/` folder.

---

## ICONS (Required before building)

You need two icon files in the `resources/` folder:

| File | Platform | Size |
|------|----------|------|
| `resources/icon.ico` | Windows | 256x256 recommended |
| `resources/icon.icns` | macOS | Use Image2icon or iconutil |

You can create these from any PNG using:
- Windows: https://convertico.com
- macOS: `iconutil` (built into macOS) or https://image2icon.com

---

## OPTIONAL: macOS DMG Background

If you want a custom background image in the DMG (the drag-to-install window):
- Create a PNG at `resources/dmg_background.png`
- Recommended size: 600×400 px
- If you skip this, remove the `--background` line from `build_mac.sh`

---

## NOTES

- You must build on the target platform: build Windows .exe on Windows, macOS .app on a Mac
- PyInstaller bundles everything — users need no Python installed
- The .spec file handles both platforms automatically
