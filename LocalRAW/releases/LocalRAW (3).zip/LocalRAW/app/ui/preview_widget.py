from PySide6.QtWidgets import QLabel
from PySide6.QtCore import Qt, QRectF, QPointF, QEvent, Signal
from PySide6.QtGui import QPainter, QColor, QPen


class PreviewWidget(QLabel):
    def __init__(self):
        super().__init__()
        self.setAlignment(Qt.AlignCenter)
        self.setText("Preview Area")
        self.setStyleSheet("background-color: #222; color: white;")


class CropLabel(QLabel):
    """Preview that lets the user drag a crop rectangle over the photo.

    The selection is kept as fractions of the picture (x0, y0, x1, y1),
    so it works the same on the small preview and the full-size export."""

    zoomRequested = Signal(float, QPointF)   # factor, position of the pointer
    panned = Signal(float, float)            # pixels dragged
    doubleClicked = Signal(QPointF)

    def __init__(self, text=""):
        super().__init__(text)
        self._pan_from = None
        self.crop_mode = False
        self.aspect = None        # width / height, or None for free shape
        self.selection = None     # (x0, y0, x1, y1) in 0..1
        self._anchor = None

    def set_crop_mode(self, on):
        self.crop_mode = on
        self._anchor = None
        self.setCursor(Qt.CrossCursor if on else Qt.ArrowCursor)
        self.update()

    def image_rect(self):
        pm = self.pixmap()
        if pm is None or pm.isNull():
            return None
        w, h = pm.width(), pm.height()
        return QRectF((self.width() - w) / 2.0, (self.height() - h) / 2.0, w, h)

    def default_selection(self):
        """Biggest centred rectangle of the chosen shape."""
        r = self.image_rect()
        if r is None or not self.aspect:
            return (0.0, 0.0, 1.0, 1.0)
        w, h = r.width(), r.height()
        cw = min(w, h * self.aspect)
        ch = cw / self.aspect
        x0 = (w - cw) / 2.0 / w
        y0 = (h - ch) / 2.0 / h
        return (x0, y0, x0 + cw / w, y0 + ch / h)

    def _clamp(self, pos, r):
        return QPointF(min(max(pos.x(), r.left()), r.right()),
                       min(max(pos.y(), r.top()), r.bottom()))

    def mousePressEvent(self, event):
        r = self.image_rect()
        if self.crop_mode and r is not None and event.button() == Qt.LeftButton:
            self._anchor = self._clamp(event.position(), r)
        elif not self.crop_mode and r is not None and event.button() == Qt.LeftButton:
            self._pan_from = event.position()
            self.setCursor(Qt.ClosedHandCursor)
        else:
            super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        r = self.image_rect()
        if not self.crop_mode and self._pan_from is not None:
            d = event.position() - self._pan_from
            self._pan_from = event.position()
            self.panned.emit(d.x(), d.y())
            return
        if not (self.crop_mode and self._anchor is not None and r is not None):
            return super().mouseMoveEvent(event)
        p = self._clamp(event.position(), r)
        a = self._anchor
        dx, dy = p.x() - a.x(), p.y() - a.y()
        if self.aspect:
            sx = 1 if dx >= 0 else -1
            sy = 1 if dy >= 0 else -1
            room_x = (r.right() - a.x()) if sx > 0 else (a.x() - r.left())
            room_y = (r.bottom() - a.y()) if sy > 0 else (a.y() - r.top())
            w = min(abs(dx), room_x, room_y * self.aspect)
            dx, dy = sx * w, sy * w / self.aspect
        x0, x1 = sorted((a.x(), a.x() + dx))
        y0, y1 = sorted((a.y(), a.y() + dy))
        self.selection = ((x0 - r.left()) / r.width(), (y0 - r.top()) / r.height(),
                          (x1 - r.left()) / r.width(), (y1 - r.top()) / r.height())
        self.update()

    def mouseReleaseEvent(self, event):
        if self.crop_mode:
            self._anchor = None
            s = self.selection
            if s and (s[2] - s[0] < 0.03 or s[3] - s[1] < 0.03):
                self.selection = self.default_selection()   # a tap, not a drag
                self.update()
        elif self._pan_from is not None:
            self._pan_from = None
            self.setCursor(Qt.ArrowCursor)
        else:
            super().mouseReleaseEvent(event)

    def mouseDoubleClickEvent(self, event):
        if not self.crop_mode:
            self.doubleClicked.emit(event.position())

    def wheelEvent(self, event):
        dy = event.angleDelta().y()
        if dy and not self.crop_mode:
            self.zoomRequested.emit(1.25 ** (dy / 120.0), event.position())
        event.accept()

    def event(self, e):
        # two-finger pinch on a Mac trackpad
        if e.type() == QEvent.NativeGesture:
            try:
                if e.gestureType() == Qt.ZoomNativeGesture and not self.crop_mode:
                    self.zoomRequested.emit(1.0 + float(e.value()), e.position())
                    return True
            except Exception:
                pass
        return super().event(e)

    def paintEvent(self, event):
        super().paintEvent(event)
        r = self.image_rect()
        if not (self.crop_mode and self.selection and r is not None):
            return
        x0, y0, x1, y1 = self.selection
        sel = QRectF(r.left() + x0 * r.width(), r.top() + y0 * r.height(),
                     (x1 - x0) * r.width(), (y1 - y0) * r.height())
        p = QPainter(self)
        shade = QColor(0, 0, 0, 150)
        p.fillRect(QRectF(r.left(), r.top(), r.width(), sel.top() - r.top()), shade)
        p.fillRect(QRectF(r.left(), sel.bottom(), r.width(), r.bottom() - sel.bottom()), shade)
        p.fillRect(QRectF(r.left(), sel.top(), sel.left() - r.left(), sel.height()), shade)
        p.fillRect(QRectF(sel.right(), sel.top(), r.right() - sel.right(), sel.height()), shade)
        p.setPen(QPen(QColor("#f5a623"), 2))
        p.drawRect(sel)
        p.setPen(QPen(QColor(255, 255, 255, 110), 1))
        for i in (1, 2):   # rule-of-thirds guides
            p.drawLine(QPointF(sel.left() + sel.width() * i / 3, sel.top()),
                       QPointF(sel.left() + sel.width() * i / 3, sel.bottom()))
            p.drawLine(QPointF(sel.left(), sel.top() + sel.height() * i / 3),
                       QPointF(sel.right(), sel.top() + sel.height() * i / 3))
        p.end()
