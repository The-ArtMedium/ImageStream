import os

RAW_EXTENSIONS = (
    ".cr2", ".cr3", ".nef", ".nrw", ".arw", ".dng",
    ".orf", ".rw2", ".raf", ".pef", ".srw",
)
PLAIN_EXTENSIONS = (
    ".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp", ".webp",
)
SUPPORTED_IMAGE_EXTENSIONS = PLAIN_EXTENSIONS + RAW_EXTENSIONS


def is_raw(file_path):
    return file_path.lower().endswith(RAW_EXTENSIONS)


def is_supported_image(file_path):
    return file_path.lower().endswith(SUPPORTED_IMAGE_EXTENSIONS)


def get_files_in_folder(folder_path):
    files = []
    for file_name in sorted(os.listdir(folder_path)):
        if file_name.startswith("."):
            continue  # skip hidden/system files such as macOS "._" copies
        full_path = os.path.join(folder_path, file_name)
        if os.path.isfile(full_path) and is_supported_image(full_path):
            files.append(full_path)
    return files
