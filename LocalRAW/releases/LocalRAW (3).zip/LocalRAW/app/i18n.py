"""LocalRAW in seven languages.

The English text on screen is the key; app/i18n_table.py holds the six translations
of each one. The language is read once at start-up (changing it asks for a restart),
so tr() can be used anywhere, even for names defined when a module loads.

The widget classes below are the usual Qt ones, except that any text given to them
passes through tr() first. main_window.py and export_dialog.py import them in place
of the PySide6 ones, so a button made with QPushButton("Save") shows the chosen
language without every line having to say tr(...).
"""
import re
import textwrap

from PySide6.QtCore import QSettings, QLocale
from PySide6 import QtWidgets as _Qt

from app.i18n_table import T, TEMPLATES

# (code, name shown in the menu) — the order of the columns in i18n_table
LANGUAGES = [("en", "English"), ("es", "Español"), ("fr", "Français"), ("pt", "Português"),
             ("ar", "العربية"), ("zh", "中文"), ("hi", "हिन्दी")]
_COLUMN = {code: i - 1 for i, (code, _name) in enumerate(LANGUAGES)}     # en = -1: no column


def computer_language():
    """The first of the computer's preferred languages (System Settings on a Mac, Windows
    display language) that LocalRAW speaks; English if none of them."""
    wanted = list(QLocale.system().uiLanguages()) + [QLocale.system().name()]
    for tag in wanted:
        code = tag.replace("_", "-").split("-")[0].lower()
        if code in _COLUMN:
            return code
    return "en"


def _start_language():
    # "auto" (the default) follows the computer every time LocalRAW opens;
    # a language picked in the menu stays until "Automatic" is picked again
    saved = QSettings("ImageStream", "LocalRAW").value("language", "auto", type=str)
    return saved if saved in _COLUMN else computer_language()


LANG = _start_language()
RTL = LANG == "ar"


def _norm(text):
    return " ".join(text.split())


_EXACT = {}
_PATTERNS = []
for _en, _row in T.items():
    if "{}" in _en:
        # the fixed words must match (spaces and line breaks may differ); each {} is any text
        glue = ["".join(r"\s*" if tok.isspace() else re.escape(tok) for tok in re.split(r"(\s+)", piece) if tok)
                for piece in _en.split("{}")]
        _PATTERNS.append((re.compile("(.*?)".join(glue), re.S), _row, _en.count("{}")))
    else:
        _EXACT[_norm(_en)] = _row
_PATTERNS.sort(key=lambda p: -len(p[0].pattern))       # the most specific pattern first
# pieces put together in code, e.g. tr("{} of {}").format(3, 40): looked up as they are,
# never matched against other text (a file name could contain "of")
for _en, _row in TEMPLATES.items():
    _EXACT[_norm(_en)] = _row


def _column(row, lang):
    col = _COLUMN.get(lang, -1)
    if col < 0 or col >= len(row) or not row[col]:
        return None
    return row[col]


def _shape(source, text):
    """Long tooltips were written on several lines; keep translations readable too."""
    if "\n" in text or "\n" not in source or len(text) < 70:
        return text
    if LANG in ("zh",):
        return "\n".join(text[i:i + 34] for i in range(0, len(text), 34))
    return textwrap.fill(text, 62)


def tr(text, lang=None):
    """The text in the chosen language (or unchanged when there is no translation)."""
    lang = lang or LANG
    if lang == "en" or not isinstance(text, str) or not text.strip():
        return text
    row = _EXACT.get(_norm(text))
    if row is not None:
        out = _column(row, lang)
        if out is None:
            return text
        lead = text[:len(text) - len(text.lstrip())]
        trail = text[len(text.rstrip()):]
        return lead + _shape(text, out) + trail
    for rx, row, _n in _PATTERNS:
        m = rx.fullmatch(text)
        if m:
            out = _column(row, lang)
            if out is None:
                return text
            groups = [tr(g, lang) for g in m.groups()]
            try:
                return _shape(text, out.format(*groups))
            except (IndexError, KeyError, ValueError):
                return text
    return text


# ── Qt widgets that translate what they are given ──────────────────────────────

def _first_text(args):
    return [tr(a) if isinstance(a, str) and i == 0 else a for i, a in enumerate(args)]


class _Texts:
    def setText(self, text):
        super().setText(tr(text))

    def setToolTip(self, text):
        super().setToolTip(tr(text))


class QPushButton(_Texts, _Qt.QPushButton):
    def __init__(self, *args):
        super().__init__(*_first_text(args))


class QLabel(_Texts, _Qt.QLabel):
    def __init__(self, *args):
        super().__init__(*_first_text(args))


class QCheckBox(_Texts, _Qt.QCheckBox):
    def __init__(self, *args):
        super().__init__(*_first_text(args))


class QRadioButton(_Texts, _Qt.QRadioButton):
    def __init__(self, *args):
        super().__init__(*_first_text(args))


class QGroupBox(_Qt.QGroupBox):
    def __init__(self, *args):
        super().__init__(*_first_text(args))

    def setTitle(self, text):
        super().setTitle(tr(text))

    def setToolTip(self, text):
        super().setToolTip(tr(text))


class QComboBox(_Qt.QComboBox):
    def addItem(self, *args):
        args = list(args)
        for i, a in enumerate(args):
            if isinstance(a, str):
                args[i] = tr(a)
                break
        super().addItem(*args)

    def addItems(self, texts):
        super().addItems([tr(t) for t in texts])

    def setToolTip(self, text):
        super().setToolTip(tr(text))


class QLineEdit(_Qt.QLineEdit):
    def setPlaceholderText(self, text):
        super().setPlaceholderText(tr(text))

    def setToolTip(self, text):
        super().setToolTip(tr(text))


class QFormLayout(_Qt.QFormLayout):
    def addRow(self, *args):
        super().addRow(*_first_text(args))


class QProgressDialog(_Qt.QProgressDialog):
    def __init__(self, *args):
        args = [tr(a) if isinstance(a, str) else a for a in args]
        super().__init__(*args)

    def setLabelText(self, text):
        super().setLabelText(tr(text))

    def setWindowTitle(self, text):
        super().setWindowTitle(tr(text))


class QMessageBox(_Qt.QMessageBox):
    @staticmethod
    def information(parent, title, text, *rest):
        return _Qt.QMessageBox.information(parent, tr(title), tr(text), *rest)

    @staticmethod
    def warning(parent, title, text, *rest):
        return _Qt.QMessageBox.warning(parent, tr(title), tr(text), *rest)

    @staticmethod
    def critical(parent, title, text, *rest):
        return _Qt.QMessageBox.critical(parent, tr(title), tr(text), *rest)

    @staticmethod
    def question(parent, title, text, *rest):
        return _Qt.QMessageBox.question(parent, tr(title), tr(text), *rest)


class QFileDialog(_Qt.QFileDialog):
    @staticmethod
    def getExistingDirectory(parent=None, caption="", *rest):
        return _Qt.QFileDialog.getExistingDirectory(parent, tr(caption), *rest)

    @staticmethod
    def getSaveFileName(parent=None, caption="", *rest):
        return _Qt.QFileDialog.getSaveFileName(parent, tr(caption), *rest)

    @staticmethod
    def getOpenFileName(parent=None, caption="", *rest):
        return _Qt.QFileDialog.getOpenFileName(parent, tr(caption), *rest)


def translate_tree(root):
    """Window and dialog titles, and tooltips of widgets that are not ours (sliders...)."""
    root.setWindowTitle(tr(root.windowTitle()))
    for w in [root] + root.findChildren(_Qt.QWidget):
        tip = w.toolTip()
        if tip:
            w.setToolTip(tr(tip))
        if isinstance(w, _Qt.QDialog):
            w.setWindowTitle(tr(w.windowTitle()))
