import os
import numpy as np
import cv2

from PySide6.QtWidgets import (
    QMainWindow, QWidget, QHBoxLayout,
    QVBoxLayout, QPushButton, QFileDialog,
    QLabel, QScrollArea, QGridLayout,
    QSlider, QGroupBox, QMessageBox,
    QSizePolicy, QInputDialog, QLineEdit,
    QDialog, QFormLayout, QDialogButtonBox,
    QComboBox, QTextEdit, QApplication
)
from PySide6.QtGui import (QPixmap, QImage, QColor, QPainter, QKeySequence, QShortcut,
                           QImageReader, QImageIOHandler, QTransform)
from PySide6.QtCore import Qt, QTimer, QThread, Signal, QBuffer, QByteArray, QIODevice

from app.ui.preview_widget import CropLabel
from app.core import focus_check
from app.core.pipeline import Pipeline
from app.core.exporter import Exporter
from app.core.raw_loader import RawLoader
from app.core.batch_renamer import BatchRenamer
from app.core.watermarker import Watermarker
from app.core.metadata_editor import MetadataEditor
from app.utils.file_utils import get_files_in_folder, is_raw
from app.utils.image_utils import numpy_to_pixmap, resize_for_preview


PREVIEW_MAX = 1200


THUMB_SIZE = 116


def _rgb_to_pixmap(rgb):
    rgb = np.ascontiguousarray(rgb)
    h, w, _ = rgb.shape
    image = QImage(rgb.data, w, h, 3 * w, QImage.Format_RGB888).copy()
    return QPixmap.fromImage(image)


def _placeholder_pixmap(name):
    pixmap = QPixmap(THUMB_SIZE, THUMB_SIZE)
    pixmap.fill(QColor("#2a2a2a"))
    painter = QPainter(pixmap)
    painter.setPen(QColor("#bbbbbb"))
    painter.drawText(pixmap.rect(), Qt.AlignCenter | Qt.TextWordWrap, name)
    painter.end()
    return pixmap


def _read_scaled(source):
    """Decode a picture straight to thumbnail size (fast even for huge JPEGs),
    upright according to its orientation tag. Returns (pixmap, was_rotated)."""
    reader = QImageReader(source)
    reader.setAutoTransform(True)
    rotated = reader.transformation() != QImageIOHandler.TransformationNone
    size = reader.size()
    if size.isValid() and max(size.width(), size.height()) > THUMB_SIZE * 2:
        size.scale(THUMB_SIZE * 2, THUMB_SIZE * 2, Qt.KeepAspectRatio)
        reader.setScaledSize(size)
    image = reader.read()
    return (QPixmap() if image.isNull() else QPixmap.fromImage(image)), rotated


def make_thumbnail(file_path):
    """Return a small preview for any supported file. RAW files use the camera's
    embedded preview (fast); if that is missing, a quick half-size render is used.
    A file that cannot be previewed gets a labelled placeholder instead of vanishing."""
    name = os.path.basename(file_path)
    pixmap = QPixmap()
    try:
        if is_raw(file_path):
            import rawpy
            with rawpy.imread(file_path) as raw:
                try:
                    thumb = raw.extract_thumb()
                    if thumb.format == rawpy.ThumbFormat.JPEG:
                        buffer = QBuffer()
                        buffer.setData(QByteArray(bytes(thumb.data)))
                        buffer.open(QIODevice.ReadOnly)
                        pixmap, rotated = _read_scaled(buffer)
                        # vertical shots: the preview may carry no orientation tag of its own
                        angle = {3: 180, 5: -90, 6: 90}.get(raw.sizes.flip, 0)
                        if angle and not rotated and not pixmap.isNull():
                            pixmap = pixmap.transformed(QTransform().rotate(angle))
                    elif thumb.format == rawpy.ThumbFormat.BITMAP:
                        pixmap = _rgb_to_pixmap(thumb.data)
                except Exception:
                    pixmap = QPixmap()
                if pixmap.isNull():
                    rgb = raw.postprocess(half_size=True, use_camera_wb=True)
                    pixmap = _rgb_to_pixmap(rgb)
        else:
            pixmap, _ = _read_scaled(file_path)
    except Exception:
        pixmap = QPixmap()
    if pixmap.isNull():
        return _placeholder_pixmap(name)
    return pixmap.scaled(THUMB_SIZE, THUMB_SIZE, Qt.KeepAspectRatio, Qt.SmoothTransformation)



APP_VERSION = "1.7"      # shown in the window title, so an old copy is easy to spot
def auto_tone_values(lum):
    """From the brightness of a photo (0..1): exposure in stops, then
    (highlights, shadows, whites, blacks), each -1..1."""
    hi = float(np.percentile(lum, 99.5))
    # an underexposed photo is first lifted so its brightest tones reach near white
    stops = min(2.5, max(0.0, float(np.log2(0.96 / max(hi, 0.02))))) if hi < 0.90 else 0.0
    lum = np.clip(lum * (2.0 ** stops), 0, 1)
    lo, hi = np.percentile(lum, 0.5), np.percentile(lum, 99.5)
    blacks = -min(1.0, lo / 0.12) if lo > 0.01 else 0.0          # darkest tones down to black
    whites = min(1.0, max(0.0, (1.0 - hi) / 0.20))               # brightest tones up to white
    black_point, white_point = -blacks * 0.12, 1.0 - whites * 0.20
    mid = (float(np.median(lum)) - black_point) / max(0.05, white_point - black_point)
    shadows = min(0.7, (0.32 - mid) / 0.32 * 1.2) if mid < 0.32 else 0.0      # dark photo: open it
    highlights = -min(0.6, (mid - 0.62) / 0.38) if mid > 0.62 else 0.0        # bright photo: hold it
    return stops, highlights, shadows, whites, blacks


FOCUS_COLORS = {"sharp": "#4caf50", "fixable": "#ffd54f", "rejected": "#ff6b6b"}
FOCUS_NAMES = {"sharp": "IN FOCUS", "fixable": "FIXABLE", "rejected": "REJECTED"}
SHOW_NAMES = {"sharp": "In focus", "fixable": "Fixable", "rejected": "Rejected"}


class FocusWorker(QThread):
    """Scores the whole folder in the background so the window stays usable."""
    progress = Signal(int, int)
    finished_scan = Signal(dict, bool)

    def __init__(self, files):
        super().__init__()
        self.files = list(files)

    def run(self):
        results = {}
        total = len(self.files)
        for i, path in enumerate(self.files, 1):
            if self.isInterruptionRequested():
                self.finished_scan.emit(results, False)
                return
            shutter = focus_check.get_shutter(path)
            results[path] = {"score": focus_check.score_image(path), "shutter": shutter}
            self.progress.emit(i, total)
        self.finished_scan.emit(results, True)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle(f"LocalRAW {APP_VERSION}  \u2014  RAW + JPG editor with Focus Check")
        self.setMinimumSize(1000, 600)

        self.pipeline = Pipeline()
        self.exporter = Exporter()
        self.raw_loader = RawLoader()
        self.batch_renamer = BatchRenamer()
        self.watermarker = Watermarker()
        self.metadata_editor = MetadataEditor()

        self.current_image = None
        self.current_file_path = None
        self.preview_image = None
        self.image_files = []
        self.focus = {}             # Focus Check results per photo
        self.focus_limits = None
        self._focus_worker = None
        self._thumb_cache = {}
        self.zoom_scale = None      # None = fit the window; 1.0 = 100 %
        self.zoom_center = None     # point of the photo in the middle of the view
        self._view_origin = (0, 0)
        self._geo_cache = (None, None)

        self._preview_timer = QTimer()
        self._preview_timer.setSingleShot(True)
        self._preview_timer.setInterval(80)
        self._preview_timer.timeout.connect(self.apply_pipeline)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QHBoxLayout()
        central_widget.setLayout(main_layout)

        # ===== LEFT PANEL
        left_layout = QVBoxLayout()
        self.import_button = QPushButton("Import Folder")
        self.import_button.clicked.connect(self.import_folder)
        self.status_label = QLabel("No folder loaded")
        left_layout.addWidget(self.import_button)
        left_layout.addWidget(self.status_label)

        # Focus Check
        focus_group = QGroupBox("Focus Check")
        self.focus_button = QPushButton("\U0001F50D  Check Focus of Folder")
        self.focus_button.setToolTip("Scores every photo: sharp, fixable or rejected")
        self.focus_button.clicked.connect(self.run_focus_check)
        self.focus_summary = QLabel("")
        self.focus_summary.setWordWrap(True)
        # one strip of four toggles: shooting order, greens, yellows, reds
        self.focus_show = set()                  # empty = everything, in shooting order
        show_row = QGridLayout()
        show_row.setSpacing(3)
        self.show_order_btn = QPushButton("Order")
        self.show_order_btn.setCheckable(True)
        self.show_order_btn.setChecked(True)
        self.show_order_btn.setToolTip("All photos, in shooting order")
        self.show_order_btn.clicked.connect(self._show_order_clicked)
        show_row.addWidget(self.show_order_btn, 0, 0)
        self.show_btns = {}
        for (cat, tip), cell in zip([("sharp", "Green: photos in focus"),
                                     ("fixable", "Yellow: slightly soft, can be recovered"),
                                     ("rejected", "Red: the softest photos of this folder")],
                                    [(0, 1), (1, 0), (1, 1)]):
            btn = QPushButton(SHOW_NAMES[cat])
            btn.setCheckable(True)
            btn.setToolTip(tip + ".\nSwitch on one, two or all three. Inside each colour the\n"
                                 "photos stay in shooting order. Files on disk are not touched.")
            btn.setStyleSheet(
                f"QPushButton {{ color: {FOCUS_COLORS[cat]}; font-weight: bold; padding: 4px 2px; }}"
                f"QPushButton:checked {{ background-color: {FOCUS_COLORS[cat]}; color: #111; }}"
                f"QPushButton:disabled {{ color: #666; }}")
            btn.clicked.connect(lambda _on=False, c=cat: self._show_group_clicked(c))
            show_row.addWidget(btn, *cell)
            self.show_btns[cat] = btn
        self.focus_recover_button = QPushButton("Recover Sharpness (this photo)")
        self.focus_recover_button.clicked.connect(self.recover_current)
        self.focus_trash_button = QPushButton("Trash All Rejected...")
        self.focus_trash_button.setStyleSheet("QPushButton { color: #ff8a80; }")
        self.focus_trash_button.clicked.connect(self.trash_rejected)
        focus_layout = QVBoxLayout()
        focus_layout.addWidget(self.focus_button)
        focus_layout.addWidget(self.focus_summary)
        focus_layout.addLayout(show_row)
        focus_layout.addWidget(self.focus_recover_button)
        focus_layout.addWidget(self.focus_trash_button)
        focus_group.setLayout(focus_layout)
        left_layout.addWidget(focus_group)
        for wdg in (self.show_order_btn, *self.show_btns.values(),
                    self.focus_recover_button, self.focus_trash_button):
            wdg.setEnabled(False)

        self.scroll_area = QScrollArea()
        self.scroll_widget = QWidget()
        self.grid_layout = QGridLayout()
        self.grid_layout.setContentsMargins(4, 4, 4, 4)
        self.grid_layout.setSpacing(4)
        self.grid_layout.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        self.scroll_widget.setLayout(self.grid_layout)
        self.scroll_area.setWidget(self.scroll_widget)
        self.scroll_area.setWidgetResizable(True)
        left_layout.addWidget(self.scroll_area)

        # Tools row
        tools_layout = QVBoxLayout()
        self.batch_rename_button = QPushButton("Batch Rename")
        self.batch_rename_button.clicked.connect(self.open_batch_rename)
        self.metadata_button = QPushButton("Metadata")
        self.metadata_button.clicked.connect(self.open_metadata)
        tools_layout.addWidget(self.batch_rename_button)
        tools_layout.addWidget(self.metadata_button)
        left_layout.addLayout(tools_layout)

        # ===== CENTER PANEL
        self.preview_label = CropLabel("Open a folder and select an image")
        self.preview_label.setAlignment(Qt.AlignCenter)
        self.preview_label.setStyleSheet("background-color: #1a1a1a; color: #555;")
        self.preview_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        # ===== RIGHT PANEL
        right_layout = QVBoxLayout()

        # Rotate & Straighten
        rot_group = QGroupBox("Rotate && Straighten")
        rot_buttons = QHBoxLayout()
        self.rotate_left_button = QPushButton("\u21ba 90\u00b0")
        self.rotate_right_button = QPushButton("\u21bb 90\u00b0")
        self.flip_button = QPushButton("Flip")
        self.rotate_left_button.clicked.connect(lambda: self.rotate_image(-1))
        self.rotate_right_button.clicked.connect(lambda: self.rotate_image(1))
        self.flip_button.clicked.connect(self.flip_image)
        rot_buttons.addWidget(self.rotate_left_button)
        rot_buttons.addWidget(self.rotate_right_button)
        rot_buttons.addWidget(self.flip_button)
        self.straighten_slider = self._make_slider(-150, 150, 0)
        self.straighten_label = QLabel("Straighten: 0.0\u00b0")
        rot_layout = QVBoxLayout()
        rot_layout.addLayout(rot_buttons)
        rot_layout.addWidget(self.straighten_label)
        rot_layout.addWidget(self.straighten_slider)
        rot_group.setLayout(rot_layout)

        # White Balance
        wb_group = QGroupBox("White Balance")
        self.temp_slider = self._make_slider(-100, 100, 0)
        self.tint_slider = self._make_slider(-100, 100, 0)
        wb_layout = QVBoxLayout()
        self.grey_button = QPushButton("\U0001F4A7  Grey Picker")
        self.grey_button.setCheckable(True)
        self.grey_button.setToolTip("Press, then click something in the photo that should be neutral\n"
                                    "grey or white: a white jersey, a grey wall, the lines on the field.\n"
                                    "Temperature and Tint are set so that spot has no colour cast.")
        self.grey_button.toggled.connect(self._grey_toggled)
        self.grey_hint = QLabel("")
        self.grey_hint.setWordWrap(True)
        self.grey_hint.setStyleSheet("color: #f5a623;")
        wb_layout.addWidget(self.grey_button)
        wb_layout.addWidget(self.grey_hint)
        wb_layout.addWidget(QLabel("Temperature"))
        wb_layout.addWidget(self.temp_slider)
        wb_layout.addWidget(QLabel("Tint"))
        wb_layout.addWidget(self.tint_slider)
        wb_group.setLayout(wb_layout)

        # Tone
        tone_group = QGroupBox("Tone")
        self.exposure_slider = self._make_slider(-30, 30, 0)
        self.contrast_slider = self._make_slider(-50, 50, 0)
        tone_layout = QVBoxLayout()
        self.auto_button = QPushButton("\u2728  Auto Tone")
        self.auto_button.setToolTip("Sets exposure, white point, black point, shadows and highlights\n"
                                    "from this photo. A starting point: adjust after.")
        self.auto_button.clicked.connect(self.auto_tone)
        tone_layout.addWidget(self.auto_button)
        tone_layout.addWidget(QLabel("Exposure"))
        tone_layout.addWidget(self.exposure_slider)
        tone_layout.addWidget(QLabel("Contrast"))
        tone_layout.addWidget(self.contrast_slider)
        self.highlights_slider = self._make_slider(-100, 100, 0)
        self.shadows_slider = self._make_slider(-100, 100, 0)
        self.whites_slider = self._make_slider(-100, 100, 0)
        self.blacks_slider = self._make_slider(-100, 100, 0)
        self.saturation_slider = self._make_slider(-100, 100, 0)
        for name, slider in [("Highlights", self.highlights_slider), ("Shadows", self.shadows_slider),
                             ("Whites (white point)", self.whites_slider),
                             ("Blacks (black point)", self.blacks_slider),
                             ("Saturation", self.saturation_slider)]:
            tone_layout.addWidget(QLabel(name))
            tone_layout.addWidget(slider)
        tone_group.setLayout(tone_layout)

        # Detail
        detail_group = QGroupBox("Detail")
        self.sharpen_slider = self._make_slider(0, 20, 0)
        detail_layout = QVBoxLayout()
        detail_layout.addWidget(QLabel("Sharpen"))
        detail_layout.addWidget(self.sharpen_slider)
        detail_group.setLayout(detail_layout)

        # Noise Reduction
        nr_group = QGroupBox("Noise Reduction")
        self.nr_lum_slider = self._make_slider(0, 100, 0)
        self.nr_color_slider = self._make_slider(0, 100, 0)
        nr_layout = QVBoxLayout()
        nr_layout.addWidget(QLabel("Luminance"))
        nr_layout.addWidget(self.nr_lum_slider)
        nr_layout.addWidget(QLabel("Color"))
        nr_layout.addWidget(self.nr_color_slider)
        nr_group.setLayout(nr_layout)

        # Dehaze
        dehaze_group = QGroupBox("Dehaze")
        self.dehaze_slider = self._make_slider(0, 100, 0)
        dehaze_layout = QVBoxLayout()
        dehaze_layout.addWidget(QLabel("Amount"))
        dehaze_layout.addWidget(self.dehaze_slider)
        dehaze_group.setLayout(dehaze_layout)

        # Watermark
        wm_group = QGroupBox("Watermark")
        self.watermark_button = QPushButton("Add Watermark...")
        self.watermark_button.clicked.connect(self.open_watermark)
        wm_layout = QVBoxLayout()
        wm_layout.addWidget(self.watermark_button)
        wm_group.setLayout(wm_layout)

        # Reset + Export
        self.reset_button = QPushButton("Reset All")
        self.reset_button.clicked.connect(self.reset_sliders)
        self.export_button = QPushButton("Export Image")
        self.export_button.clicked.connect(self.export_image)

        # Crop
        crop_group = QGroupBox("Crop")
        self.crop_shape = QComboBox()
        for name, value in [("Free shape", None), ("Original shape", "orig"), ("Square 1:1", 1.0),
                            ("Portrait 4:5", 4 / 5), ("Photo 3:2", 3 / 2), ("Photo 2:3", 2 / 3),
                            ("Wide 16:9", 16 / 9), ("Tall 9:16", 9 / 16)]:
            self.crop_shape.addItem(name, value)
        self.crop_shape.currentIndexChanged.connect(self.crop_shape_changed)
        self.crop_button = QPushButton("\u2702  Crop")
        self.crop_button.clicked.connect(self.toggle_crop)
        self.crop_cancel_button = QPushButton("Cancel")
        self.crop_cancel_button.clicked.connect(self.cancel_crop)
        self.crop_cancel_button.setVisible(False)
        self.crop_clear_button = QPushButton("Remove Crop")
        self.crop_clear_button.clicked.connect(self.clear_crop)
        self.crop_hint = QLabel("")
        self.crop_hint.setWordWrap(True)
        self.crop_hint.setStyleSheet("color: #f5a623;")
        crop_row = QHBoxLayout()
        crop_row.addWidget(self.crop_button)
        crop_row.addWidget(self.crop_cancel_button)
        crop_layout = QVBoxLayout()
        crop_layout.addWidget(self.crop_shape)
        crop_layout.addLayout(crop_row)
        crop_layout.addWidget(self.crop_clear_button)
        crop_layout.addWidget(self.crop_hint)
        crop_group.setLayout(crop_layout)

        right_layout.addWidget(crop_group)
        right_layout.addWidget(rot_group)
        right_layout.addWidget(wb_group)
        right_layout.addWidget(tone_group)
        right_layout.addWidget(detail_group)
        right_layout.addWidget(nr_group)
        right_layout.addWidget(dehaze_group)
        right_layout.addWidget(wm_group)
        right_layout.addStretch()

        main_layout.addLayout(left_layout, 3)
        center_layout = QVBoxLayout()
        top_bar = QHBoxLayout()
        self.prev_button = QPushButton("\u25c0  Previous")
        self.next_button = QPushButton("Next  \u25b6")
        self.delete_button = QPushButton("\U0001F5D1  Delete")
        self.delete_button.setToolTip("Move this photo to the Trash (Delete key)")
        self.delete_button.setStyleSheet("QPushButton { color: #ff8a80; font-weight: bold; }")
        self.prev_button.clicked.connect(lambda: self.show_neighbor(-1))
        self.next_button.clicked.connect(lambda: self.show_neighbor(1))
        self.delete_button.clicked.connect(self.delete_current_photo)
        self.info_label = QLabel("")
        self.info_label.setAlignment(Qt.AlignCenter)
        self.info_label.setStyleSheet("color: #f5a623; font-weight: bold; padding: 4px;")
        top_bar.addWidget(self.prev_button)
        top_bar.addWidget(self.info_label, 1)
        top_bar.addWidget(self.next_button)
        top_bar.addWidget(self.delete_button)
        center_layout.addLayout(top_bar)
        zoom_bar = QHBoxLayout()
        self.zoom_out_button = QPushButton("\u2212")
        self.zoom_fit_button = QPushButton("Fit")
        self.zoom_100_button = QPushButton("100%")
        self.zoom_in_button = QPushButton("+")
        self.zoom_label = QLabel("Zoom: Fit")
        self.zoom_label.setStyleSheet("color: #aaa; padding: 0 8px;")
        for b in (self.zoom_out_button, self.zoom_in_button):
            b.setFixedWidth(44)
        self.zoom_out_button.setToolTip("Zoom out")
        self.zoom_in_button.setToolTip("Zoom in (or use the mouse wheel / pinch)")
        self.zoom_fit_button.setToolTip("Show the whole photo")
        self.zoom_100_button.setToolTip("Real size, to check sharpness. You can also just click on the photo.")
        self.zoom_out_button.clicked.connect(lambda: self.zoom_by(1 / 1.5))
        self.zoom_in_button.clicked.connect(lambda: self.zoom_by(1.5))
        self.zoom_fit_button.clicked.connect(self.zoom_fit)
        self.zoom_100_button.clicked.connect(lambda: self.zoom_to(1.0))
        zoom_bar.addStretch()
        zoom_bar.addWidget(self.zoom_out_button)
        zoom_bar.addWidget(self.zoom_fit_button)
        zoom_bar.addWidget(self.zoom_100_button)
        zoom_bar.addWidget(self.zoom_in_button)
        zoom_bar.addWidget(self.zoom_label)
        self.compare_button = QPushButton("Before | After")
        self.compare_button.setCheckable(True)
        self.compare_button.setToolTip("Left half: before your corrections. Right half: after.")
        self.compare_button.toggled.connect(lambda _on: self.apply_pipeline())
        zoom_bar.addWidget(self.compare_button)
        zoom_bar.addStretch()
        center_layout.addLayout(zoom_bar)
        self.preview_label.setMinimumSize(200, 200)
        self.preview_label.zoomRequested.connect(self.zoom_by)
        self.preview_label.panned.connect(self.pan_view)
        self.preview_label.clicked.connect(self.toggle_zoom)
        center_layout.addWidget(self.preview_label, 1)
        main_layout.addLayout(center_layout, 6)
        screen = QApplication.primaryScreen()
        if screen is not None:
            area = screen.availableGeometry()
            self.resize(min(1400, area.width() - 40), min(850, area.height() - 60))
        right_widget = QWidget()
        right_widget.setLayout(right_layout)
        right_scroll = QScrollArea()
        right_scroll.setWidget(right_widget)
        right_scroll.setWidgetResizable(True)
        right_scroll.setMinimumWidth(300)
        right_outer = QVBoxLayout()
        right_outer.addWidget(right_scroll, 1)
        # Reset and Export stay pinned at the bottom, always visible
        right_outer.addWidget(self.reset_button)
        right_outer.addWidget(self.export_button)
        main_layout.addLayout(right_outer, 3)

        # Keyboard: Delete / Backspace moves the current photo to the Trash
        QShortcut(QKeySequence(Qt.Key_Delete), self, activated=self.delete_current_photo)
        QShortcut(QKeySequence(Qt.Key_Backspace), self, activated=self.delete_current_photo)  # the Mac delete key
        QShortcut(QKeySequence(Qt.Key_Left), self, activated=lambda: self.show_neighbor(-1))
        QShortcut(QKeySequence(Qt.Key_Right), self, activated=lambda: self.show_neighbor(1))
        QShortcut(QKeySequence(QKeySequence.ZoomIn), self, activated=lambda: self.zoom_by(1.5))
        QShortcut(QKeySequence("Ctrl+="), self, activated=lambda: self.zoom_by(1.5))
        QShortcut(QKeySequence(QKeySequence.ZoomOut), self, activated=lambda: self.zoom_by(1 / 1.5))
        QShortcut(QKeySequence("Ctrl+0"), self, activated=self.zoom_fit)
        QShortcut(QKeySequence("Ctrl+1"), self, activated=lambda: self.zoom_to(1.0))

    # ─────────────────────────────────────────────────

    def _make_slider(self, min_val, max_val, default):
        slider = QSlider(Qt.Horizontal)
        slider.setRange(min_val, max_val)
        slider.setValue(default)
        slider.valueChanged.connect(self._on_slider_changed)
        return slider

    def _on_slider_changed(self):
        self._preview_timer.start()

    # ─────────────────────────────────────────────────

    def import_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Select Folder")
        if folder:
            self.stop_focus_check()
            self.image_files = get_files_in_folder(folder)
            self._thumb_cache = {}
            self._set_focus_results({}, None)
            self.status_label.setText(f"{len(self.image_files)} images found")
            self.display_thumbnails()

    def _shown_files(self):
        """Photos in the strip: all of them, or only one Focus Check group."""
        if not self.focus or not self.focus_show:
            return self.image_files
        # the chosen colours, greens then yellows then reds; the sort is stable, so
        # shooting order is kept inside each colour
        rank = {"sharp": 0, "fixable": 1, "rejected": 2}
        chosen = [p for p in self.image_files if self.focus.get(p, {}).get("cat") in self.focus_show]
        return sorted(chosen, key=lambda p: rank[self.focus[p]["cat"]])

    def _caption_for(self, path):
        info = self.focus.get(path)
        if not info:
            return "", ""
        cat = info["cat"]
        return f"\u25cf {FOCUS_NAMES[cat]}  {info['score']:.0f}", FOCUS_COLORS[cat]

    def _wanted_thumb_cols(self):
        """As many preview columns as the strip has room for."""
        return max(1, (self.scroll_area.viewport().width() - 8) // (THUMB_SIZE + 12))

    def display_thumbnails(self):
        for i in reversed(range(self.grid_layout.count())):
            widget = self.grid_layout.itemAt(i).widget()
            if widget:
                widget.setParent(None)

        self.thumb_labels = {}
        self.thumb_captions = {}
        files = list(self._shown_files())
        self._thumb_cols = self._wanted_thumb_cols()
        row, col = 0, 0
        for n, file_path in enumerate(files):
            pixmap = self._thumb_cache.get(file_path)
            if pixmap is None:
                pixmap = make_thumbnail(file_path)
                self._thumb_cache[file_path] = pixmap
                if n % 6 == 0:      # keep the window alive while a big folder loads
                    self.status_label.setText(f"Loading previews... {n + 1} of {len(files)}")
                    QApplication.processEvents()
            cell = QWidget()
            cell_layout = QVBoxLayout(cell)
            cell_layout.setContentsMargins(0, 0, 0, 0)
            cell_layout.setSpacing(1)
            label = QLabel()
            label.setPixmap(pixmap)
            label.setAlignment(Qt.AlignCenter)
            label.setCursor(Qt.PointingHandCursor)
            label.setToolTip(os.path.basename(file_path))
            label.setStyleSheet("border: 3px solid transparent;")
            caption = QLabel()
            caption.setAlignment(Qt.AlignCenter)
            text, color = self._caption_for(file_path)
            caption.setText(text)
            caption.setStyleSheet(f"color: {color or '#888'}; font-size: 11px; font-weight: bold;")
            caption.setVisible(bool(text))
            cell_layout.addWidget(label)
            cell_layout.addWidget(caption)
            self.thumb_labels[file_path] = label
            self.thumb_captions[file_path] = caption
            label.mousePressEvent = lambda event, path=file_path: self.load_image(path)
            self.grid_layout.addWidget(cell, row, col)
            col += 1
            if col >= self._thumb_cols:
                col = 0
                row += 1
        shown, total = len(files), len(self.image_files)
        self.status_label.setText(
            f"{total} images found" if shown == total else f"Showing {shown} of {total} images")
        self.highlight_current()

    # ───────────────────── Focus Check ─────────────────────

    def stop_focus_check(self):
        worker = self._focus_worker
        if worker is not None and worker.isRunning():
            worker.requestInterruption()
            worker.wait(15000)
        self._focus_worker = None

    def run_focus_check(self):
        if self._focus_worker is not None and self._focus_worker.isRunning():
            self._focus_worker.requestInterruption()      # the button says Stop while scanning
            return
        if not self.image_files:
            QMessageBox.information(self, "Focus Check", "Import a folder first.")
            return
        self.focus_button.setText("Stop")
        self.focus_summary.setText("Checking focus...")
        self._focus_worker = FocusWorker(self.image_files)
        self._focus_worker.progress.connect(
            lambda i, n: self.focus_summary.setText(f"Checking focus... {i} of {n}"))
        self._focus_worker.finished_scan.connect(self._focus_done)
        self._focus_worker.start()

    def _focus_done(self, results, completed):
        self.focus_button.setText("\U0001F50D  Check Focus of Folder")
        if not completed:
            self.focus_summary.setText("Stopped. Nothing was changed.")
            return
        results = {p: r for p, r in results.items() if p in self.image_files}
        limits = focus_check.calibrate([r["score"] for r in results.values()])
        for r in results.values():
            r["cat"] = focus_check.category(r["score"], *limits)
            r["blur"] = focus_check.blur_type(r["shutter"])
        self._set_focus_results(results, limits)
        self.display_thumbnails()

    def _set_focus_results(self, results, limits):
        self.focus = results
        self.focus_limits = limits
        have = bool(results)
        if not have:
            self.focus_show.clear()
        for wdg in (self.show_order_btn, *self.show_btns.values(),
                    self.focus_recover_button, self.focus_trash_button):
            wdg.setEnabled(have)
        self._update_focus_summary()

    def _update_focus_summary(self):
        if not self.focus:
            self.focus_summary.setText("")
            self._paint_show_strip()
            return
        count = {"sharp": 0, "fixable": 0, "rejected": 0}
        for r in self.focus.values():
            count[r["cat"]] += 1
        self.focus_summary.setText(
            f"<span style='color:{FOCUS_COLORS['sharp']}'>In focus {count['sharp']}</span> \u00b7 "
            f"<span style='color:{FOCUS_COLORS['fixable']}'>Fixable {count['fixable']}</span> \u00b7 "
            f"<span style='color:{FOCUS_COLORS['rejected']}'>Rejected {count['rejected']}</span>")
        self._paint_show_strip(count)

    def _paint_show_strip(self, count=None):
        if count is None:
            count = {"sharp": 0, "fixable": 0, "rejected": 0}
            for r in self.focus.values():
                count[r["cat"]] += 1
        self.show_order_btn.setChecked(not self.focus_show)
        for cat, btn in self.show_btns.items():
            btn.setChecked(cat in self.focus_show)
            btn.setText(f"{SHOW_NAMES[cat]}  {count[cat]}" if self.focus else SHOW_NAMES[cat])

    def _show_order_clicked(self):
        self.focus_show.clear()
        self._show_changed()

    def _show_group_clicked(self, cat):
        self.focus_show.symmetric_difference_update({cat})
        self._show_changed()

    def _show_changed(self):
        self._paint_show_strip()
        self.display_thumbnails()
        shown = self._shown_files()
        if shown and self.current_file_path not in shown:
            self.load_image(shown[0])

    def recover_current(self):
        info = self.focus.get(self.current_file_path)
        if not info or self.focus_limits is None:
            QMessageBox.information(self, "Recover Sharpness", "Click a photo that Focus Check has scored.")
            return
        level = focus_check.recovery_level(info["score"], self.focus_limits[0])
        if level == 0:
            QMessageBox.information(self, "Recover Sharpness", "This photo is already sharp.")
            return
        self.sharpen_slider.setValue({1: 6, 2: 12, 3: 18}[level])
        self.compare_button.setChecked(True)      # show before | after straight away
        self.apply_pipeline()

    def trash_rejected(self):
        rejected = [p for p in self.image_files if self.focus.get(p, {}).get("cat") == "rejected"]
        if not rejected:
            QMessageBox.information(self, "Trash Rejected", "There are no rejected photos.")
            return
        answer = QMessageBox.question(
            self, "Trash Rejected",
            f"Move {len(rejected)} rejected photos to the Trash?\n\n"
            "Rejected means the softest photos of this folder. Look at them first with "
            "'Show: rejected' if you are not sure.\nYou can restore them from the Trash.",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if answer != QMessageBox.Yes:
            return
        from send2trash import send2trash
        failed = 0
        for path in rejected:
            try:
                send2trash(path)
            except Exception:
                failed += 1
                continue
            self.image_files.remove(path)
            self.focus.pop(path, None)
            self._thumb_cache.pop(path, None)
        if self.current_file_path not in self.image_files:
            self.current_image = None
            self.current_file_path = None
            self.preview_image = None
            self.preview_label.clear()
            self.preview_label.setText("Rejected photos moved to the Trash")
        self.focus_show.clear()
        self._update_focus_summary()
        self.display_thumbnails()
        if failed:
            QMessageBox.warning(self, "Trash Rejected", f"{failed} photos could not be moved to the Trash.")
        if self.current_file_path is None and self.image_files:
            self.load_image(self.image_files[0])

    def closeEvent(self, event):
        self.stop_focus_check()
        super().closeEvent(event)

    # ─────────────────────────────────────────────────

    def load_image(self, file_path):
        try:
            image = self.raw_loader.load_image(file_path)
        except Exception as e:
            QMessageBox.critical(self, "Load Error", str(e))
            return
        if image is None:
            return
        self.current_image = image
        self.current_file_path = file_path
        self.preview_image = resize_for_preview(image, max_size=PREVIEW_MAX)
        # a new photo starts upright; rotation and straightening belong to one photo
        self.pipeline.rotation = 0
        self.pipeline.flip = False
        self.pipeline.crop = None
        self.grey_button.setChecked(False)
        self.zoom_scale = None
        self.zoom_center = None
        self._geo_cache = (None, None)
        self._end_crop_mode()
        self.highlight_current()
        self.straighten_slider.blockSignals(True)
        self.straighten_slider.setValue(0)
        self.straighten_slider.blockSignals(False)
        self.apply_pipeline()

    # ─────────────────────────────────────────────────

    def update_pipeline_values(self):
        self.pipeline.temperature = self.temp_slider.value()
        self.pipeline.tint = self.tint_slider.value()
        self.pipeline.exposure = self.exposure_slider.value() / 10.0
        self.pipeline.contrast = self.contrast_slider.value()
        self.pipeline.highlights = self.highlights_slider.value() / 100.0
        self.pipeline.shadows = self.shadows_slider.value() / 100.0
        self.pipeline.whites = self.whites_slider.value() / 100.0
        self.pipeline.blacks = self.blacks_slider.value() / 100.0
        self.pipeline.saturation = self.saturation_slider.value() / 100.0
        self.pipeline.sharpen_amount = self.sharpen_slider.value() / 10.0
        self.pipeline.nr_luminance = self.nr_lum_slider.value() / 100.0
        self.pipeline.nr_color = self.nr_color_slider.value() / 100.0
        self.pipeline.dehaze = self.dehaze_slider.value() / 100.0
        self.pipeline.straighten = self.straighten_slider.value() / 10.0
        self.straighten_label.setText(f"Straighten: {self.pipeline.straighten:+.1f}\u00b0")

    def apply_pipeline(self):
        if self.preview_image is None:
            return
        self.update_pipeline_values()
        if self.zoom_scale is not None and not self.preview_label.crop_mode:
            self._render_zoomed()
            return
        self.zoom_label.setText("Zoom: Fit")
        # while the crop frame is being drawn, show the whole photo
        use_crop = not self.preview_label.crop_mode
        processed = self.pipeline.apply(self.preview_image, use_crop=use_crop)
        if self.compare_button.isChecked() and not self.preview_label.crop_mode:
            before = self.pipeline._geometry(self.preview_image, use_crop)
            processed = self._split(before, processed)
        pixmap = numpy_to_pixmap(processed)
        self.preview_label.setPixmap(
            pixmap.scaled(self.preview_label.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
        )

    # ─────────────────────────────────────────────────

    # ───────────────────── grey picker (white balance) ─────────────────────

    def _grey_toggled(self, on):
        if on and self.preview_image is None:
            self.grey_button.setChecked(False)
            return
        if on and self.preview_label.crop_mode:
            self.cancel_crop()
        self.preview_label.setCursor(Qt.CrossCursor if on else Qt.ArrowCursor)
        self.grey_hint.setText("Now click something that should be neutral grey or white." if on else "")

    def _patch_lab(self, pos):
        """Average colour (Lab) of a small patch of the picture on screen, or None."""
        r = self.preview_label.image_rect()
        pm = self.preview_label.pixmap()
        if r is None or pm is None or not r.contains(pos):
            return None
        image = pm.toImage().convertToFormat(QImage.Format_RGB888)
        x, y = int(pos.x() - r.left()), int(pos.y() - r.top())
        x0, y0 = max(0, x - 5), max(0, y - 5)
        x1, y1 = min(image.width(), x + 6), min(image.height(), y + 6)
        if x1 <= x0 or y1 <= y0:
            return None
        patch = image.copy(x0, y0, x1 - x0, y1 - y0)
        arr = np.frombuffer(patch.constBits(), np.uint8, patch.sizeInBytes())
        arr = arr.reshape(patch.height(), patch.bytesPerLine())[:, :patch.width() * 3]
        rgb = arr.reshape(patch.height(), patch.width(), 3).astype(np.float32).mean(axis=(0, 1)) / 255.0
        return cv2.cvtColor(rgb.reshape(1, 1, 3), cv2.COLOR_RGB2Lab)[0, 0]

    def pick_grey(self, pos):
        compare = self.compare_button.isChecked()
        if compare:                                  # measure the corrected picture, not the "before" half
            self.compare_button.blockSignals(True)
            self.compare_button.setChecked(False)
            self.compare_button.blockSignals(False)
            self.apply_pipeline()
        lab = self._patch_lab(pos)
        message = ""
        if lab is None:
            message = "Click on the photo itself."
        elif lab[0] < 6 or lab[0] > 98:
            message = "That spot is too dark or too bright to read. Try another one."
        else:
            # a few rounds: set, look at the same spot again, refine
            for _round in range(4):
                temp = self.temp_slider.value() - lab[2] * 50.0 / 15.0
                temp = max(-100.0, min(100.0, temp))
                a_left = lab[1] + (temp - self.temp_slider.value()) / 50.0 * 3.0
                tint = max(-100.0, min(100.0, self.tint_slider.value() - a_left * 50.0 / 15.0))
                for slider, value in ((self.temp_slider, temp), (self.tint_slider, tint)):
                    slider.blockSignals(True)
                    slider.setValue(int(round(value)))
                    slider.blockSignals(False)
                self.apply_pipeline()
                lab = self._patch_lab(pos)
                if lab is None or (abs(lab[1]) < 0.7 and abs(lab[2]) < 0.7):
                    break
            if abs(self.temp_slider.value()) == 100 or abs(self.tint_slider.value()) == 100:
                message = "That spot has a very strong colour. It may not be a neutral surface."
        if compare:
            self.compare_button.setChecked(True)
        self.grey_button.setChecked(False)
        self.grey_hint.setText(message)

    def auto_tone(self):
        if self.preview_image is None:
            return
        tone = (self.exposure_slider, self.highlights_slider, self.shadows_slider,
                self.whites_slider, self.blacks_slider)
        for slider in tone:
            slider.blockSignals(True)
            slider.setValue(0)
        self.update_pipeline_values()
        # measure the photo as it is with the other corrections, before these four
        small = self.preview_image[::2, ::2]
        out = self.pipeline.apply(small, geometry=False).astype(np.float32) / 255.0
        lum = out[..., 0] * 0.299 + out[..., 1] * 0.587 + out[..., 2] * 0.114
        stops, hl, sh, wh, bl = auto_tone_values(lum)
        for slider, value in zip(tone, (stops * 10, hl * 100, sh * 100, wh * 100, bl * 100)):
            slider.setValue(int(round(value)))
            slider.blockSignals(False)
        self.apply_pipeline()

    def reset_sliders(self):
        for slider in [
            self.temp_slider, self.tint_slider,
            self.exposure_slider, self.contrast_slider,
            self.highlights_slider, self.shadows_slider, self.whites_slider,
            self.blacks_slider, self.saturation_slider,
            self.sharpen_slider, self.nr_lum_slider,
            self.nr_color_slider, self.dehaze_slider,
            self.straighten_slider
        ]:
            slider.blockSignals(True)
            slider.setValue(0)
            slider.blockSignals(False)
        self.pipeline.reset()
        self._end_crop_mode()
        self.apply_pipeline()

    # ─────────────────────────────────────────────────

    def highlight_current(self):
        """Light up the thumbnail being edited and say which photo it is."""
        labels = getattr(self, "thumb_labels", {})
        for path, label in labels.items():
            label.setStyleSheet(
                "border: 3px solid #f5a623;" if path == self.current_file_path
                else "border: 3px solid transparent;"
            )
        if self.current_file_path in labels:
            self.scroll_area.ensureWidgetVisible(labels[self.current_file_path])
        shown = self._shown_files()
        if self.current_file_path and self.current_file_path in shown:
            position = shown.index(self.current_file_path) + 1
            text = f"{os.path.basename(self.current_file_path)}   \u00b7   {position} of {len(shown)}"
            info = self.focus.get(self.current_file_path)
            if info:
                text += f"   \u00b7   {FOCUS_NAMES[info['cat']]} {info['score']:.0f}"
                if info["cat"] != "sharp" and info["blur"] != "unknown":
                    kind = "motion blur" if info["blur"] == "motion" else "focus error"
                    text += f" ({kind}, {focus_check.shutter_str(info['shutter'])})"
            self.info_label.setText(text)
        else:
            self.info_label.setText("")

    def show_neighbor(self, step):
        shown = self._shown_files()
        if not shown:
            return
        if self.current_file_path in shown:
            index = shown.index(self.current_file_path) + step
        else:
            index = 0
        if 0 <= index < len(shown):
            self.load_image(shown[index])

    # ─────────────────────────────────────────────────

    # ───────────────────────── zoom ─────────────────────────

    @staticmethod
    def _split(before, after):
        """Left half before the corrections, right half after, white line between."""
        out = np.ascontiguousarray(after).copy()
        h, w = out.shape[:2]
        if before.shape[:2] != (h, w):
            return out
        mid = w // 2
        out[:, :mid] = before[:, :mid]
        out[:, max(0, mid - 1):mid + 1] = 255
        return out

    def _geo_source(self):
        """Full-size photo after rotate / straighten / crop (kept until they change)."""
        p = self.pipeline
        key = (self.current_file_path, p.rotation, p.flip, p.straighten, p.crop)
        if self._geo_cache[0] != key:
            self._geo_cache = (key, p._geometry(self.current_image, True))
        return self._geo_cache[1]

    def _fit_scale(self, src):
        h, w = src.shape[:2]
        return min(self.preview_label.width() / float(w), self.preview_label.height() / float(h))

    def _render_zoomed(self):
        src = self._geo_source()
        H, W = src.shape[:2]
        s = self.zoom_scale
        lw, lh = self.preview_label.width(), self.preview_label.height()
        vw, vh = min(W, lw / s), min(H, lh / s)          # part of the photo on screen
        cx, cy = self.zoom_center or (W / 2.0, H / 2.0)
        cx = min(max(cx, vw / 2.0), W - vw / 2.0)
        cy = min(max(cy, vh / 2.0), H - vh / 2.0)
        self.zoom_center = (cx, cy)
        x0, y0 = int(cx - vw / 2.0), int(cy - vh / 2.0)
        x1, y1 = min(W, x0 + int(round(vw))), min(H, y0 + int(round(vh)))
        self._view_origin = (x0, y0)
        m = 24                                           # margin so edges are processed cleanly
        ex0, ey0, ex1, ey1 = max(0, x0 - m), max(0, y0 - m), min(W, x1 + m), min(H, y1 + m)
        region = np.ascontiguousarray(src[ey0:ey1, ex0:ex1])
        k = min(s, 1.0)
        if k < 1.0:
            region = cv2.resize(region, (max(1, int(round(region.shape[1] * k))),
                                         max(1, int(round(region.shape[0] * k)))),
                                interpolation=cv2.INTER_AREA)
        processed = self.pipeline.apply(region, geometry=False)
        ix0, iy0 = int(round((x0 - ex0) * k)), int(round((y0 - ey0) * k))
        iw, ih = max(1, int(round((x1 - x0) * k))), max(1, int(round((y1 - y0) * k)))
        view = processed[iy0:iy0 + ih, ix0:ix0 + iw]
        if self.compare_button.isChecked():
            view = self._split(region[iy0:iy0 + ih, ix0:ix0 + iw], view)
        if s > 1.0:
            view = cv2.resize(view, (int(round((x1 - x0) * s)), int(round((y1 - y0) * s))),
                              interpolation=cv2.INTER_NEAREST if s >= 3 else cv2.INTER_LINEAR)
        view = np.ascontiguousarray(view)
        self.preview_label.setPixmap(numpy_to_pixmap(view).copy())
        self.zoom_label.setText(f"Zoom: {s * 100:.0f}%")

    def zoom_to(self, scale, pos=None):
        if self.current_image is None or self.preview_label.crop_mode:
            return
        src = self._geo_source()
        H, W = src.shape[:2]
        fit = self._fit_scale(src)
        scale = min(scale, max(4.0, fit))
        if scale <= fit * 1.01 and fit <= 1.0:
            return self.zoom_fit()
        r = self.preview_label.image_rect()
        if pos is not None and r is not None and r.contains(pos):
            # keep the spot under the pointer where it is
            if self.zoom_scale is None:
                px = (pos.x() - r.left()) / r.width() * W
                py = (pos.y() - r.top()) / r.height() * H
            else:
                px = self._view_origin[0] + (pos.x() - r.left()) / self.zoom_scale
                py = self._view_origin[1] + (pos.y() - r.top()) / self.zoom_scale
            lw, lh = self.preview_label.width(), self.preview_label.height()
            self.zoom_center = (px - (pos.x() - lw / 2.0) / scale, py - (pos.y() - lh / 2.0) / scale)
        elif self.zoom_center is None:
            self.zoom_center = (W / 2.0, H / 2.0)
        self.zoom_scale = scale
        self.apply_pipeline()

    def zoom_by(self, factor, pos=None):
        if self.current_image is None or self.preview_label.crop_mode:
            return
        current = self.zoom_scale or self._fit_scale(self._geo_source())
        self.zoom_to(current * factor, pos)

    def zoom_fit(self):
        self.zoom_scale = None
        self.zoom_center = None
        self.apply_pipeline()

    def toggle_zoom(self, pos=None):
        """Click on the photo: jump to 100 % on that spot; click again for the whole photo."""
        if self.grey_button.isChecked():
            return self.pick_grey(pos)
        if self.zoom_scale is None:
            self.zoom_to(1.0, pos)
        else:
            self.zoom_fit()

    def pan_view(self, dx, dy):
        if self.zoom_scale is None or self.zoom_center is None:
            return
        self.zoom_center = (self.zoom_center[0] - dx / self.zoom_scale,
                            self.zoom_center[1] - dy / self.zoom_scale)
        self.apply_pipeline()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if getattr(self, "preview_image", None) is not None:
            self._preview_timer.start()
        if getattr(self, "thumb_labels", None) and self._wanted_thumb_cols() != getattr(self, "_thumb_cols", 0):
            QTimer.singleShot(0, self._relayout_thumbs)

    def _relayout_thumbs(self):
        if self._wanted_thumb_cols() != getattr(self, "_thumb_cols", 0):
            self.display_thumbnails()

    def _crop_aspect(self):
        value = self.crop_shape.currentData()
        if value == "orig":
            r = self.preview_label.image_rect()
            return (r.width() / r.height()) if r is not None and r.height() else None
        return value

    def _end_crop_mode(self):
        self.preview_label.set_crop_mode(False)
        self.crop_button.setText("\u2702  Crop")
        self.crop_cancel_button.setVisible(False)
        self.crop_hint.setText("")

    def toggle_crop(self):
        if self.preview_image is None:
            return
        label = self.preview_label
        self.grey_button.setChecked(False)
        if not label.crop_mode:
            # start: show the whole photo with a frame on it
            self.zoom_scale = None
            label.crop_mode = True
            self.apply_pipeline()
            label.aspect = self._crop_aspect()
            label.selection = self.pipeline.crop or label.default_selection()
            label.set_crop_mode(True)
            self.crop_button.setText("\u2713  Apply Crop")
            self.crop_cancel_button.setVisible(True)
            self.crop_hint.setText("Pull the corners or sides to adjust the frame, drag inside it to move it, then press Apply Crop.")
        else:
            sel = label.selection
            full = sel is None or (sel[0] <= 0.001 and sel[1] <= 0.001 and sel[2] >= 0.999 and sel[3] >= 0.999)
            self.pipeline.crop = None if full else sel
            self._end_crop_mode()
            self.apply_pipeline()

    def cancel_crop(self):
        self._end_crop_mode()
        self.apply_pipeline()

    def clear_crop(self):
        self.pipeline.crop = None
        self._end_crop_mode()
        self.apply_pipeline()

    def crop_shape_changed(self):
        label = self.preview_label
        if label.crop_mode:
            label.aspect = self._crop_aspect()
            label.selection = label.default_selection()
            label.update()

    def rotate_image(self, direction):
        if self.preview_image is None:
            return
        self.pipeline.rotation = (self.pipeline.rotation + direction) % 4
        self.pipeline.crop = None      # the frame no longer fits a turned photo
        self._end_crop_mode()
        self.apply_pipeline()

    def flip_image(self):
        if self.preview_image is None:
            return
        self.pipeline.flip = not self.pipeline.flip
        if self.pipeline.crop:
            x0, y0, x1, y1 = self.pipeline.crop
            self.pipeline.crop = (1 - x1, y0, 1 - x0, y1)
        self.apply_pipeline()

    # ─────────────────────────────────────────────────

    def delete_current_photo(self):
        path = self.current_file_path
        if not path:
            QMessageBox.information(self, "Delete Photo", "Click a photo first, then delete it.")
            return
        name = os.path.basename(path)
        answer = QMessageBox.question(
            self, "Delete Photo",
            f"Move '{name}' to the Trash?\n\nYou can restore it from the Trash if you change your mind.",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if answer != QMessageBox.Yes:
            return
        try:
            from send2trash import send2trash
            send2trash(path)
        except Exception as e:
            QMessageBox.critical(self, "Delete Photo", f"Could not move the photo to the Trash.\n\n{e}")
            return
        shown = self._shown_files()
        index = shown.index(path) if path in shown else 0
        if path in self.image_files:
            self.image_files.remove(path)
        self.focus.pop(path, None)
        self._thumb_cache.pop(path, None)
        self._update_focus_summary()
        self.current_image = None
        self.current_file_path = None
        self.preview_image = None
        self.preview_label.clear()
        self.preview_label.setText("Photo moved to the Trash")
        self.display_thumbnails()
        shown = self._shown_files()
        if shown:
            self.load_image(shown[min(index, len(shown) - 1)])

    # ─────────────────────────────────────────────────

    def export_image(self):
        if self.current_image is None:
            QMessageBox.warning(self, "Export", "No image loaded.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Export Image", "", "JPEG (*.jpg);;PNG (*.png)"
        )
        if path:
            self.update_pipeline_values()
            processed = self.pipeline.apply(self.current_image)
            self.exporter.save(processed, path)
            QMessageBox.information(self, "Export", "Image exported successfully.")

    # ─────────────────────────────────────────────────

    def open_batch_rename(self):
        if not self.image_files:
            QMessageBox.warning(self, "Batch Rename", "No folder loaded.")
            return

        dialog = QDialog(self)
        dialog.setWindowTitle("Batch Rename")
        dialog.setMinimumWidth(500)
        layout = QFormLayout()

        pattern_input = QLineEdit("{prefix}_{date}_{n}")
        prefix_input = QLineEdit()
        preview_box = QTextEdit()
        preview_box.setReadOnly(True)
        preview_box.setMaximumHeight(200)

        def update_preview():
            results = self.batch_renamer.preview(
                self.image_files,
                pattern_input.text(),
                prefix_input.text()
            )
            lines = [f"{os.path.basename(old)} → {new}" for old, new in results[:10]]
            if len(self.image_files) > 10:
                lines.append(f"... and {len(self.image_files) - 10} more")
            preview_box.setText("\n".join(lines))

        pattern_input.textChanged.connect(update_preview)
        prefix_input.textChanged.connect(update_preview)

        layout.addRow("Pattern:", pattern_input)
        layout.addRow("Prefix:", prefix_input)
        layout.addRow("Preview:", preview_box)

        hint = QLabel("Tokens: {name} {n} {date} {prefix} {ext}")
        hint.setStyleSheet("color: #888; font-size: 11px;")
        layout.addRow(hint)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addRow(buttons)

        dialog.setLayout(layout)
        update_preview()

        if dialog.exec() == QDialog.Accepted:
            results = self.batch_renamer.execute(
                self.image_files,
                pattern_input.text(),
                prefix_input.text()
            )
            success = sum(1 for _, _, ok, _ in results if ok)
            failed = [(old, err) for old, _, ok, err in results if not ok]

            msg = f"{success} files renamed successfully."
            if failed:
                msg += f"\n{len(failed)} failed."
            QMessageBox.information(self, "Batch Rename", msg)
            self.import_folder()

    # ─────────────────────────────────────────────────

    def open_watermark(self):
        if self.current_image is None:
            QMessageBox.warning(self, "Watermark", "No image loaded.")
            return

        dialog = QDialog(self)
        dialog.setWindowTitle("Add Watermark")
        layout = QFormLayout()

        text_input = QLineEdit("© Your Name")
        position_combo = QComboBox()
        position_combo.addItems(self.watermarker.POSITIONS)
        position_combo.setCurrentText("bottom_right")

        opacity_slider = QSlider(Qt.Horizontal)
        opacity_slider.setRange(10, 100)
        opacity_slider.setValue(60)

        layout.addRow("Text:", text_input)
        layout.addRow("Position:", position_combo)
        layout.addRow("Opacity:", opacity_slider)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addRow(buttons)
        dialog.setLayout(layout)

        if dialog.exec() == QDialog.Accepted:
            self.update_pipeline_values()
            processed = self.pipeline.apply(self.current_image)
            watermarked = self.watermarker.apply_text(
                processed,
                text=text_input.text(),
                position=position_combo.currentText(),
                opacity=opacity_slider.value() / 100.0
            )
            path, _ = QFileDialog.getSaveFileName(
                self, "Export Watermarked Image", "", "JPEG (*.jpg);;PNG (*.png)"
            )
            if path:
                self.exporter.save(watermarked, path)
                QMessageBox.information(self, "Watermark", "Watermarked image exported.")

    # ─────────────────────────────────────────────────

    def open_metadata(self):
        if not self.current_file_path:
            QMessageBox.warning(self, "Metadata", "No image loaded.")
            return

        dialog = QDialog(self)
        dialog.setWindowTitle("Metadata Editor")
        dialog.setMinimumWidth(480)
        layout = QFormLayout()

        summary = self.metadata_editor.summary(self.current_file_path)
        exif_box = QTextEdit(summary)
        exif_box.setReadOnly(True)
        exif_box.setMaximumHeight(180)

        artist_input = QLineEdit()
        copyright_input = QLineEdit()
        description_input = QLineEdit()

        layout.addRow("EXIF Data:", exif_box)
        layout.addRow("Artist:", artist_input)
        layout.addRow("Copyright:", copyright_input)
        layout.addRow("Description:", description_input)

        note = QLabel("Changes are written to exported JPEG files only.")
        note.setStyleSheet("color: #888; font-size: 11px;")
        layout.addRow(note)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addRow(buttons)
        dialog.setLayout(layout)

        if dialog.exec() == QDialog.Accepted:
            ext = os.path.splitext(self.current_file_path)[1].lower()
            if ext not in [".jpg", ".jpeg"]:
                QMessageBox.information(self, "Metadata", "Metadata writing is only supported for JPEG files.\nExport as JPEG first.")
                return
            try:
                self.metadata_editor.write(
                    self.current_file_path,
                    artist=artist_input.text(),
                    copyright=copyright_input.text(),
                    description=description_input.text()
                )
                QMessageBox.information(self, "Metadata", "Metadata saved successfully.")
            except Exception as e:
                QMessageBox.critical(self, "Metadata Error", str(e))
