"""The film strip, as on the phone: pictures of the whole video, the part to keep
framed in gold, the teal IN edge and the gold OUT edge to drag, and a white
playhead. Clicking anywhere else moves the playhead there."""
from PySide6.QtCore import Qt, Signal, QRectF
from PySide6.QtGui import QPainter, QColor, QImage, QPen
from PySide6.QtWidgets import QWidget

GOLD = QColor("#F5A623")
TEAL = QColor("#2EC4B6")


class Timeline(QWidget):
    scrubbed = Signal(int)          # ms: the playhead was moved by the person
    in_changed = Signal(int)
    out_changed = Signal(int)
    edit_finished = Signal()        # an edge was let go (check the keyframe then)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(86)
        self.setMouseTracking(True)
        self.duration = 0
        self.in_ms = 0
        self.out_ms = 0
        self.pos_ms = 0
        self.frames = []            # QImages
        self._drag = 0              # 1 = IN edge, 2 = OUT edge, 3 = playhead
        self.touching = False

    def set_frames(self, arrays):
        self.frames = []
        for a in arrays:
            h, w = a.shape[:2]
            self.frames.append(QImage(a.data, w, h, 3 * w, QImage.Format_RGB888).copy())
        self.update()

    # positions
    def _x(self, ms):
        return 0.0 if self.duration <= 0 else ms / self.duration * self.width()

    def _ms(self, x):
        if self.duration <= 0 or self.width() <= 0:
            return 0
        x = min(max(x, 0.0), float(self.width()))
        return int(x / self.width() * self.duration)

    def paintEvent(self, _e):
        p = QPainter(self)
        w, h = float(self.width()), float(self.height())
        p.fillRect(self.rect(), QColor("#10151C"))
        if self.frames:
            cw = w / len(self.frames)
            for i, img in enumerate(self.frames):
                dst = QRectF(i * cw, 0, cw, h)
                ar, iar = cw / h, img.width() / max(1, img.height())
                if iar > ar:                            # crop to fill each cell
                    sw = img.height() * ar
                    src = QRectF((img.width() - sw) / 2, 0, sw, img.height())
                else:
                    sh = img.width() / ar
                    src = QRectF(0, (img.height() - sh) / 2, img.width(), sh)
                p.drawImage(dst, img, src)
        if self.duration > 0:
            xi, xo = self._x(self.in_ms), self._x(self.out_ms)
            shade = QColor(0, 0, 0, 185)                 # what will NOT be kept
            p.fillRect(QRectF(0, 0, xi, h), shade)
            p.fillRect(QRectF(xo, 0, w - xo, h), shade)
            p.setPen(QPen(GOLD, 3))                      # what WILL be kept
            p.setBrush(Qt.NoBrush)
            p.drawRect(QRectF(xi, 1.5, xo - xi, h - 3))
            p.fillRect(QRectF(xi - 5, 0, 10, h), TEAL)
            p.fillRect(QRectF(xo - 5, 0, 10, h), GOLD)
            xp = self._x(self.pos_ms)
            p.fillRect(QRectF(xp - 1.5, 0, 3, h), Qt.white)
        p.end()

    def _which(self, x):
        di, do = abs(x - self._x(self.in_ms)), abs(x - self._x(self.out_ms))
        slop = 14
        if di <= slop and di <= do:
            return 1
        if do <= slop:
            return 2
        return 3

    def mousePressEvent(self, e):
        if self.duration <= 0 or e.button() != Qt.LeftButton:
            return
        self.touching = True
        self._drag = self._which(e.position().x())
        self._move(e.position().x())

    def mouseMoveEvent(self, e):
        if self._drag:
            self._move(e.position().x())
        elif self.duration > 0:
            self.setCursor(Qt.SizeHorCursor if self._which(e.position().x()) in (1, 2) else Qt.PointingHandCursor)

    def mouseReleaseEvent(self, _e):
        if self._drag in (1, 2):
            self.edit_finished.emit()
        self._drag = 0
        self.touching = False

    def _move(self, x):
        ms = self._ms(x)
        if self._drag == 1:
            self.in_ms = min(ms, max(0, self.out_ms - 100))
            self.pos_ms = self.in_ms
            self.in_changed.emit(self.in_ms)
            self.scrubbed.emit(self.in_ms)
        elif self._drag == 2:
            self.out_ms = max(ms, min(self.duration, self.in_ms + 100))
            self.pos_ms = self.out_ms
            self.out_changed.emit(self.out_ms)
            self.scrubbed.emit(self.out_ms)
        else:
            self.pos_ms = ms
            self.scrubbed.emit(ms)
        self.update()
