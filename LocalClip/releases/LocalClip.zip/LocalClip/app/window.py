"""LocalClip's window: the same tool as the Android app, laid out for a computer.

Open one long video (the master), mark IN and OUT, save a lossless clip, then mark
the next one: the master stays open, so you can cut clip after clip without
loading anything again.
"""
import os
import sys
import threading

from PySide6.QtCore import Qt, QObject, Signal, QUrl, QTimer, QSettings, QStandardPaths
from PySide6.QtGui import QKeySequence, QShortcut, QPixmap, QDesktopServices, QIcon
from PySide6.QtMultimedia import QMediaPlayer, QAudioOutput
from PySide6.QtMultimediaWidgets import QVideoWidget
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QStackedLayout, QScrollArea, QSizePolicy,
    QComboBox as _QtComboBox, QMessageBox as _QtMessageBox,
)

from app import clipper
from app.clipper import fmt
from app.timeline import Timeline
from app.i18n import (tr, translate_tree, LANGUAGES, LANG, computer_language,
                      QPushButton, QLabel, QLineEdit, QFileDialog, QMessageBox)

APP_VERSION = "2.0"      # shown in the window title, so an old copy is easy to spot

BG, PANEL, KEY = "#0B0F14", "#141A22", "#26303C"
GOLD, TEAL, DIM, GREEN = "#F5A623", "#2EC4B6", "#8A96A3", "#52B788"
KOFI = "https://ko-fi.com/satdiva"
VIDEO_FILES = "*.mp4 *.mov *.m4v *.mkv *.avi *.mts *.m2ts *.ts *.webm *.3gp *.MP4 *.MOV *.M4V *.MKV *.MTS"


def resource(name):
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    return os.path.join(base, "resources", name)


def pill(text, bg, fg, small=False):
    b = QPushButton(text)
    b.setCursor(Qt.PointingHandCursor)
    b.setStyleSheet(
        f"QPushButton {{ background:{bg}; color:{fg}; border:none; border-radius:{8 if small else 10}px;"
        f" padding:{'6px 4px' if small else '10px 12px'}; font-size:{12 if small else 14}px; font-weight:600; }}"
        f"QPushButton:hover {{ border:1px solid {GOLD}; }}"
        f"QPushButton:disabled {{ background:#1d242d; color:#4b5560; }}")
    return b


def label(text, size, color, bold=False):
    l = QLabel(text)
    l.setWordWrap(True)
    l.setStyleSheet(f"color:{color}; font-size:{size}px; {'font-weight:700;' if bold else ''} background:transparent;")
    return l


class _Bridge(QObject):
    """Brings results from background work back to the window."""
    frames = Signal(object, object)          # path, list of pictures
    snap = Signal(object, int, int)          # path, IN asked, keyframe found
    saved = Signal(bool, str, str)           # ok, message, path
    progress = Signal(float)


class ClipWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(tr(f"LocalClip {APP_VERSION}  —  Lossless video trimming"))
        self.setWindowIcon(QIcon(resource("icon.png")))
        self.setAcceptDrops(True)
        self.settings = QSettings("ImageStream", "LocalClip")
        self.path = None
        self.info = None
        self.duration = 0
        self.in_ms = 0
        self.out_ms = 0
        self.name_edited = False
        self.saving = False
        self.bridge = _Bridge()
        self.bridge.frames.connect(self._got_frames)
        self.bridge.snap.connect(self._got_snap)
        self.bridge.saved.connect(self._got_saved)
        self.bridge.progress.connect(lambda f: self.status.setText(tr("Saving…") + f"  {int(f * 100)}%"))
        self._build()
        self._shortcuts()
        self.resize(1280, 820)
        self.setMinimumSize(1000, 680)
        translate_tree(self)
        self.refresh()

    # ───────────────────────── layout ─────────────────────────

    def _build(self):
        root = QWidget()
        root.setStyleSheet(f"background:{BG};")
        outer = QVBoxLayout(root)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        # header: logo, name, language
        header = QWidget()
        header.setStyleSheet(f"background:{BG};")
        hl = QHBoxLayout(header)
        hl.setContentsMargins(16, 10, 16, 10)
        logo = QLabel()
        logo.setPixmap(QPixmap(resource("logo.png")).scaled(44, 44, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        hl.addWidget(logo)
        titles = QVBoxLayout()
        titles.setSpacing(0)
        titles.addWidget(label("LocalClip", 22, GOLD, True))
        titles.addWidget(label(tr("Lossless · Local · No recompression"), 12, DIM))
        hl.addLayout(titles, 1)
        kofi = pill("☕ Ko-fi", GOLD, "black", small=True)
        kofi.setFixedWidth(90)
        kofi.setToolTip(tr("LocalClip is free. If it helps your work, a coffee on Ko-fi keeps it going."))
        kofi.clicked.connect(self.open_kofi)
        hl.addWidget(kofi)
        hl.addSpacing(14)
        hl.addWidget(label(tr("Language:"), 12, DIM))
        self.language_box = _QtComboBox()
        self.language_box.addItem(tr("Automatic (like the computer)"), "auto")
        for code, name in LANGUAGES:
            self.language_box.addItem(name, code)
        saved = self.settings.value("language", "auto", type=str)
        self.language_box.setCurrentIndex(max(0, self.language_box.findData(saved)))
        self.language_box.setStyleSheet(f"QComboBox {{ background:{KEY}; color:white; border-radius:6px; padding:4px 8px; }}")
        self.language_box.currentIndexChanged.connect(self._language_changed)
        hl.addWidget(self.language_box)
        outer.addWidget(header)

        # body: video on the left, controls on the right
        body = QHBoxLayout()
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(0)

        stage = QWidget()
        stage.setStyleSheet("background:black;")
        self.stage_stack = QStackedLayout(stage)
        empty = QWidget()
        el = QVBoxLayout(empty)
        el.setAlignment(Qt.AlignCenter)
        msg = label(tr("Choose a video to trim"), 18, DIM)
        msg.setAlignment(Qt.AlignCenter)
        el.addWidget(msg)
        hint = label(tr("or drop it here"), 13, DIM)
        hint.setAlignment(Qt.AlignCenter)
        el.addWidget(hint)
        big = pill(tr("Open video"), GOLD, "black")
        big.setFixedWidth(240)
        big.clicked.connect(self.open_video)
        el.addSpacing(14)
        el.addWidget(big, 0, Qt.AlignCenter)
        self.video_widget = QVideoWidget()
        self.video_widget.setStyleSheet("background:black;")
        self.stage_stack.addWidget(empty)
        self.stage_stack.addWidget(self.video_widget)
        body.addWidget(stage, 3)

        side = QScrollArea()
        side.setWidgetResizable(True)
        side.setFixedWidth(380)
        side.setStyleSheet(f"QScrollArea {{ background:{PANEL}; border:none; }}")
        side.setWidget(self._panel())
        body.addWidget(side)
        outer.addLayout(body, 1)

        # film strip
        strip = QWidget()
        strip.setStyleSheet(f"background:{PANEL};")
        sl = QVBoxLayout(strip)
        sl.setContentsMargins(12, 8, 12, 10)
        self.timeline = Timeline()
        self.timeline.scrubbed.connect(self._scrub)
        self.timeline.in_changed.connect(lambda ms: self._set_in(ms, check=False))
        self.timeline.out_changed.connect(self._set_out)
        self.timeline.edit_finished.connect(self.check_snap)
        sl.addWidget(self.timeline)
        outer.addWidget(strip)
        self.setCentralWidget(root)

        # player
        self.player = QMediaPlayer(self)
        self.audio = None
        if not os.environ.get("LOCALCLIP_NO_AUDIO"):      # only for automatic tests on machines without sound
            self.audio = QAudioOutput(self)
            self.player.setAudioOutput(self.audio)
        self.player.setVideoOutput(self.video_widget)
        self.player.positionChanged.connect(self._playing_at)
        self.player.playbackStateChanged.connect(self._play_state)
        self.player.errorOccurred.connect(self._player_error)

    def _panel(self):
        panel = QWidget()
        panel.setStyleSheet(f"background:{PANEL};")
        v = QVBoxLayout(panel)
        v.setContentsMargins(14, 12, 14, 12)
        v.setSpacing(8)

        self.pos_text = label("00:00.000", 34, "white", True)
        self.pos_text.setAlignment(Qt.AlignCenter)
        self.pos_text.setStyleSheet(self.pos_text.styleSheet() + "font-family: Menlo, Consolas, monospace;")
        v.addWidget(self.pos_text)
        self.dur_text = label("", 12, DIM)
        self.dur_text.setAlignment(Qt.AlignCenter)
        v.addWidget(self.dur_text)

        self.nudges = []

        def row(items, colour):
            h = QHBoxLayout()
            h.setSpacing(5)
            for text, ms in items:
                b = pill(text, colour, "white", small=True)
                b.clicked.connect(lambda _=False, d=ms: self.nudge(d))
                self.nudges.append(b)
                h.addWidget(b)
            v.addLayout(h)

        row([("−60s", -60000), ("−30s", -30000), ("−10s", -10000),
             ("+10s", 10000), ("+30s", 30000), ("+60s", 60000)], KEY)
        row([("−3s", -3000), ("−1s", -1000), ("+1s", 1000), ("+3s", 3000)], "#3A4757")
        row([("−200ms", -200), ("−50ms", -50), ("+50ms", 50), ("+200ms", 200)], KEY)
        h = QHBoxLayout()
        h.setSpacing(5)
        self.frame_back = pill(tr("◀ 1 frame"), "#3A4757", "white", small=True)
        self.frame_back.clicked.connect(lambda: self.step_frame(-1))
        self.frame_fwd = pill(tr("1 frame ▶"), "#3A4757", "white", small=True)
        self.frame_fwd.clicked.connect(lambda: self.step_frame(1))
        h.addWidget(self.frame_back)
        h.addWidget(self.frame_fwd)
        v.addLayout(h)

        self.play_btn = pill(tr("Play / Pause"), KEY, "white")
        self.play_btn.clicked.connect(self.toggle_play)
        v.addWidget(self.play_btn)

        h = QHBoxLayout()
        self.in_btn = pill(tr("Set IN"), TEAL, "black")
        self.in_btn.clicked.connect(lambda: self._set_in(self.player.position()))
        self.out_btn = pill(tr("Set OUT"), GOLD, "black")
        self.out_btn.clicked.connect(lambda: self._set_out(self.player.position()))
        h.addWidget(self.in_btn)
        h.addWidget(self.out_btn)
        v.addLayout(h)

        self.range_text = label("", 13, "white", True)
        self.range_text.setAlignment(Qt.AlignCenter)
        v.addWidget(self.range_text)
        self.snap_text = label("", 12, TEAL)
        self.snap_text.setAlignment(Qt.AlignCenter)
        v.addWidget(self.snap_text)

        v.addSpacing(4)
        v.addWidget(label(tr("Save as:"), 12, DIM))
        self.name_edit = QLineEdit()
        self.name_edit.setPlaceholderText(tr("Name of the clip"))
        self.name_edit.setStyleSheet(f"QLineEdit {{ background:{KEY}; color:white; border-radius:6px; padding:7px; font-size:13px; }}")
        self.name_edit.textEdited.connect(lambda _t: setattr(self, "name_edited", True))
        v.addWidget(self.name_edit)

        self.save_btn = pill(tr("Save lossless clip"), GOLD, "black")
        self.save_btn.clicked.connect(self.save)
        v.addWidget(self.save_btn)

        h = QHBoxLayout()
        self.open_btn = pill(tr("Open video"), KEY, "white", small=True)
        self.open_btn.clicked.connect(self.open_video)
        self.folder_btn = pill(tr("Change folder…"), KEY, "white", small=True)
        self.folder_btn.clicked.connect(self.change_folder)
        h.addWidget(self.open_btn)
        h.addWidget(self.folder_btn)
        v.addLayout(h)
        self.folder_text = label("", 11, DIM)
        v.addWidget(self.folder_text)

        self.status = label("", 13, GREEN)
        self.status.setAlignment(Qt.AlignCenter)
        v.addWidget(self.status)
        self.show_btn = pill(tr("Show in folder"), KEY, "white", small=True)
        self.show_btn.clicked.connect(self.show_in_folder)
        self.show_btn.hide()
        v.addWidget(self.show_btn)
        self.thanks_btn = pill(tr("☕ Thank you! Say thanks on Ko-fi"), GOLD, "black", small=True)
        self.thanks_btn.clicked.connect(self.open_kofi)
        self.thanks_btn.hide()
        v.addWidget(self.thanks_btn)
        self.last_saved = None

        hint = label(tr("Drag the gold edges on the film strip to choose what to keep. Click the strip to move "
                        "the playhead. Original quality, no re-encoding: the start snaps back to the nearest "
                        "earlier keyframe; the end lands on the frame."), 11, DIM)
        hint.setAlignment(Qt.AlignCenter)
        v.addWidget(hint)
        keys = label(tr("Keys: Space play · I / O set IN / OUT · ← → one frame · Shift+← → one second · "
                        "⌘S / Ctrl+S save"), 11, DIM)
        keys.setAlignment(Qt.AlignCenter)
        v.addWidget(keys)
        love = label(tr("Made with love by Satdiva. LocalClip is free, private and works offline: "
                        "no ads, no tracking.") + " " +
                     tr("If it helps your work, a coffee on Ko-fi keeps it going. Thank you!"), 12, GOLD)
        love.setAlignment(Qt.AlignCenter)
        love.setCursor(Qt.PointingHandCursor)
        love.mousePressEvent = lambda _e: self.open_kofi()
        v.addWidget(love)
        v.addStretch(1)
        self._show_folder()
        return panel

    def _shortcuts(self):
        QShortcut(QKeySequence(Qt.Key_Space), self, activated=self.toggle_play)
        QShortcut(QKeySequence("I"), self, activated=lambda: self._set_in(self.player.position()))
        QShortcut(QKeySequence("O"), self, activated=lambda: self._set_out(self.player.position()))
        QShortcut(QKeySequence(Qt.Key_Left), self, activated=lambda: self.step_frame(-1))
        QShortcut(QKeySequence(Qt.Key_Right), self, activated=lambda: self.step_frame(1))
        QShortcut(QKeySequence("Shift+Left"), self, activated=lambda: self.nudge(-1000))
        QShortcut(QKeySequence("Shift+Right"), self, activated=lambda: self.nudge(1000))
        QShortcut(QKeySequence.Save, self, activated=self.save)
        QShortcut(QKeySequence.Open, self, activated=self.open_video)

    # ───────────────────────── opening ─────────────────────────

    def open_video(self):
        start = self.settings.value("open_dir", QStandardPaths.writableLocation(QStandardPaths.MoviesLocation), type=str)
        path, _f = QFileDialog.getOpenFileName(self, "Open video", start, f"{tr('Videos')} ({VIDEO_FILES})")
        if path:
            self.load(path)

    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e):
        for u in e.mimeData().urls():
            if u.isLocalFile():
                self.load(u.toLocalFile())
                return

    def load(self, path):
        try:
            info = clipper.probe(path)
        except clipper.ClipError as e:
            QMessageBox.warning(self, "LocalClip", tr("Could not read that file:") + f"\n{e}")
            return
        self.settings.setValue("open_dir", os.path.dirname(path))
        self.path, self.info = path, info
        self.duration = info["duration_ms"]
        self.in_ms, self.out_ms = 0, self.duration
        self.name_edited = False
        self.status.setText("")
        self.snap_text.setText("")
        self.show_btn.hide()
        self.timeline.duration = self.duration
        self.timeline.frames = []
        self.timeline.pos_ms = 0
        self.stage_stack.setCurrentIndex(1)
        self.player.setSource(QUrl.fromLocalFile(path))
        self.player.pause()
        QTimer.singleShot(150, lambda: self.player.setPosition(1))
        self.refresh()
        threading.Thread(target=self._frames_job, args=(path, self.duration), daemon=True).start()

    def _frames_job(self, path, dur):
        n = max(8, min(20, self.timeline.width() // 70))
        self.bridge.frames.emit(path, clipper.thumbnails(path, dur, n))

    def _got_frames(self, path, frames):
        if path == self.path:
            self.timeline.set_frames(frames)

    def _player_error(self, _err, text):
        if self.path:
            self.status.setStyleSheet(f"color:{GOLD}; font-size:13px; background:transparent;")
            self.status.setText(tr("This video can't be previewed here, but it can still be cut.")
                                + (f"\n{text}" if text else ""))

    # ───────────────────────── moving around ─────────────────────────

    def _playing_at(self, ms):
        if not self.timeline.touching:
            self.timeline.pos_ms = ms
            self.timeline.update()
        self.pos_text.setText(fmt(ms))

    def _play_state(self, state):
        self.play_btn.setText(tr("Pause") if state == QMediaPlayer.PlayingState else tr("Play / Pause"))

    def _scrub(self, ms):
        self.player.pause()
        self.player.setPosition(int(ms))
        self.pos_text.setText(fmt(ms))

    def toggle_play(self):
        if not self.path:
            return
        if self.player.playbackState() == QMediaPlayer.PlayingState:
            self.player.pause()
        else:
            if self.player.position() >= self.duration - 30:
                self.player.setPosition(self.in_ms)
            self.player.play()

    def nudge(self, delta):
        if not self.path:
            return
        target = min(max(0, self.player.position() + delta), self.duration)
        self.player.pause()
        self.player.setPosition(int(target))
        self.timeline.pos_ms = target
        self.timeline.update()
        self.pos_text.setText(fmt(target))

    def step_frame(self, n):
        fps = (self.info or {}).get("fps") or 30.0
        self.nudge(int(round(n * 1000.0 / fps)) or n)

    # ───────────────────────── IN / OUT ─────────────────────────

    def _set_in(self, ms, check=True):
        if not self.path:
            return
        self.in_ms = int(min(max(0, ms), max(0, self.out_ms - 100)))
        self.refresh()
        if check:
            self.check_snap()

    def _set_out(self, ms):
        if not self.path:
            return
        self.out_ms = int(max(min(self.duration, ms), min(self.duration, self.in_ms + 100)))
        self.refresh()

    def check_snap(self):
        if not self.path:
            return
        path, at = self.path, self.in_ms
        threading.Thread(target=lambda: self.bridge.snap.emit(path, at, clipper.keyframe_before(path, at)),
                         daemon=True).start()

    def _got_snap(self, path, asked, found):
        if path != self.path or asked != self.in_ms:
            return
        if found < 0:
            self.snap_text.setText("")
        elif found >= asked - 20:
            self.snap_text.setText(tr("Start is on a keyframe: exact."))
        else:
            self.snap_text.setText(tr("Start will snap back to {} (nearest earlier keyframe).").format(fmt(found)))

    def refresh(self):
        has = self.path is not None
        for w in self.nudges + [self.frame_back, self.frame_fwd, self.play_btn, self.in_btn,
                                self.out_btn, self.save_btn, self.name_edit]:
            w.setEnabled(has and not (self.saving and w is self.save_btn))
        self.dur_text.setText(tr("of {}").format(fmt(self.duration)) if has else "")
        length = fmt(self.out_ms - self.in_ms) if self.out_ms > self.in_ms else fmt(0)
        self.range_text.setText(tr("IN {}    OUT {}    LENGTH {}").format(fmt(self.in_ms), fmt(self.out_ms), length)
                                if has else "")
        self.timeline.in_ms, self.timeline.out_ms = self.in_ms, self.out_ms
        self.timeline.update()
        if has and not self.name_edited:
            stem = os.path.splitext(os.path.basename(self.path))[0]
            self.name_edit.setText(f"{stem}_{self._stamp(self.in_ms)}-{self._stamp(self.out_ms)}")

    @staticmethod
    def _stamp(ms):
        return fmt(ms).replace(":", "m").replace(".", "s")

    # ───────────────────────── saving ─────────────────────────

    def _folder(self):
        default = os.path.join(QStandardPaths.writableLocation(QStandardPaths.MoviesLocation), "LocalClip")
        return self.settings.value("save_dir", default, type=str) or default

    def _show_folder(self):
        self.folder_text.setText(tr("Saves to: {}").format(self._folder()))

    def change_folder(self):
        d = QFileDialog.getExistingDirectory(self, "Choose where clips are saved", self._folder())
        if d:
            self.settings.setValue("save_dir", d)
            self._show_folder()

    def _out_path(self):
        ext = os.path.splitext(self.path)[1] or ".mp4"
        if ext.lower() in (".avi", ".webm", ".3gp", ".wmv", ".flv"):
            ext = ".mkv"                      # these can't hold every kind of video: mkv can
        name = "".join(c for c in (self.name_edit.text().strip() or "clip") if c not in '\\/:*?"<>|').strip() or "clip"
        folder = self._folder()
        os.makedirs(folder, exist_ok=True)
        out = os.path.join(folder, name + ext)
        n = 2
        while os.path.exists(out):            # never overwrite an earlier clip
            out = os.path.join(folder, f"{name} ({n}){ext}")
            n += 1
        return out

    def save(self):
        if not self.path:
            self.status.setText(tr("Open a video first."))
            return
        if self.out_ms <= self.in_ms:
            self.status.setText(tr("OUT must be after IN."))
            return
        if self.saving:
            return
        try:
            out = self._out_path()
        except OSError as e:
            QMessageBox.warning(self, "LocalClip", tr("Could not create the folder:") + f"\n{e}")
            return
        self.saving = True
        self.refresh()
        self.show_btn.hide()
        self.thanks_btn.hide()
        self.status.setStyleSheet(f"color:{GREEN}; font-size:13px; background:transparent;")
        self.status.setText(tr("Saving…"))
        src, a, b = self.path, self.in_ms, self.out_ms

        def job():
            try:
                clipper.trim(src, a, b, out, progress=self.bridge.progress.emit)
                self.bridge.saved.emit(True, "", out)
            except Exception as e:
                self.bridge.saved.emit(False, str(e), out)

        threading.Thread(target=job, daemon=True).start()

    def _got_saved(self, ok, message, out):
        self.saving = False
        if ok:
            self.last_saved = out
            self.status.setStyleSheet(f"color:{GREEN}; font-size:13px; background:transparent;")
            self.status.setText(tr("Saved: {}").format(os.path.basename(out)))
            self.show_btn.show()
            self.thanks_btn.show()
            self.name_edited = False          # the next clip gets a fresh name
        else:
            self.status.setStyleSheet(f"color:{GOLD}; font-size:13px; background:transparent;")
            self.status.setText(tr("Could not save:") + f" {message}")
        self.refresh()

    def open_kofi(self):
        QDesktopServices.openUrl(QUrl(KOFI))

    def show_in_folder(self):
        if not self.last_saved:
            return
        if sys.platform == "darwin":
            import subprocess
            subprocess.run(["open", "-R", self.last_saved])
        elif sys.platform.startswith("win"):
            import subprocess
            subprocess.run(["explorer", "/select,", os.path.normpath(self.last_saved)])
        else:
            QDesktopServices.openUrl(QUrl.fromLocalFile(os.path.dirname(self.last_saved)))

    # ───────────────────────── language ─────────────────────────

    def _language_changed(self, _i):
        code = self.language_box.currentData()
        self.settings.setValue("language", code)
        shown = computer_language() if code == "auto" else code
        _QtMessageBox.information(self, "LocalClip",
                                  tr("Close LocalClip and open it again to see the new language.", shown))

    def closeEvent(self, e):
        self.player.stop()
        super().closeEvent(e)
