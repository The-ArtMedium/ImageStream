"""Quick Start: the manual, inside the app, in the person's language.
Opens by itself the first time LocalClip starts, and any time from the ? button."""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QDialog, QVBoxLayout, QHBoxLayout, QScrollArea, QWidget

from app.i18n import tr, QLabel, QPushButton, QCheckBox

STEPS = [
    ("Open a video",
     "Click Open video, or drop a video on the window. This is your master: it stays open while you cut as many clips as you want."),
    ("Find the moment",
     "Press Space to play and pause. Click the film strip to jump anywhere. Fine-tune with the buttons, from ±60 seconds down to ±50 milliseconds, or with the arrow keys: ← → one frame, Shift + ← → one second."),
    ("Mark the start",
     "On the first frame you want, press Set IN (or the I key). The teal edge moves there. LocalClip tells you if the clip will really start a little earlier, on the nearest keyframe."),
    ("Mark the end",
     "On the last frame you want, press Set OUT (or the O key). The gold frame on the film strip shows exactly what you keep. You can also drag the teal and gold edges with the mouse."),
    ("Name it",
     "The name fills in by itself: the video's name plus the IN and OUT times. Type your own name if you like, to find the clip easily later."),
    ("Save",
     "Press Save lossless clip (⌘S on Mac, Ctrl+S on Windows). It takes seconds, because nothing is re-encoded: the clip has the original quality. Show in folder opens the place it went."),
    ("Cut the next clip",
     "Mark a new IN and OUT and save again. The master stays open, and an earlier clip is never overwritten."),
]


class QuickStart(QDialog):
    def __init__(self, parent, settings):
        super().__init__(parent)
        self.settings = settings
        self.setWindowTitle(tr("Quick Start"))
        self.resize(560, 640)
        self.setStyleSheet("QDialog { background:#141A22; }")
        v = QVBoxLayout(self)
        v.setContentsMargins(18, 16, 18, 14)
        title = QLabel(tr("Quick Start"))
        title.setStyleSheet("color:#F5A623; font-size:22px; font-weight:700;")
        v.addWidget(title)
        intro = QLabel(tr("LocalClip cuts pieces out of a long video without losing any quality. Here is how, step by step."))
        intro.setWordWrap(True)
        intro.setStyleSheet("color:#c9d1d9; font-size:13px;")
        v.addWidget(intro)

        area = QScrollArea()
        area.setWidgetResizable(True)
        area.setStyleSheet("QScrollArea { border:none; background:#141A22; }")
        inner = QWidget()
        inner.setStyleSheet("background:#141A22;")
        iv = QVBoxLayout(inner)
        iv.setSpacing(12)
        for n, (head, body) in enumerate(STEPS, 1):
            row = QHBoxLayout()
            num = QLabel(str(n))
            num.setFixedSize(30, 30)
            num.setAlignment(Qt.AlignCenter)
            num.setStyleSheet("background:#F5A623; color:black; border-radius:15px; font-weight:700; font-size:14px;")
            row.addWidget(num, 0, Qt.AlignTop)
            col = QVBoxLayout()
            col.setSpacing(2)
            h = QLabel(tr(head))
            h.setStyleSheet("color:white; font-size:15px; font-weight:700;")
            b = QLabel(tr(body))
            b.setWordWrap(True)
            b.setStyleSheet("color:#c9d1d9; font-size:13px;")
            col.addWidget(h)
            col.addWidget(b)
            row.addLayout(col, 1)
            iv.addLayout(row)
        tip = QLabel(tr("Clips are saved in Movies/LocalClip (Videos/LocalClip on Windows). Change folder… picks another place."))
        tip.setWordWrap(True)
        tip.setStyleSheet("color:#2EC4B6; font-size:12px; padding-top:6px;")
        iv.addWidget(tip)
        iv.addStretch(1)
        area.setWidget(inner)
        v.addWidget(area, 1)

        bottom = QHBoxLayout()
        self.at_start = QCheckBox(tr("Show this when LocalClip starts"))
        self.at_start.setStyleSheet("color:#8A96A3; font-size:12px;")
        self.at_start.setChecked(settings.value("quickstart_at_start", True, type=bool))
        self.at_start.toggled.connect(lambda on: settings.setValue("quickstart_at_start", on))
        bottom.addWidget(self.at_start, 1)
        ok = QPushButton(tr("Got it"))
        ok.setStyleSheet("QPushButton { background:#F5A623; color:black; border:none; border-radius:8px; padding:8px 22px; font-weight:700; }")
        ok.clicked.connect(self.accept)
        bottom.addWidget(ok)
        v.addLayout(bottom)
