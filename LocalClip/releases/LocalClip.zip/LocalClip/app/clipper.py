"""The heart of LocalClip: lossless cuts, the same way the Android app does it.

Nothing is re-encoded. The compressed video and sound are copied packet by packet
from the original into the new file, so the clip has exactly the original quality
and is written in seconds, whatever its length.

One rule comes with that: a clip has to start on a keyframe (a full picture the
others are built from). So the start moves back to the nearest keyframe at or
before IN; the end stops on the frame at OUT. keyframe_before() tells the person
in advance where the start will really be.
"""
import os
from fractions import Fraction

import av
import numpy as np


class ClipError(Exception):
    pass


def probe(path):
    """Duration (ms), size, frame rate and rotation of a video, or raise ClipError."""
    try:
        with av.open(path) as c:
            v = next((s for s in c.streams if s.type == "video"), None)
            if v is None:
                raise ClipError("no video in this file")
            if c.duration:
                dur = c.duration / av.time_base
            elif v.duration and v.time_base:
                dur = float(v.duration * v.time_base)
            else:
                dur = 0.0
            fps = float(v.average_rate) if v.average_rate else 30.0
            rotation = 0
            try:
                rotation = int(next(c.decode(v)).rotation or 0) % 360
            except Exception:
                rotation = _rotation(v)
            return {"duration_ms": int(dur * 1000), "width": v.codec_context.width,
                    "height": v.codec_context.height, "fps": fps or 30.0,
                    "rotation": rotation}
    except ClipError:
        raise
    except Exception as e:                       # not a video, damaged, unknown format
        raise ClipError(str(e)) from e


def _rotation(stream):
    """Degrees the picture must be turned for display (phones film sideways)."""
    try:
        rot = stream.metadata.get("rotate")
        if rot:
            return int(rot) % 360
    except Exception:
        pass
    try:
        dm = stream.side_data.get("DISPLAYMATRIX") if hasattr(stream, "side_data") else None
        if dm is not None:
            return int(round(float(dm))) % 360
    except Exception:
        pass
    return 0


def keyframe_before(path, at_ms):
    """Time (ms) of the keyframe at or before at_ms: where a lossless clip really starts."""
    try:
        with av.open(path) as c:
            v = next(s for s in c.streams if s.type == "video")
            tb = v.time_base
            target = int((at_ms / 1000) / tb) + (v.start_time or 0)
            c.seek(target, stream=v, backward=True, any_frame=False)
            for packet in c.demux(v):
                if packet.pts is None:
                    continue
                if packet.is_keyframe:
                    t = float((packet.pts - (v.start_time or 0)) * tb) * 1000
                    if t > at_ms + 1:                  # some files seek one keyframe too far
                        c.seek(max(0, target - int(5 / tb)), stream=v, backward=True, any_frame=False)
                        best = 0.0
                        for p in c.demux(v):
                            if p.pts is None:
                                continue
                            pt = float((p.pts - (v.start_time or 0)) * tb) * 1000
                            if pt > at_ms + 1:
                                break
                            if p.is_keyframe:
                                best = pt
                        return int(best)
                    return int(max(0.0, t))
    except Exception:
        pass
    return -1


def thumbnails(path, duration_ms, n=12, width=240):
    """Evenly spaced small pictures for the film strip (RGB numpy arrays)."""
    out = []
    try:
        with av.open(path) as c:
            v = next(s for s in c.streams if s.type == "video")
            v.thread_type = "AUTO"
            for i in range(n):
                t = duration_ms / 1000 * (2 * i + 1) / (2 * n)
                c.seek(int(t / v.time_base) + (v.start_time or 0), stream=v, backward=True, any_frame=False)
                for frame in c.decode(v):
                    h = max(1, int(round(frame.height * width / frame.width)))
                    img = frame.reformat(width=width, height=h, format="rgb24").to_ndarray()
                    turn = int(getattr(frame, "rotation", 0) or 0) % 360
                    if turn:                       # filmed sideways on a phone: show it upright
                        img = np.rot90(img, k=turn // 90)
                    out.append(np.ascontiguousarray(img))
                    break
    except Exception:
        pass
    return out


def trim(src, start_ms, end_ms, out_path, progress=None):
    """Copy the part between start_ms and end_ms into out_path, without re-encoding.
    Returns the real start (ms) of the clip (the keyframe it begins on)."""
    if end_ms <= start_ms:
        raise ClipError("OUT must be after IN")
    tmp = out_path + ".partial" + os.path.splitext(out_path)[1]
    ok = False
    try:
        with av.open(src) as inp:
            v = next((s for s in inp.streams if s.type == "video"), None)
            if v is None:
                raise ClipError("no video in this file")
            keep = [s for s in inp.streams if s.type in ("video", "audio")]
            fmt = None if not out_path.lower().endswith((".mts", ".m2ts", ".ts")) else "mpegts"
            with av.open(tmp, "w", format=fmt) as out:
                omap = {}
                for s in keep:
                    try:
                        omap[s.index] = out.add_stream_from_template(s)
                    except Exception:
                        if s is v:
                            raise
                start_s, end_s = start_ms / 1000, end_ms / 1000
                v0 = float((v.start_time or 0) * v.time_base)
                inp.seek(int((start_s + v0) / v.time_base), stream=v, backward=True, any_frame=False)

                base_s = None              # time of the first keyframe: becomes 0 in the clip
                done = set()
                span = max(0.001, end_s - start_s)
                for packet in inp.demux([s for s in keep if s.index in omap]):
                    s = packet.stream
                    if packet.dts is None and packet.pts is None:
                        continue
                    tb = s.time_base
                    s0 = float((s.start_time or 0) * tb)
                    pts_s = float(packet.pts * tb) - s0 if packet.pts is not None else None
                    dts_s = float(packet.dts * tb) - s0 if packet.dts is not None else pts_s
                    if base_s is None:
                        # wait for the first video keyframe; earlier sound is dropped
                        if s is not v or not packet.is_keyframe:
                            continue
                        base_s = pts_s if pts_s is not None else dts_s    # the keyframe's picture = 0:00
                    if s.index in done:
                        continue
                    if s is v:
                        if dts_s > end_s + 1e-6:             # every later picture is after OUT
                            done.add(s.index)
                            if all(x.index in done for x in keep if x.index in omap):
                                break
                            continue
                    else:
                        if pts_s is not None and pts_s < base_s - 1e-3:
                            continue
                        if pts_s is not None and pts_s > end_s:
                            done.add(s.index)
                            if all(x.index in done for x in keep if x.index in omap):
                                break
                            continue
                    shift = int(round(base_s / tb))
                    if packet.pts is not None:
                        packet.pts = packet.pts - int(round(s0 / tb)) - shift
                    if packet.dts is not None:
                        packet.dts = packet.dts - int(round(s0 / tb)) - shift
                    packet.stream = omap[s.index]
                    out.mux(packet)
                    if progress and s is v and pts_s is not None:
                        progress(min(1.0, max(0.0, (pts_s - start_s) / span)))
                if base_s is None:
                    raise ClipError("no keyframe found before IN")
        os.replace(tmp, out_path)
        ok = True
        return int(round(base_s * 1000))
    except ClipError:
        raise
    except Exception as e:
        raise ClipError(str(e)) from e
    finally:
        if not ok and os.path.exists(tmp):
            try:
                os.remove(tmp)
            except OSError:
                pass


def fmt(ms):
    """00:00.000, or 0:00:00.000 past an hour."""
    ms = max(0, int(ms))
    h, rest = divmod(ms, 3600000)
    m, rest = divmod(rest, 60000)
    s, milli = divmod(rest, 1000)
    return f"{h}:{m:02d}:{s:02d}.{milli:03d}" if h else f"{m:02d}:{s:02d}.{milli:03d}"
