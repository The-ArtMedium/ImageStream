"""LocalClip — lossless video trimming on your own computer.
Free to use. See LICENSE."""
import sys

from PySide6.QtCore import Qt, QTranslator, QLibraryInfo
from PySide6.QtWidgets import QApplication


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("LocalClip")
    app.setOrganizationName("ImageStream")
    app.setStyle("Fusion")
    from app import i18n
    if i18n.RTL:
        app.setLayoutDirection(Qt.RightToLeft)          # Arabic reads right to left
    qt_words = QTranslator(app)                         # Qt's own buttons: OK, Cancel, Yes, No
    if qt_words.load("qtbase_" + i18n.LANG, QLibraryInfo.path(QLibraryInfo.TranslationsPath)):
        app.installTranslator(qt_words)
    app.setStyleSheet("QToolTip { background:#141A22; color:white; border:1px solid #F5A623; padding:6px; }"
                      "QMessageBox { background:#141A22; } QMessageBox QLabel { color:white; }"
                      "QScrollBar:vertical { background:#141A22; width:10px; margin:0; }"
                      "QScrollBar::handle:vertical { background:#3A4757; border-radius:5px; min-height:30px; }"
                      "QScrollBar::add-line, QScrollBar::sub-line { height:0; width:0; }"
                      "QScrollBar::add-page, QScrollBar::sub-page { background:none; }")
    from app.window import ClipWindow
    w = ClipWindow()
    w.show()
    if len(sys.argv) > 1:                               # a video dropped on the app icon
        w.load(sys.argv[1])
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
